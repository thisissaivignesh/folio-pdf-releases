"""Continuous-scroll page view: rendering, zoom, text selection, editing tools, laser pointer, touch."""
import math
import time
from collections import OrderedDict

import fitz
from PySide6.QtCore import Qt, QRectF, QPointF, Signal, QTimer, QEvent
from PySide6.QtGui import (QImage, QPainter, QColor, QPen, QPainterPath, QTransform, QCursor, QPixmap,
                           QInputDevice, QEventPoint, QBrush, QPolygonF)
from PySide6.QtWidgets import (QGraphicsView, QGraphicsScene, QGraphicsItem, QGraphicsRectItem,
                               QGraphicsPathItem, QFrame)

from . import theme

PAGE_GAP = 14.0
ZOOM_MIN, ZOOM_MAX = 0.1, 8.0

# What the mouse/finger does with each tool
TEXT_TOOLS = {"select", "highlight"}                 # follow the text, like a browser
DRAG_TOOLS = {"rect", "image", "signature"}           # drag a box
CLICK_TOOLS = {"text", "note", "erase"}              # act on a click/tap
STROKE_TOOLS = {"draw", "laser"}                     # follow the pointer


# ======================================================================= text
class TextLayer:
    """The characters on one page, in reading order, for selecting text."""

    def __init__(self, page):
        self.chars = []     # (fitz.Rect, str)
        self.lines = []     # (fitz.Rect, start, end)
        try:
            raw = page.get_text("rawdict", flags=fitz.TEXT_PRESERVE_WHITESPACE | fitz.TEXT_PRESERVE_LIGATURES)
        except Exception:
            return
        for block in raw.get("blocks", []):
            if block.get("type", 0) != 0:
                continue
            for line in block.get("lines", []):
                start = len(self.chars)
                for span in line.get("spans", []):
                    for ch in span.get("chars", []):
                        self.chars.append((fitz.Rect(ch["bbox"]), ch.get("c", "")))
                if len(self.chars) > start:
                    self.lines.append((fitz.Rect(line["bbox"]), start, len(self.chars)))

    def __bool__(self):
        return bool(self.chars)

    def _line_at(self, pt):
        best, best_score = None, None
        for li, (r, s, e) in enumerate(self.lines):
            dy = 0 if r.y0 <= pt.y <= r.y1 else min(abs(pt.y - r.y0), abs(pt.y - r.y1))
            dx = 0 if r.x0 <= pt.x <= r.x1 else min(abs(pt.x - r.x0), abs(pt.x - r.x1))
            score = dy * 4 + dx
            if best_score is None or score < best_score:
                best, best_score = li, score
        return best

    def index_at(self, pt):
        """Caret position (0..len) nearest to the point."""
        li = self._line_at(pt)
        if li is None:
            return 0
        _, s, e = self.lines[li]
        for i in range(s, e):
            r = self.chars[i][0]
            if pt.x < (r.x0 + r.x1) / 2:
                return i
        return e

    def word_at(self, pt):
        li = self._line_at(pt)
        if li is None:
            return 0, 0
        _, s, e = self.lines[li]
        i = min(max(self.index_at(pt), s), e - 1)
        if self.chars[i][1].isspace() and i > s:
            i -= 1
        a = b = i
        while a > s and not self.chars[a - 1][1].isspace():
            a -= 1
        while b < e and not self.chars[b][1].isspace():
            b += 1
        return a, b

    def line_rects(self, i0, i1):
        out = []
        for r, s, e in self.lines:
            a, b = max(i0, s), min(i1, e)
            if a >= b:
                continue
            rr = fitz.Rect(self.chars[a][0])
            for i in range(a + 1, b):
                if not self.chars[i][0].is_empty:
                    rr |= self.chars[i][0]
            rr.y0, rr.y1 = min(rr.y0, r.y0), max(rr.y1, r.y1)
            if rr.width > 0.5:
                out.append(rr)
        return out

    def text(self, i0, i1):
        parts = []
        for r, s, e in self.lines:
            a, b = max(i0, s), min(i1, e)
            if a < b:
                parts.append("".join(c for _, c in self.chars[a:b]).rstrip())
        return "\n".join(parts)


# ====================================================================== pages
class StrokeItem(QGraphicsItem):
    """A freehand line drawn straight from its list of points (used for the live
    Draw preview and for laser marks). Painting a polyline avoids building a QPainterPath,
    which in this Qt version started every stroke at the document's top-left corner."""

    def __init__(self, first_point, pen):
        super().__init__()
        p = QPointF(first_point)
        self.points = [p]
        self.pen = pen
        self._minx = self._maxx = p.x()
        self._miny = self._maxy = p.y()

    def add_point(self, p):
        p = QPointF(p)
        if self.points and p == self.points[-1]:
            return
        self.prepareGeometryChange()
        self.points.append(p)
        self._minx, self._maxx = min(self._minx, p.x()), max(self._maxx, p.x())
        self._miny, self._maxy = min(self._miny, p.y()), max(self._maxy, p.y())

    def boundingRect(self):
        # the whole stroke plus room for the (screen-sized) pen, so erasing it repaints everything
        zoom = 1.0
        sc = self.scene()
        if sc is not None and sc.views():
            zoom = max(getattr(sc.views()[0], "zoom", 1.0), 0.05)
        m = (self.pen.widthF() / 2 + 4) / zoom if self.pen.isCosmetic() else self.pen.widthF() / 2 + 4
        return QRectF(self._minx - m, self._miny - m, self._maxx - self._minx + 2 * m, self._maxy - self._miny + 2 * m)

    def paint(self, painter, option, widget=None):
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(self.pen)
        if len(self.points) == 1:
            painter.drawPoint(self.points[0])
        else:
            painter.drawPolyline(QPolygonF(self.points))


class PageItem(QGraphicsItem):
    """One page. Renders itself lazily at the resolution it is shown at."""

    def __init__(self, view, pno, width, height):
        super().__init__()
        self.view = view
        self.pno = pno
        self.w = width
        self.h = height

    def boundingRect(self):
        return QRectF(-3, -3, self.w + 6, self.h + 6)

    def paint(self, painter, option, widget=None):
        t = theme.tokens()
        target = QRectF(0, 0, self.w, self.h)
        if t["page_shadow"]:
            painter.fillRect(QRectF(1.5, 2.5, self.w, self.h), QColor(0, 0, 0, t["page_shadow"]))
        painter.fillRect(target, QColor(t["dark_page_bg"]) if self.view.dark_pages else Qt.GlobalColor.white)
        scale = painter.worldTransform().m11()
        dpr = widget.devicePixelRatioF() if widget is not None else 1.0
        img = self.view.page_image(self.pno, scale * dpr)
        if img is not None:
            painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
            painter.drawImage(target, img)
        if t["page_border"]:
            pen = QPen(QColor(t["page_border"]), 0)
            pen.setCosmetic(True)
            painter.setPen(pen)
            painter.drawRect(target)


def _laser_cursor(color):
    pm = QPixmap(22, 22)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    glow = QColor(color)
    glow.setAlpha(90)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(glow)
    p.drawEllipse(QRectF(2, 2, 18, 18))
    p.setBrush(QColor(color))
    p.drawEllipse(QRectF(7, 7, 8, 8))
    p.end()
    return QCursor(pm, 11, 11)


class PageView(QGraphicsView):
    currentPageChanged = Signal(int)
    zoomChanged = Signal(float)
    # editing signals carry page number and PDF (unrotated) coordinates
    rectDrawn = Signal(str, int, object)          # tool, pno, fitz.Rect
    pointClicked = Signal(str, int, object)       # tool, pno, fitz.Point
    inkDrawn = Signal(int, object)                # pno, [fitz.Point]
    selectionFinished = Signal(str)               # tool ("select" or "highlight")
    contextRequested = Signal(str, int, object, object)   # tool, pno (-1 = none), fitz.Point, QPoint global

    def __init__(self, model, parent=None):
        super().__init__(parent)
        self.model = model
        self.scene_ = QGraphicsScene(self)
        self.setScene(self.scene_)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        self.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.SmartViewportUpdate)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.items_ = []
        self.zoom = 1.0
        self.fit_mode = "width"   # "width", "page" or None
        self.tool = "select"
        self.ink_color = (0.85, 0.1, 0.1)
        self.highlight_color = QColor("#ffd400")
        self.laser_color = QColor("#ff2d2d")
        self.dark_pages = False
        self._cache = OrderedDict()   # pno -> (scale, QImage)
        self._cache_limit = 14
        self._text = {}               # pno -> TextLayer
        self._search_items = []
        self._drag_start = None
        self._drag_item = None
        self._drag_page = None
        self._ink_path = None
        self._ink_points = []
        self._laser_items = []
        self._laser_path = None
        self._sel = None              # {"anchor": (pno, idx), "focus": (pno, idx), "tool": str}
        self._sel_items = []
        self._last_page = -1
        self.verticalScrollBar().valueChanged.connect(self._on_scroll)
        self._refit_timer = QTimer(self, singleShot=True, interval=60, timeout=self._apply_fit)
        # touch screens
        self.viewport().setAttribute(Qt.WidgetAttribute.WA_AcceptTouchEvents, True)
        self._touch = None
        self._touch_ended = 0.0
        self._pinching = False
        self._velocity = [0.0, 0.0]
        self._kinetic = QTimer(self, interval=16, timeout=self._kinetic_step)
        self._long_press = QTimer(self, singleShot=True, interval=500, timeout=self._on_long_press)
        self.apply_theme()
        self.set_tool("select")

    # ------------------------------------------------------------ theme
    def apply_theme(self):
        self.setBackgroundBrush(theme.qcolor("canvas"))
        self.set_dark_pages(self.dark_pages, force=True)
        self._restyle_selection()

    def set_dark_pages(self, on, force=False):
        if on == self.dark_pages and not force:
            return
        self.dark_pages = on
        self._cache.clear()
        self.viewport().update()

    # ------------------------------------------------------------ rendering
    def page_image(self, pno, scale):
        doc = self.model.doc
        if doc is None or pno >= doc.page_count:
            return None
        scale = max(0.05, min(scale, 6.0))
        cached = self._cache.get(pno)
        if cached and self._pinching:      # keep pinch-zoom smooth; re-render when fingers lift
            return cached[1]
        if cached and abs(cached[0] - scale) / scale < 0.08:
            self._cache.move_to_end(pno)
            return cached[1]
        try:
            pix = doc[pno].get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False, annots=True)
        except Exception:
            return None
        img = QImage(pix.samples, pix.width, pix.height, pix.stride,
                     QImage.Format.Format_RGB888).copy()
        if self.dark_pages:
            img.invertPixels(QImage.InvertMode.InvertRgb)
            bg = QColor(theme.c("dark_page_bg"))
            if bg != QColor("#000000"):                # lift pure black up to the theme's grey
                img = img.convertToFormat(QImage.Format.Format_RGB32)
                p = QPainter(img)
                p.setCompositionMode(QPainter.CompositionMode.CompositionMode_Lighten)
                p.fillRect(img.rect(), bg)
                p.end()
        self._cache[pno] = (scale, img)
        self._cache.move_to_end(pno)
        while len(self._cache) > self._cache_limit:
            self._cache.popitem(last=False)
        return img

    def invalidate_page(self, pno):
        self._cache.pop(pno, None)
        self._text.pop(pno, None)
        if 0 <= pno < len(self.items_):
            self.items_[pno].update()

    def rebuild(self, keep_position=True):
        """Lay out all pages again (after loading, rotating, inserting, deleting...)."""
        old_page = self.current_page() if keep_position else 0
        self._cache.clear()
        self._text.clear()
        self._sel = None
        self._sel_items = []
        self._laser_items = []
        self._laser_path = None
        self._tool_cancel()
        self.scene_.clear()
        self.items_ = []
        self._search_items = []
        doc = self.model.doc
        if doc is None:
            self.scene_.setSceneRect(QRectF())
            return
        y = PAGE_GAP
        maxw = 0
        for pno in range(doc.page_count):
            r = doc[pno].rect
            item = PageItem(self, pno, r.width, r.height)
            item.setPos(-r.width / 2, y)
            self.scene_.addItem(item)
            self.items_.append(item)
            y += r.height + PAGE_GAP
            maxw = max(maxw, r.width)
        self.scene_.setSceneRect(QRectF(-maxw / 2 - PAGE_GAP, 0, maxw + 2 * PAGE_GAP, y))
        if self.fit_mode:
            self._apply_fit()
        if keep_position:
            self.go_to_page(min(old_page, doc.page_count - 1))
        else:
            self.go_to_page(0)

    # ----------------------------------------------------------------- zoom
    def set_zoom(self, z, keep_fit=False):
        z = max(ZOOM_MIN, min(ZOOM_MAX, z))
        if not keep_fit:
            self.fit_mode = None
        page = self.current_page()
        frac = self._page_fraction()
        self.zoom = z
        self.setTransform(QTransform.fromScale(z, z))
        self.go_to_page(page, frac_y=frac)
        self.zoomChanged.emit(z)

    def zoom_in(self):
        self.set_zoom(self.zoom * 1.2)

    def zoom_out(self):
        self.set_zoom(self.zoom / 1.2)

    def fit_width(self):
        self.fit_mode = "width"
        self._apply_fit()

    def fit_page(self):
        self.fit_mode = "page"
        self._apply_fit()

    def _apply_fit(self):
        if not self.items_ or not self.fit_mode:
            return
        item = self.items_[max(0, self.current_page())]
        vw = self.viewport().width() - 4
        vh = self.viewport().height() - 4
        maxw = max(it.w for it in self.items_)
        if self.fit_mode == "width":
            z = vw / (maxw + 2 * PAGE_GAP)
        else:
            z = min(vw / (maxw + 2 * PAGE_GAP), vh / (item.h + 2 * PAGE_GAP))
        self.set_zoom(z, keep_fit=True)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self.fit_mode:
            self._refit_timer.start()

    def wheelEvent(self, event):
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
            self.set_zoom(self.zoom * factor)
            event.accept()
            return
        super().wheelEvent(event)

    # ----------------------------------------------------------- navigation
    def _view_top_scene_y(self):
        return self.mapToScene(0, 0).y()

    def current_page(self):
        if not self.items_:
            return -1
        probe = self.mapToScene(self.viewport().width() // 2, self.viewport().height() // 3).y()
        for item in self.items_:
            if probe <= item.y() + item.h + PAGE_GAP / 2:
                return item.pno
        return self.items_[-1].pno

    def _page_fraction(self):
        p = self.current_page()
        if p < 0:
            return 0.0
        item = self.items_[p]
        return (self._view_top_scene_y() - item.y()) / item.h

    def go_to_page(self, pno, y=None, frac_y=None):
        """Scroll so page pno is at the top. y = position on the page in visible points."""
        if not self.items_:
            return
        pno = max(0, min(pno, len(self.items_) - 1))
        item = self.items_[pno]
        if y is not None:
            top = item.y() + max(0.0, y - 20)
        elif frac_y is not None:
            top = item.y() + frac_y * item.h
        else:
            top = item.y() - PAGE_GAP / 2
        bar = self.verticalScrollBar()
        bar.setValue(int(round((top - self.sceneRect().top()) * self.zoom)))
        self._on_scroll()

    def next_page(self):
        self.go_to_page(self.current_page() + 1)

    def prev_page(self):
        self.go_to_page(self.current_page() - 1)

    def _on_scroll(self, *_):
        p = self.current_page()
        if p != self._last_page:
            self._last_page = p
            self.currentPageChanged.emit(p)

    def view_point_on_page(self, pno):
        """Visible-page y coordinate of the top of the window (for 'add chapter here')."""
        if not (0 <= pno < len(self.items_)):
            return 0.0
        return max(0.0, self._view_top_scene_y() - self.items_[pno].y())

    def flash(self, pno, rects):
        """Briefly outline some (unrotated) rectangles on a page, e.g. a saved highlight."""
        if not (0 <= pno < len(self.items_)) or not rects:
            return
        page = self.model.doc[pno]
        path = QPainterPath()
        for r in rects:
            v = fitz.Rect(r) * page.rotation_matrix
            path.addRoundedRect(QRectF(v.x0 - 2, v.y0 - 2, v.width + 4, v.height + 4), 3, 3)
        item = QGraphicsPathItem(path, self.items_[pno])
        pen = QPen(theme.qcolor("accent"), 2)
        pen.setCosmetic(True)
        item.setPen(pen)
        item.setZValue(20)
        def remove():
            try:
                if item.scene() is not None:
                    self.scene_.removeItem(item)
            except RuntimeError:          # the page was redrawn meanwhile; nothing left to remove
                pass
        QTimer.singleShot(1400, remove)

    # ------------------------------------------------------- search display
    def clear_search_highlights(self):
        for it in self._search_items:
            if it.scene() is not None:
                self.scene_.removeItem(it)
        self._search_items = []

    def show_search_hits(self, hits, current=-1):
        """hits: list of (pno, visible fitz.Rect)."""
        self.clear_search_highlights()
        for pno, r in hits:
            if pno >= len(self.items_):
                continue
            item = QGraphicsRectItem(QRectF(r.x0 - 1, r.y0 - 1, r.width + 2, r.height + 2), self.items_[pno])
            item.setPen(QPen(Qt.PenStyle.NoPen))
            item.setBrush(QColor(255, 214, 0, 95))
            item.setZValue(5)
            self._search_items.append(item)
        self.set_current_hit(hits, current)

    def set_current_hit(self, hits, index):
        for i, it in enumerate(self._search_items):
            if i == index:
                it.setBrush(QColor(255, 120, 0, 130))
                it.setPen(QPen(QColor(230, 90, 0), 0.8))
            else:
                it.setBrush(QColor(255, 214, 0, 95))
                it.setPen(QPen(Qt.PenStyle.NoPen))
        if 0 <= index < len(hits):
            pno, r = hits[index]
            if pno < len(self.items_):
                item = self.items_[pno]
                target = QRectF(item.x() + r.x0, item.y() + r.y0, r.width, r.height)
                self.ensureVisible(target, 60, 120)
                self._on_scroll()

    # ------------------------------------------------------------ text selection
    def text_layer(self, pno):
        layer = self._text.get(pno)
        if layer is None and self.model.doc is not None and 0 <= pno < self.model.doc.page_count:
            layer = self._text[pno] = TextLayer(self.model.doc[pno])
        return layer

    def has_selection(self):
        if not self._sel:
            return False
        (pa, ia), (pb, ib) = self._ordered()
        return (pa, ia) != (pb, ib)

    def _ordered(self):
        a, b = self._sel["anchor"], self._sel["focus"]
        return (a, b) if a <= b else (b, a)

    def selection_ranges(self):
        """{pno: (i0, i1)} for the current selection."""
        if not self._sel:
            return {}
        (pa, ia), (pb, ib) = self._ordered()
        out = {}
        for p in range(pa, pb + 1):
            layer = self.text_layer(p)
            if not layer:
                continue
            i0 = ia if p == pa else 0
            i1 = ib if p == pb else len(layer.chars)
            if i1 > i0:
                out[p] = (i0, i1)
        return out

    def selection_rects(self):
        """{pno: [fitz.Rect (unrotated), one per line]}"""
        return {p: self.text_layer(p).line_rects(i0, i1) for p, (i0, i1) in self.selection_ranges().items()}

    def selected_text(self):
        parts = [self.text_layer(p).text(i0, i1) for p, (i0, i1) in sorted(self.selection_ranges().items())]
        return "\n".join(x for x in parts if x)

    def clear_selection(self):
        self._sel = None
        self._draw_selection()

    def select_page_text(self, pno):
        layer = self.text_layer(pno)
        if layer:
            self._sel = {"anchor": (pno, 0), "focus": (pno, len(layer.chars)), "tool": "select"}
            self._draw_selection()

    def select_word_at(self, pno, pdf_pt):
        layer = self.text_layer(pno)
        if not layer:
            return False
        a, b = layer.word_at(pdf_pt)
        self._sel = {"anchor": (pno, a), "focus": (pno, b), "tool": self.tool}
        self._draw_selection()
        return b > a

    def _sel_color(self):
        if self._sel and self._sel.get("tool") == "highlight":
            c = QColor(self.highlight_color)
            c.setAlpha(120)
        else:
            c = theme.qcolor("selection", 80)
        return c

    def _restyle_selection(self):
        if self._sel_items:
            self._draw_selection()

    def _draw_selection(self):
        for it in self._sel_items:
            if it.scene() is not None:
                self.scene_.removeItem(it)
        self._sel_items = []
        if not self._sel or self.model.doc is None:
            return
        color = self._sel_color()
        for p, rects in self.selection_rects().items():
            if not rects or p >= len(self.items_):
                continue
            page = self.model.doc[p]
            path = QPainterPath()
            for r in rects:
                v = r * page.rotation_matrix
                path.addRect(QRectF(v.x0, v.y0, v.width, v.height))
            item = QGraphicsPathItem(path, self.items_[p])
            item.setPen(QPen(Qt.PenStyle.NoPen))
            item.setBrush(color)
            item.setZValue(8)
            self._sel_items.append(item)

    def _caret_at(self, scene_pos, clamp_page=None):
        """(pno, caret index) under a scene position."""
        item = clamp_page or self._page_at(scene_pos, nearest=True)
        if item is None:
            return None
        layer = self.text_layer(item.pno)
        if not layer:
            return (item.pno, 0)
        return (item.pno, layer.index_at(self._to_pdf_point(item, scene_pos)))

    # ------------------------------------------------------------- laser
    def clear_laser(self):
        had = bool(self._laser_items)
        for it in self._laser_items:
            if it.scene() is not None:
                self.scene_.removeItem(it)
        self._laser_items = []
        self._laser_path = None
        if had:
            self.viewport().update()

    def laser_count(self):
        return len(self._laser_items) // 2

    # ------------------------------------------------------------- tools
    def set_tool(self, tool):
        if tool != self.tool:
            self._tool_cancel()
        self.tool = tool
        if tool not in TEXT_TOOLS:
            self.clear_selection()
        if tool == "hand":
            self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
            self.viewport().setCursor(Qt.CursorShape.OpenHandCursor)
            return
        self.setDragMode(QGraphicsView.DragMode.NoDrag)
        if tool == "laser":
            self.viewport().setCursor(_laser_cursor(self.laser_color))
            return
        shape = {
            "select": Qt.CursorShape.IBeamCursor,
            "highlight": Qt.CursorShape.IBeamCursor,
            "text": Qt.CursorShape.IBeamCursor,
            "erase": Qt.CursorShape.PointingHandCursor,
            "note": Qt.CursorShape.PointingHandCursor,
        }.get(tool, Qt.CursorShape.CrossCursor)
        self.viewport().setCursor(shape)

    def refresh_cursor(self):
        self.set_tool(self.tool)

    def _page_at(self, scene_pos, nearest=False):
        for item in self.items_:
            if item.y() - PAGE_GAP / 2 <= scene_pos.y() <= item.y() + item.h + PAGE_GAP / 2:
                return item
        if nearest and self.items_:
            return self.items_[0] if scene_pos.y() < self.items_[0].y() else self.items_[-1]
        return None

    def _to_pdf_point(self, item, scene_pos):
        """Scene position -> unrotated PDF coordinates on that page."""
        local = scene_pos - item.pos()
        x = min(max(local.x(), 0), item.w)
        y = min(max(local.y(), 0), item.h)
        page = self.model.doc[item.pno]
        return fitz.Point(x, y) * page.derotation_matrix

    # ---------------------------------------------- strokes (mouse, pen, finger)
    def _tool_press(self, vpos, extend=False):
        """Start the current tool at viewport position vpos. Returns True if a stroke started."""
        if self.tool == "hand" or not self.items_:
            return False
        if self._drag_page is not None or self._laser_path is not None:
            self._tool_cancel()                  # never join two strokes together
        sp = self.mapToScene(vpos.toPoint())
        if self.tool == "laser":
            self._start_laser(sp)
            return True
        item = self._page_at(sp)
        if item is None:
            if self.tool in TEXT_TOOLS:
                self.clear_selection()
            return False
        if self.tool in CLICK_TOOLS:
            self.pointClicked.emit(self.tool, item.pno, self._to_pdf_point(item, sp))
            return False
        self._drag_page = item
        self._drag_start = sp
        if self.tool in TEXT_TOOLS and self.text_layer(item.pno):
            caret = self._caret_at(sp, item)
            if extend and self._sel:
                self._sel["focus"] = caret
            else:
                self._sel = {"anchor": caret, "focus": caret, "tool": self.tool}
            self._draw_selection()
            return True
        if self.tool in TEXT_TOOLS:
            self.clear_selection()
            if self.tool == "select":           # nothing to select on a scanned page
                self._drag_page = None
                return False
        if self.tool == "draw":
            self._ink_points = [sp]
            r, g, b = self.ink_color
            self._ink_path = StrokeItem(sp, QPen(QColor.fromRgbF(r, g, b), 2, Qt.PenStyle.SolidLine,
                                                 Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
            self._ink_path.setZValue(10)
            self.scene_.addItem(self._ink_path)
        else:                                     # boxes, pictures, signatures, highlight on scans
            self._drag_item = QGraphicsRectItem(QRectF(sp, sp))
            pen = QPen(theme.qcolor("accent"), 0)
            pen.setStyle(Qt.PenStyle.DashLine)
            self._drag_item.setPen(pen)
            col = theme.qcolor("accent", 30)
            if self.tool == "highlight":
                col = QColor(self.highlight_color)
                col.setAlpha(110)
            self._drag_item.setBrush(col)
            self._drag_item.setZValue(10)
            self.scene_.addItem(self._drag_item)
        return True

    def _start_laser(self, sp):
        glow = QColor(self.laser_color)
        glow.setAlpha(70)
        items = []
        for col, width in ((glow, 11), (self.laser_color, 3.5)):
            pen = QPen(col, width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
            pen.setCosmetic(True)
            it = StrokeItem(sp, pen)
            it.setZValue(30)
            self.scene_.addItem(it)
            items.append(it)
        self._laser_items.extend(items)
        self._laser_path = items

    def _clamp_to_page(self, sp):
        it = self._drag_page
        return QPointF(min(max(sp.x(), it.x()), it.x() + it.w),
                       min(max(sp.y(), it.y()), it.y() + it.h))

    def _tool_move(self, vpos):
        sp = self.mapToScene(vpos.toPoint())
        if self._laser_path is not None:
            for it in self._laser_path:
                it.add_point(sp)
            return
        if self._drag_page is None:
            return
        if self._sel is not None and self.tool in TEXT_TOOLS and self._drag_item is None:
            caret = self._caret_at(sp)
            if caret is not None and caret != self._sel["focus"]:
                self._sel["focus"] = caret
                self._draw_selection()
            return
        sp = self._clamp_to_page(sp)
        if self._ink_path is not None:
            self._ink_points.append(sp)
            self._ink_path.add_point(sp)
        elif self._drag_item is not None:
            self._drag_item.setRect(QRectF(self._drag_start, sp).normalized())

    def _tool_cancel(self):
        """Throw away a stroke in progress (e.g. a second finger turned it into a scroll)."""
        for it in (self._ink_path, self._drag_item):
            if it is not None and it.scene() is not None:
                self.scene_.removeItem(it)
        if self._laser_path is not None:
            for it in self._laser_path:
                if it.scene() is not None:
                    self.scene_.removeItem(it)
                if it in self._laser_items:
                    self._laser_items.remove(it)
        self._laser_path = None
        self._ink_path = None
        self._ink_points = []
        self._drag_item = None
        self._drag_page = None
        self._drag_start = None

    def _tool_release(self, vpos):
        if self._laser_path is not None:
            self._tool_move(vpos)
            self._laser_path = None          # the mark stays until a right-click
            return
        if self._drag_page is None:
            return
        item = self._drag_page
        tool = self.tool
        if self._sel is not None and tool in TEXT_TOOLS and self._drag_item is None:
            self._tool_move(vpos)
            self._drag_page = None
            self._drag_start = None
            if self.has_selection():
                self.selectionFinished.emit(tool)
            else:
                self.clear_selection()
            return
        sp = self._clamp_to_page(self.mapToScene(vpos.toPoint()))
        if self._ink_path is not None:
            self.scene_.removeItem(self._ink_path)
            pts = [self._to_pdf_point(item, p) for p in self._ink_points]
            self._ink_path = None
            self._ink_points = []
            if len(pts) >= 2:
                self.inkDrawn.emit(item.pno, pts)
        elif self._drag_item is not None:
            self.scene_.removeItem(self._drag_item)
            self._drag_item = None
            p1 = self._to_pdf_point(item, self._drag_start)
            p2 = self._to_pdf_point(item, sp)
            rect = fitz.Rect(p1, p2).normalize()
            if rect.width < 4 or rect.height < 4:
                # a plain click: give images/signatures a sensible default size
                if tool in ("image", "signature"):
                    w, h = (160, 110) if tool == "image" else (160, 60)
                    rect = fitz.Rect(p1.x, p1.y, p1.x + w, p1.y + h)
                    self.rectDrawn.emit(tool, item.pno, rect)
            else:
                self.rectDrawn.emit(tool, item.pno, rect)
        self._drag_page = None
        self._drag_start = None

    # ------------------------------------------------------------ mouse & pen
    def _ignore_mouse(self, event):
        """Mouse events Windows makes up from touch input. They carry a stale cursor position,
        which used to add a straight line from wherever the mouse last was to the stroke."""
        dev = event.pointingDevice()
        if dev is not None and dev.type() == QInputDevice.DeviceType.TouchScreen:
            return True
        try:
            if event.source() == Qt.MouseEventSource.MouseEventSynthesizedBySystem:
                return True
        except AttributeError:
            pass
        return self._touch is not None or (time.monotonic() - self._touch_ended) < 0.6

    def mousePressEvent(self, event):
        if self._ignore_mouse(event):
            event.accept()
            return
        self._kinetic.stop()
        if event.button() == Qt.MouseButton.LeftButton:
            extend = bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
            if self._tool_press(event.position(), extend=extend):
                event.accept()
                return
            if self.tool in CLICK_TOOLS or self.tool in TEXT_TOOLS:
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._ignore_mouse(event):
            event.accept()
            return
        if self._drag_page is None and self._laser_path is None:
            return super().mouseMoveEvent(event)
        if not (event.buttons() & Qt.MouseButton.LeftButton):
            self._tool_release(event.position())      # button let go somewhere we didn't see
            return
        self._tool_move(event.position())

    def mouseReleaseEvent(self, event):
        if self._ignore_mouse(event):
            event.accept()
            return
        if self._drag_page is None and self._laser_path is None:
            return super().mouseReleaseEvent(event)
        self._tool_release(event.position())

    def mouseDoubleClickEvent(self, event):
        if self._ignore_mouse(event) or event.button() != Qt.MouseButton.LeftButton:
            return
        if self.tool in TEXT_TOOLS and self.items_:
            sp = self.mapToScene(event.position().toPoint())
            item = self._page_at(sp)
            self._tool_cancel()
            if item is not None and self.select_word_at(item.pno, self._to_pdf_point(item, sp)):
                self.selectionFinished.emit(self.tool)
            return
        super().mouseDoubleClickEvent(event)

    def contextMenuEvent(self, event):
        if self.tool == "laser":
            self.clear_laser()
            event.accept()
            return
        sp = self.mapToScene(event.pos())
        item = self._page_at(sp)
        if item is None:
            self.contextRequested.emit(self.tool, -1, None, event.globalPos())
        else:
            self.contextRequested.emit(self.tool, item.pno, self._to_pdf_point(item, sp), event.globalPos())
        event.accept()

    # ------------------------------------------------------------- touch
    # One finger scrolls (Select and Hand tools) or uses the tool (editing tools).
    # Two fingers always scroll and pinch-zoom; a quick two-finger tap clears laser marks.
    # In Select, press and hold to start selecting text.
    def viewportEvent(self, event):
        if event.type() in (QEvent.Type.TouchBegin, QEvent.Type.TouchUpdate,
                            QEvent.Type.TouchEnd, QEvent.Type.TouchCancel):
            dev = event.device()
            if dev is not None and dev.type() == QInputDevice.DeviceType.TouchScreen:
                self._handle_touch(event)
                event.accept()
                return True
        return super().viewportEvent(event)

    def _scroll_by(self, dx, dy):
        h, v = self.horizontalScrollBar(), self.verticalScrollBar()
        h.setValue(int(round(h.value() - dx)))
        v.setValue(int(round(v.value() - dy)))

    def zoom_about(self, z, vpos):
        """Zoom so the document point under viewport position vpos stays under it."""
        z = max(ZOOM_MIN, min(ZOOM_MAX, z))
        if abs(z - self.zoom) < 1e-6:
            return
        anchor = self.mapToScene(vpos.toPoint())
        self.fit_mode = None
        self.zoom = z
        self.setTransform(QTransform.fromScale(z, z))
        moved = QPointF(self.mapFromScene(anchor)) - vpos
        self._scroll_by(-moved.x(), -moved.y())
        self._on_scroll()
        self.zoomChanged.emit(z)

    def _handle_touch(self, event):
        now = time.monotonic()
        t = event.type()
        down = [p for p in event.points() if p.state() != QEventPoint.State.Released]
        st = self._touch
        if t == QEvent.Type.TouchCancel:
            self._tool_cancel()
            self._touch_finish(cancelled=True)
            return
        if t == QEvent.Type.TouchBegin or st is None:
            self._kinetic.stop()
            p = (down or event.points())[0].position()
            st = self._touch = {"mode": None, "start": QPointF(p), "last": QPointF(p), "t0": now,
                                "samples": [(now, QPointF(p))], "far": False, "pinch_moved": 0.0}
            if len(down) <= 1:
                if self.tool in ("select", "hand"):
                    st["mode"] = "pan"
                    if self.tool == "select":
                        self._long_press.start()
                elif self.tool in CLICK_TOOLS:
                    st["mode"] = "tap"          # decided when the finger lifts
                else:
                    st["mode"] = "tool" if self._tool_press(p) else "pan"
        # a second finger: always scroll / pinch, dropping any stroke in progress
        if len(down) >= 2 and st["mode"] != "pinch":
            self._long_press.stop()
            if st["mode"] == "tool":
                self._tool_cancel()
            st["mode"] = "pinch"
            st["c"], st["d"] = self._centroid(down)
            self._pinching = True
        if st["mode"] == "pinch":
            if len(down) >= 2:
                c, d = self._centroid(down)
                st["pinch_moved"] += (c - st["c"]).manhattanLength() + abs(d - st["d"])
                self._scroll_by(c.x() - st["c"].x(), c.y() - st["c"].y())
                if st["d"] > 20 and d > 20:
                    self.zoom_about(self.zoom * d / st["d"], c)
                st["c"], st["d"] = c, d
            elif len(down) == 1:            # lifted one finger: keep scrolling with the other
                st["mode"] = "pan"
                st["last"] = QPointF(down[0].position())
                st["samples"] = [(now, st["last"])]
                self._pinching = False
                self.viewport().update()
        elif down:
            p = QPointF(down[0].position())
            if (p - st["start"]).manhattanLength() > 12:
                st["far"] = True
                self._long_press.stop()
            if st["mode"] == "pan":
                self._scroll_by(p.x() - st["last"].x(), p.y() - st["last"].y())
            elif st["mode"] == "tool":
                self._tool_move(p)
            elif st["mode"] == "tap" and st["far"]:
                st["mode"] = "pan"
                self._scroll_by(p.x() - st["start"].x(), p.y() - st["start"].y())
            st["last"] = p
            st["samples"] = [s for s in st["samples"] if now - s[0] < 0.1] + [(now, p)]
        if t == QEvent.Type.TouchEnd or not down:
            if st["mode"] == "tool":
                self._tool_release(st["last"])
            elif st["mode"] == "tap" and not st["far"]:
                self._tool_press(st["start"])
            elif st["mode"] == "pan":
                self._start_kinetic(st["samples"])
            elif st["mode"] == "pinch" and st["pinch_moved"] < 16 and now - st["t0"] < 0.4:
                self.clear_laser()            # two-finger tap = the touch version of a right-click
            self._touch_finish()

    @staticmethod
    def _centroid(points):
        xs = [p.position().x() for p in points[:2]]
        ys = [p.position().y() for p in points[:2]]
        c = QPointF(sum(xs) / 2, sum(ys) / 2)
        d = math.hypot(xs[0] - xs[1], ys[0] - ys[1])
        return c, d

    def _touch_finish(self, cancelled=False):
        self._long_press.stop()
        self._touch = None
        self._touch_ended = time.monotonic()
        if self._pinching:
            self._pinching = False
            self.viewport().update()     # re-render sharply at the new zoom

    def _on_long_press(self):
        """Select tool: holding a finger still starts a text selection there."""
        st = self._touch
        if st and st["mode"] == "pan" and not st["far"] and self.tool == "select":
            if self._tool_press(st["last"]):
                st["mode"] = "tool"

    def _start_kinetic(self, samples):
        if len(samples) < 2:
            return
        (t0, p0), (t1, p1) = samples[0], samples[-1]
        dt = (t1 - t0) * 1000
        if dt < 5:
            return
        vx, vy = (p1.x() - p0.x()) / dt, (p1.y() - p0.y()) / dt   # pixels per ms
        if math.hypot(vx, vy) < 0.25:
            return
        self._velocity = [vx, vy]
        self._kinetic.start()

    def _kinetic_step(self):
        vx, vy = self._velocity
        self._scroll_by(vx * 16, vy * 16)
        vx *= 0.94
        vy *= 0.94
        self._velocity = [vx, vy]
        if math.hypot(vx, vy) < 0.03:
            self._kinetic.stop()

    def keyPressEvent(self, event):
        key = event.key()
        ctrl = event.modifiers() & Qt.KeyboardModifier.ControlModifier
        if key == Qt.Key.Key_PageDown and ctrl:
            self.next_page()
        elif key == Qt.Key.Key_PageUp and ctrl:
            self.prev_page()
        elif key == Qt.Key.Key_Home and ctrl:
            self.go_to_page(0)
        elif key == Qt.Key.Key_End and ctrl:
            self.go_to_page(len(self.items_) - 1)
        elif key == Qt.Key.Key_Escape and (self._laser_items or self._sel):
            self.clear_laser()
            self.clear_selection()
        else:
            super().keyPressEvent(event)
