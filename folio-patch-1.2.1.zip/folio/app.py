"""Main window: document tabs, menus, toolbars and all editing actions."""
import os
import subprocess
import sys
import tempfile
import time
import uuid

import fitz
from PySide6.QtCore import Qt, QSettings, QSize, QThread, QTimer, QUrl, QPoint, QMimeData, QEvent
from PySide6.QtGui import (QAction, QActionGroup, QKeySequence, QColor, QIntValidator, QDrag, QCursor,
                           QDesktopServices, QPainter, QImage, QGuiApplication, QShortcut, QMouseEvent)
from PySide6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter, QToolBar,
                               QLabel, QLineEdit, QComboBox, QFileDialog, QMessageBox, QInputDialog,
                               QProgressDialog, QStackedWidget, QPushButton, QFrame, QToolButton,
                               QApplication, QListWidget, QListWidgetItem, QGridLayout, QTabWidget, QTabBar,
                               QSizePolicy, QMenu, QWidgetAction)

from . import __version__
from .document import DocumentModel
from .viewer import PageView
from .sidepanel import SidePanel
from . import store
from .search import find_all, has_text_layer
from .icons import icon, app_icon, set_icon, refresh_icons, wordmark, wordmark
from . import convert
from . import updater
from . import theme
from .colorpicker import pick_color, dot_icon, Swatch, HIGHLIGHTER, PEN
from .dialogs import TextDialog, SignatureDialog, ImagesToPdfDialog, NewPdfDialog

APP_NAME = "Olai"
SETTINGS = ("FolioPDF", "Folio PDF")       # internal storage names, kept from the old name
TAB_MIME = "application/x-olai-tab"
WINDOWS = []                                # every open main window
INSTANCE = {"server": None}                 # single-instance server (set by run.py)

OPEN_FILTER = ("All supported (*.pdf *.doc *.docx *.rtf *.odt *.ppt *.pptx *.pps *.ppsx *.odp "
               "*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff *.webp *.heic);;"
               "PDF (*.pdf);;Word (*.doc *.docx *.rtf *.odt);;PowerPoint (*.ppt *.pptx *.pps *.ppsx *.odp);;"
               "Photos (*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff *.webp *.heic)")

TOOLS = [
    ("select", "select", "Select text", "Drag over text to select it · Ctrl+C copies · right-click for more"),
    ("hand", "hand", "Hand", "Drag to scroll"),
    ("text", "text", "Add text", "Click where the text should go"),
    ("highlight", "highlight", "Highlight", "Drag over text to highlight it · right-click a highlight for options"),
    ("draw", "draw", "Draw", "Draw freehand on the page"),
    ("laser", "laser", "Laser", "Point things out while presenting · right-click clears (nothing is saved)"),
    ("rect", "rect", "Box", "Drag to draw a box"),
    ("note", "note", "Sticky note", "Click to add a comment note"),
    ("image", "image", "Picture", "Drag a box, then choose a picture"),
    ("signature", "signature", "Signature", "Draw a signature, then drag a box to place it"),
    ("erase", "eraser", "Remove", "Click a highlight, drawing, box, note or added text to remove it"),
]
SEPARATE_AFTER = ("hand", "laser", "signature")

DEFAULT_COLORS = {"text": "#111111", "highlight": "#ffd400", "draw": "#d61f1f",
                  "rect": "#d61f1f", "note": "#ffd400", "laser": "#ff2d2d"}
COLOR_TITLES = {"highlight": "Highlighter colours", "laser": "Laser colours"}

# which annotation types each tool's right-click can recolour / remove
TOOL_ANNOTS = {
    "highlight": {fitz.PDF_ANNOT_HIGHLIGHT},
    "draw": {fitz.PDF_ANNOT_INK},
    "rect": {fitz.PDF_ANNOT_SQUARE},
    "note": {fitz.PDF_ANNOT_TEXT},
    "text": {fitz.PDF_ANNOT_FREE_TEXT},
}


class _Worker(QThread):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn
        self.result = None
        self.error = None

    def run(self):
        try:
            self.result = self.fn()
        except Exception as e:
            self.error = e


def _rgb(hexcolor):
    c = QColor(hexcolor)
    return (c.redF(), c.greenF(), c.blueF())


def _hex(rgb):
    if not rgb:
        return None
    return QColor.fromRgbF(*[min(max(float(x), 0.0), 1.0) for x in rgb[:3]]).name()


# ================================================================ one document
class DocumentTab(QWidget):
    """Everything for one open file: the pages, its side panel, search state and undo history."""
    _counter = [0]

    def __init__(self, win):
        super().__init__()
        DocumentTab._counter[0] += 1
        self.uid = DocumentTab._counter[0]
        self.win = win
        self.model = DocumentModel()
        self.bookmarks = store.bookmarks()
        self.highlights = store.highlights()
        self.view = PageView(self.model)
        self.side = SidePanel(self)
        self.hits = []
        self.hit_index = -1
        self.search_phrase = ""
        self.own_toc_edit = False
        # banner (e.g. "Converted from Word")
        self.banner = QFrame()
        self.banner.setObjectName("banner")
        h = QHBoxLayout(self.banner)
        h.setContentsMargins(12, 6, 6, 6)
        self.banner_label = QLabel()
        self.banner_label.setWordWrap(True)
        h.addWidget(self.banner_label, 1)
        save = QPushButton("Save as PDF…")
        set_icon(save, "save")
        save.clicked.connect(lambda: self.win.save_as())
        h.addWidget(save)
        close = QToolButton()
        set_icon(close, "close")
        close.setAutoRaise(True)
        close.clicked.connect(self.banner.hide)
        h.addWidget(close)
        self.banner.hide()
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        rl.setSpacing(0)
        rl.addWidget(self.banner)
        rl.addWidget(self.view, 1)
        self.splitter = QSplitter()
        self.splitter.addWidget(self.side)
        self.splitter.addWidget(right)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setCollapsible(0, True)
        self.splitter.setCollapsible(1, False)
        self.splitter.setSizes([340, 940])
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.splitter)

    def title(self):
        star = "• " if self.model.modified else ""
        return star + (self.model.display_name or "Untitled")

    def file_key(self):
        p = self.model.path or self.model.source_path
        return os.path.normcase(os.path.abspath(p)) if p else None


class DocTabBar(QTabBar):
    """Document tabs. Drag a tab off the bar to open it in its own window, or onto another window."""

    def __init__(self, win):
        super().__init__()
        self.win = win
        self.setObjectName("docTabBar")
        self.setAcceptDrops(True)
        self.setElideMode(Qt.TextElideMode.ElideRight)
        self.setExpanding(False)
        self.setDrawBase(False)
        self._press = None
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._menu)

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._press = self.tabAt(e.position().toPoint())
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        if self._press is not None and self._press >= 0 and e.buttons() & Qt.MouseButton.LeftButton:
            y = e.position().y()
            if y < -36 or y > self.height() + 36:
                idx, self._press = self._press, None
                # let the bar finish its own drag-to-reorder before we take over
                rel = QMouseEvent(QEvent.Type.MouseButtonRelease, e.position(), e.globalPosition(),
                                  Qt.MouseButton.LeftButton, Qt.MouseButton.NoButton, e.modifiers())
                super().mouseReleaseEvent(rel)
                self.start_drag(idx)
                return
        super().mouseMoveEvent(e)

    def mouseReleaseEvent(self, e):
        self._press = None
        super().mouseReleaseEvent(e)

    def start_drag(self, idx):
        tab = self.win.tabs.widget(idx)
        if tab is None:
            return
        drag = QDrag(self)
        mime = QMimeData()
        mime.setData(TAB_MIME, f"{id(self.win)}:{tab.uid}".encode())
        drag.setMimeData(mime)
        pm = tab.grab()
        if not pm.isNull():
            drag.setPixmap(pm.scaled(300, 200, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation))
            drag.setHotSpot(QPoint(24, 12))
        result = drag.exec(Qt.DropAction.MoveAction)
        if result == Qt.DropAction.IgnoreAction:          # dropped outside any Olai window
            self.win.detach_tab(tab, QCursor.pos())

    def dragEnterEvent(self, e):
        if e.mimeData().hasFormat(TAB_MIME):
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if e.mimeData().hasFormat(TAB_MIME):
            e.acceptProposedAction()

    def dropEvent(self, e):
        if e.mimeData().hasFormat(TAB_MIME):
            self.win.receive_tab_drop(bytes(e.mimeData().data(TAB_MIME)).decode(),
                                      self.tabAt(e.position().toPoint()))
            e.acceptProposedAction()

    def _menu(self, pos):
        i = self.tabAt(pos)
        if i < 0:
            return
        tab = self.win.tabs.widget(i)
        m = QMenu(self)
        m.addAction("Open in new window", lambda: self.win.detach_tab(tab, self.mapToGlobal(pos) + QPoint(40, 40)))
        m.addSeparator()
        m.addAction("Close", lambda: self.win.close_tab(tab))
        m.addAction("Close other tabs", lambda: self.win.close_other_tabs(tab))
        path = tab.model.path or tab.model.source_path
        if path:
            m.addSeparator()
            m.addAction("Copy file path", lambda: QGuiApplication.clipboard().setText(path))
            m.addAction("Show in folder", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path))))
        m.exec(self.mapToGlobal(pos))


def show_menu(menu, global_pos):
    """Shows a popup menu (the self-test replaces this so it never waits for a click)."""
    return menu.exec(global_pos)


def find_window_by_id(wid):
    for w in WINDOWS:
        if id(w) == wid:
            return w
    return None


def find_open(path):
    """(window, tab) already showing this file, if any."""
    key = os.path.normcase(os.path.abspath(path))
    for w in WINDOWS:
        for i in range(w.tabs.count()):
            t = w.tabs.widget(i)
            if t.file_key() == key:
                return w, t
    return None, None


def open_files(paths, window=None):
    """Open files in the given (or most recently active) window, as new tabs."""
    win = window
    if win is None:
        active = QApplication.activeWindow()
        win = active if isinstance(active, MainWindow) else (WINDOWS[-1] if WINDOWS else None)
    if win is None:
        win = MainWindow()
        win.show()
    for p in paths:
        if p and os.path.exists(p):
            win.open_path(os.path.abspath(p))
    win.bring_to_front()
    return win


# ================================================================ main window
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        WINDOWS.append(self)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.setWindowIcon(app_icon())
        self.settings = QSettings(*SETTINGS)
        self.bookmarks = store.bookmarks()
        self.highlights_store = store.highlights()
        self.colors = dict(DEFAULT_COLORS)
        for k in self.colors:
            v = self.settings.value(f"color/{k}")
            if v and QColor(v).isValid():
                self.colors[k] = v
        self.current_tool = "select"
        self._signature = None
        self._closing = False
        self.dark_pages = self.settings.value("dark_pages", False, type=bool)

        # a hidden placeholder so actions always have a "current document", even with no tabs
        self._empty = DocumentTab(self)
        self._empty.setParent(self)
        self._empty.hide()

        self.tabs = QTabWidget()
        self.tabbar = DocTabBar(self)
        self.tabs.setTabBar(self.tabbar)
        self.tabs.setDocumentMode(True)
        self.tabs.setMovable(True)
        self.tabs.currentChanged.connect(lambda _: self._sync_ui())
        plus = QToolButton()
        plus.setAutoRaise(True)
        set_icon(plus, "plus")
        plus.setToolTip("Open another file in a new tab (Ctrl+O)")
        plus.clicked.connect(self.open_dialog)
        self.tabs.setCornerWidget(plus, Qt.Corner.TopRightCorner)

        self.welcome = self._make_welcome()
        self.stack = QStackedWidget()
        self.stack.addWidget(self.welcome)
        self.stack.addWidget(self.tabs)
        self.setCentralWidget(self.stack)

        self._make_actions()
        self._make_menus()
        self._make_toolbars()
        self.status_page = QLabel()
        self.statusBar().addPermanentWidget(self.status_page)
        theme.notifier.changed.connect(self._on_theme_changed)

        self.setAcceptDrops(True)
        self.resize(1280, 860)
        if len(WINDOWS) == 1:
            geo = self.settings.value("geometry")
            if geo is not None:
                self.restoreGeometry(geo)
        self._sync_ui()
        self._refresh_recent()

    # ---------------------------------------------------- current document
    @property
    def tab(self):
        w = self.tabs.currentWidget()
        return w if w is not None else self._empty

    @property
    def model(self):
        return self.tab.model

    @property
    def view(self):
        return self.tab.view

    @property
    def side(self):
        return self.tab.side

    @property
    def banner(self):
        return self.tab.banner

    @property
    def banner_label(self):
        return self.tab.banner_label

    @property
    def hits(self):
        return self.tab.hits

    @hits.setter
    def hits(self, v):
        self.tab.hits = v

    @property
    def hit_index(self):
        return self.tab.hit_index

    @hit_index.setter
    def hit_index(self, v):
        self.tab.hit_index = v

    @property
    def _search_phrase(self):
        return self.tab.search_phrase

    @_search_phrase.setter
    def _search_phrase(self, v):
        self.tab.search_phrase = v

    def all_tabs(self):
        return [self.tabs.widget(i) for i in range(self.tabs.count())]

    # ================================================================ building
    def _make_welcome(self):
        w = QWidget()
        w.setObjectName("welcome")
        outer = QVBoxLayout(w)
        outer.addStretch(1)
        col = QVBoxLayout()
        col.setSpacing(14)
        logo = QLabel()
        logo.setPixmap(app_icon().pixmap(84, 84))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        col.addWidget(logo)
        title = QLabel(APP_NAME)
        title.setObjectName("welcomeTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        col.addWidget(title)
        sub = QLabel("Open, read, mark up and create PDFs. Drop files anywhere in this window.")
        sub.setObjectName("welcomeSub")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        col.addWidget(sub)
        grid = QGridLayout()
        grid.setSpacing(12)
        buttons = [
            ("open", "Open files\nPDF, Word, PowerPoint or photo", self.open_dialog),
            ("image", "Photos to PDF\nTurn pictures into one PDF", self.images_to_pdf),
            ("convert", "Word or PowerPoint to PDF\nConvert and save a copy", self.office_to_pdf_dialog),
            ("new", "New blank PDF\nStart from empty pages", self.new_pdf),
        ]
        for i, (ic, text, slot) in enumerate(buttons):
            b = QPushButton("  " + text.replace("\n", "\n  "))
            set_icon(b, ic, "accent")
            b.setProperty("class", "big")
            b.setIconSize(QSize(28, 28))
            b.setMinimumSize(300, 70)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda checked=False, s=slot: s())
            grid.addWidget(b, i // 2, i % 2)
        col.addLayout(grid)
        self.recent_label = QLabel("Recent files")
        self.recent_label.setObjectName("recentLabel")
        col.addWidget(self.recent_label)
        self.recent_list = QListWidget()
        self.recent_list.setObjectName("recentList")
        self.recent_list.setMaximumHeight(190)
        self.recent_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.recent_list.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.recent_list.setMaximumWidth(612)
        self.recent_list.itemActivated.connect(lambda it: self.open_path(it.data(Qt.ItemDataRole.UserRole)))
        self.recent_list.itemClicked.connect(lambda it: self.open_path(it.data(Qt.ItemDataRole.UserRole)))
        col.addWidget(self.recent_list)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addLayout(col)
        row.addStretch(1)
        outer.addLayout(row)
        outer.addStretch(2)
        return w

    def _act(self, text, slot, shortcut=None, ic=None, tip=None, checkable=False):
        a = QAction(text, self)
        if ic:
            set_icon(a, ic)
        if shortcut:
            if isinstance(shortcut, (list, tuple)):
                a.setShortcuts([QKeySequence(s) for s in shortcut])
            else:
                a.setShortcut(QKeySequence(shortcut))
        if tip:
            a.setToolTip(tip)
        a.setCheckable(checkable)
        a.triggered.connect(lambda checked=False: slot())
        return a

    def _make_actions(self):
        A = self._act
        self.a_new = A("&New blank PDF…", self.new_pdf, "Ctrl+N", "new")
        self.a_open = A("&Open…", self.open_dialog, "Ctrl+O", "open", "Open (Ctrl+O)")
        self.a_new_window = A("New &window", self.new_window, "Ctrl+Shift+N", "window")
        self.a_save = A("&Save", self.save, "Ctrl+S", "save", "Save (Ctrl+S)")
        self.a_save_as = A("Save &as…", self.save_as, "Ctrl+Shift+S")
        self.a_print = A("&Print…", self.print_doc, "Ctrl+P", "print", "Print (Ctrl+P)")
        self.a_close = A("&Close tab", self.close_tab, "Ctrl+W")
        self.a_exit = A("E&xit", self.close, "Alt+F4")
        self.a_img2pdf = A("&Photos to PDF…", self.images_to_pdf, None, "image")
        self.a_office2pdf = A("&Word or PowerPoint to PDF…", self.office_to_pdf_dialog, None, "convert")
        self.a_undo = A("&Undo", self.undo, "Ctrl+Z", "undo", "Undo (Ctrl+Z)")
        self.a_redo = A("&Redo", self.redo, ["Ctrl+Y", "Ctrl+Shift+Z"], "redo", "Redo (Ctrl+Y)")
        self.a_copy = A("&Copy", self.copy_selection, "Ctrl+C", "copy")
        self.a_select_page = A("Select all text on this &page", self.select_page_text, "Ctrl+A")
        self.a_find = A("&Find…", self.focus_search, "Ctrl+F", "search", "Find a word or phrase (Ctrl+F)")
        self.a_find_next = A("Find &next", lambda: self.step_search(1), "F3")
        self.a_find_prev = A("Find pre&vious", lambda: self.step_search(-1), "Shift+F3")
        self.a_sidebar = A("&Side panel", self.toggle_sidebar, "F4", "sidebar",
                           "Show or hide the side panel (F4)", checkable=True)
        self.a_sidebar.setChecked(True)
        self.a_zoom_in = A("Zoom &in", lambda: self.view.zoom_in(), ["Ctrl++", "Ctrl+="], "zoom_in", "Zoom in")
        self.a_zoom_out = A("Zoom &out", lambda: self.view.zoom_out(), "Ctrl+-", "zoom_out", "Zoom out")
        self.a_fit_w = A("Fit &width", lambda: self.view.fit_width(), "Ctrl+0", "fit_width", "Fit width (Ctrl+0)")
        self.a_fit_p = A("Fit &page", lambda: self.view.fit_page(), "Ctrl+9", "fit_page", "Whole page (Ctrl+9)")
        self.a_goto = A("&Go to page…", self.goto_dialog, "Ctrl+G")
        self.a_prev = A("Previous page", lambda: self.view.prev_page(), None, "prev", "Previous page")
        self.a_next = A("Next page", lambda: self.view.next_page(), None, "next", "Next page")
        self.a_next_tab = A("Next tab", lambda: self._cycle_tab(1), ["Ctrl+Tab", "Ctrl+PgDown"])
        self.a_prev_tab = A("Previous tab", lambda: self._cycle_tab(-1), ["Ctrl+Shift+Tab", "Ctrl+PgUp"])
        self.a_add_chapter = A("Add &chapter here…", lambda: self._show_panel("chapters", self.side.chapters.add_chapter),
                               "Ctrl+Shift+C", "chapters")
        self.a_add_sub = A("Add &sub-chapter…", lambda: self._show_panel("chapters", self.side.chapters.add_sub_chapter))
        self.a_add_bookmark = A("Add &bookmark here…", lambda: self._show_panel("bookmarks", self.side.bookmarks.add),
                                "Ctrl+D", "bookmark_add", "Bookmark this spot (Ctrl+D)")
        self.a_show_highlights = A("Show &Highlights", lambda: self._show_panel("highlights"), "Ctrl+Shift+H",
                                   "highlights")
        cur = lambda: max(0, self.view.current_page())
        self.a_pg_blank = A("Insert &blank page after", lambda: self.page_action("blank", cur()), None, "plus")
        self.a_pg_file = A("Insert pages from &file…", lambda: self.page_action("insert_file", cur()), None, "open")
        self.a_pg_rotl = A("Rotate &left", lambda: self.page_action("rotl", cur()), "Ctrl+Shift+L", "rotate_left")
        self.a_pg_rotr = A("Rotate &right", lambda: self.page_action("rotr", cur()), "Ctrl+Shift+R", "rotate_right")
        self.a_pg_up = A("Move page &up", lambda: self.page_action("up", cur()), None, "up")
        self.a_pg_down = A("Move page &down", lambda: self.page_action("down", cur()), None, "down")
        self.a_pg_extract = A("&Extract pages…", self.extract_pages_dialog, None, "save")
        self.a_pg_delete = A("De&lete page", lambda: self.page_action("delete", cur()), None, "delete")
        self.a_about = A("&About Olai", self.about)
        self.a_check_updates = A("Check for &updates…", lambda: self.check_for_updates(manual=True))
        self.a_auto_updates = A("Check for updates when Olai starts", self._toggle_auto_updates, checkable=True)
        self.a_auto_updates.setChecked(self.settings.value("auto_update", True, type=bool))
        self.a_undo_update = A("Undo the last update…", self.undo_update)
        self.a_shortcuts = A("&Keyboard shortcuts", self.shortcuts_help)

        # themes
        self.theme_group = QActionGroup(self)
        self.theme_actions = {}
        for key, label in theme.CHOICES:
            a = QAction(label, self)
            a.setCheckable(True)
            a.triggered.connect(lambda checked=False, k=key: self.set_theme(k))
            self.theme_group.addAction(a)
            self.theme_actions[key] = a
        self.a_dark_pages = A("Dark pages (invert page colours)", self._toggle_dark_pages, "Ctrl+Shift+D",
                              checkable=True)
        self.a_dark_pages.setChecked(self.dark_pages)

        self.tool_group = QActionGroup(self)
        self.tool_actions = {}
        for key, ic, label, tip in TOOLS:
            a = QAction(label, self)
            set_icon(a, ic)
            a.setCheckable(True)
            a.setToolTip(f"{label} — {tip}")
            a.setData(key)
            a.triggered.connect(lambda checked=False, k=key: self.set_tool(k))
            self.tool_group.addAction(a)
            self.tool_actions[key] = a
        self.tool_actions["select"].setChecked(True)
        QShortcut(QKeySequence("Escape"), self, activated=self._escape)

        self.doc_actions = [self.a_save, self.a_save_as, self.a_print, self.a_close, self.a_find,
                            self.a_find_next, self.a_find_prev, self.a_zoom_in, self.a_zoom_out,
                            self.a_fit_w, self.a_fit_p, self.a_goto, self.a_prev, self.a_next,
                            self.a_add_chapter, self.a_add_sub, self.a_add_bookmark, self.a_show_highlights,
                            self.a_pg_blank, self.a_pg_file, self.a_pg_rotl, self.a_pg_rotr, self.a_pg_up,
                            self.a_pg_down, self.a_pg_extract, self.a_pg_delete, self.a_copy,
                            self.a_select_page] + list(self.tool_actions.values())

    def _theme_menu(self, parent):
        m = QMenu("&Theme", parent)
        for key, _ in theme.CHOICES:
            m.addAction(self.theme_actions[key])
        m.addSeparator()
        m.addAction(self.a_dark_pages)
        return m

    def _make_menus(self):
        mb = self.menuBar()
        m = mb.addMenu("&File")
        for a in (self.a_new, self.a_open, self.a_new_window):
            m.addAction(a)
        self.recent_menu = m.addMenu("Open &recent")
        m.addSeparator()
        for a in (self.a_save, self.a_save_as, self.a_print):
            m.addAction(a)
        m.addSeparator()
        m.addAction(self.a_close)
        m.addAction(self.a_exit)
        m = mb.addMenu("&Create")
        m.addAction(self.a_img2pdf)
        m.addAction(self.a_office2pdf)
        m.addAction(self.a_new)
        m = mb.addMenu("&Edit")
        m.addAction(self.a_undo)
        m.addAction(self.a_redo)
        m.addSeparator()
        m.addAction(self.a_copy)
        m.addAction(self.a_select_page)
        m.addSeparator()
        for a in self.tool_actions.values():
            m.addAction(a)
        m.addSeparator()
        m.addAction(self.a_find)
        m.addAction(self.a_find_next)
        m.addAction(self.a_find_prev)
        m = mb.addMenu("&View")
        m.addMenu(self._theme_menu(m))
        m.addSeparator()
        for a in (self.a_sidebar, None, self.a_zoom_in, self.a_zoom_out, self.a_fit_w, self.a_fit_p,
                  None, self.a_goto, None, self.a_next_tab, self.a_prev_tab):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Pages")
        for a in (self.a_pg_blank, self.a_pg_file, None, self.a_pg_rotl, self.a_pg_rotr, self.a_pg_up,
                  self.a_pg_down, None, self.a_pg_extract, self.a_pg_delete):
            m.addSeparator() if a is None else m.addAction(a)
        m = mb.addMenu("&Chapters && Bookmarks")
        m.addAction(self.a_add_chapter)
        m.addAction(self.a_add_sub)
        m.addSeparator()
        m.addAction(self.a_add_bookmark)
        m.addAction(self.a_show_highlights)
        m = mb.addMenu("&Help")
        m.addAction(self.a_check_updates)
        m.addAction(self.a_auto_updates)
        m.addAction(self.a_undo_update)
        m.addSeparator()
        m.addAction(self.a_shortcuts)
        m.addAction(self.a_about)
        m.aboutToShow.connect(lambda: self.a_undo_update.setEnabled(updater.can_undo()))
        # the Olai wordmark, centred in the menu bar row (hidden if the window is too narrow for it)
        self.menu_logo = QLabel(mb)
        self.menu_logo.setObjectName("menuLogo")
        self.menu_logo.setToolTip("Olai")
        self.menu_logo.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        mb.installEventFilter(self)

    def _make_toolbars(self):
        tb = QToolBar("Main")
        tb.setObjectName("main_toolbar")
        tb.setIconSize(QSize(20, 20))
        tb.setMovable(False)
        self.addToolBar(tb)
        tb.addAction(self.a_open)
        tb.addAction(self.a_save)
        tb.addAction(self.a_print)
        tb.addSeparator()
        tb.addAction(self.a_sidebar)
        tb.addSeparator()
        tb.addAction(self.a_prev)
        tb.addAction(self.a_next)
        self.page_edit = QLineEdit()
        self.page_edit.setFixedWidth(52)
        self.page_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.page_edit.setValidator(QIntValidator(1, 999999))
        self.page_edit.returnPressed.connect(self._page_entered)
        tb.addWidget(self.page_edit)
        self.page_total = QLabel(" / 0 ")
        tb.addWidget(self.page_total)
        tb.addSeparator()
        tb.addAction(self.a_zoom_out)
        self.zoom_combo = QComboBox()
        self.zoom_combo.setEditable(True)
        self.zoom_combo.addItems(["Fit width", "Fit page", "50%", "75%", "100%", "125%", "150%", "200%", "300%", "400%"])
        self.zoom_combo.setFixedWidth(104)
        self.zoom_combo.activated.connect(self._zoom_chosen)
        self.zoom_combo.lineEdit().returnPressed.connect(self._zoom_chosen)
        tb.addWidget(self.zoom_combo)
        tb.addAction(self.a_zoom_in)
        tb.addAction(self.a_fit_w)
        tb.addAction(self.a_fit_p)
        tb.addSeparator()
        tb.addAction(self.a_undo)
        tb.addAction(self.a_redo)
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)
        self.quick_search = QLineEdit()
        self.quick_search.setPlaceholderText("Search this document…")
        self.quick_search.setClearButtonEnabled(True)
        set_icon(self.quick_search.addAction(icon("search"), QLineEdit.ActionPosition.LeadingPosition), "search")
        self.quick_search.setFixedWidth(240)
        self.quick_search.returnPressed.connect(self._quick_search)
        tb.addWidget(self.quick_search)
        tb.addAction(self.a_add_bookmark)
        self.theme_btn = QToolButton()
        set_icon(self.theme_btn, "theme")
        self.theme_btn.setToolTip("Theme: Light, Dark grey or Black")
        self.theme_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.theme_btn.setMenu(self._theme_menu(self))
        tb.addWidget(self.theme_btn)

        self.addToolBarBreak()
        tt = QToolBar("Tools")
        tt.setObjectName("tools_toolbar")
        tt.setIconSize(QSize(20, 20))
        tt.setMovable(False)
        tt.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.addToolBar(tt)
        for key, *_ in TOOLS:
            tt.addAction(self.tool_actions[key])
            if key in SEPARATE_AFTER:
                tt.addSeparator()
        tt.addSeparator()
        self.color_btn = QToolButton()
        self.color_btn.setObjectName("colorButton")
        self.color_btn.setText("Colour")
        self.color_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.color_btn.setIconSize(QSize(18, 18))
        self.color_btn.setToolTip("Colour for the current tool")
        self.color_btn.clicked.connect(self._pick_color)
        self.color_btn_action = tt.addWidget(self.color_btn)
        self.tool_hint = QLabel()
        self.tool_hint.setObjectName("toolHint")
        tt.addWidget(self.tool_hint)
        self.tools_toolbar = tt
        self.main_toolbar = tb
        self._update_color_btn()

    def eventFilter(self, obj, ev):
        if obj is self.menuBar() and ev.type() in (QEvent.Type.Resize, QEvent.Type.Show,
                                                    QEvent.Type.LayoutRequest):
            self._place_menu_logo()
        return super().eventFilter(obj, ev)

    def _place_menu_logo(self):
        mb = self.menuBar()
        lbl = getattr(self, "menu_logo", None)
        if lbl is None:
            return
        h = max(14, min(22, mb.height() - 6))
        dpr = self.devicePixelRatioF()
        if getattr(self, "_logo_key", None) != (h, dpr):
            pm = wordmark(h, dpr)
            lbl.setPixmap(pm)
            lbl.resize(int(round(pm.width() / dpr)), int(round(pm.height() / dpr)))
            self._logo_key = (h, dpr)
        x = (mb.width() - lbl.width()) // 2
        y = (mb.height() - lbl.height()) // 2
        last = max((mb.actionGeometry(a).right() for a in mb.actions()), default=0)
        lbl.move(x, y)
        lbl.setVisible(x > last + 24)
        lbl.raise_()

    # ============================================================== tabs
    def _wire(self, tab):
        m, v, s = tab.model, tab.view, tab.side
        m.changed.connect(lambda kind: tab.win._on_doc_changed(tab, kind))
        m.pageChanged.connect(lambda pno: tab.win._on_page_content_changed(tab, pno))
        m.modifiedChanged.connect(lambda _: tab.win._on_modified(tab))
        v.currentPageChanged.connect(lambda p: tab.win._on_current_page(p) if tab.win.tab is tab else None)
        v.zoomChanged.connect(lambda z: tab.win._on_zoom(z) if tab.win.tab is tab else None)
        v.rectDrawn.connect(lambda *a: tab.win._on_rect(*a))
        v.pointClicked.connect(lambda *a: tab.win._on_click(*a))
        v.inkDrawn.connect(lambda *a: tab.win._on_ink(*a))
        v.selectionFinished.connect(lambda tool: tab.win._on_selection(tool))
        v.contextRequested.connect(lambda *a: tab.win._on_context(*a))
        for panel in (s.chapters, s.bookmarks, s.highlights, s.pages):
            panel.navigate.connect(lambda p, y: tab.win._navigate(p, y))
        s.chapters.tocEdited.connect(lambda toc: tab.win._on_toc_edited(toc))
        s.pages.pageMoved.connect(lambda a, b: tab.win._on_page_dragged(a, b))
        s.pages.pageAction.connect(lambda name, p: tab.win.page_action(name, p))
        s.search.searchRequested.connect(lambda *a: tab.win.run_search(*a))
        s.search.stepRequested.connect(lambda d: tab.win.step_search(d))
        s.search.resultChosen.connect(lambda i: tab.win.go_to_hit(i))

    def _new_tab(self):
        tab = DocumentTab(self)
        self._wire(tab)
        self._configure_tab(tab)
        return tab

    def _configure_tab(self, tab):
        """Apply this window's settings (colours, dark pages, side panel) to a tab."""
        tab.win = self
        tab.view.ink_color = _rgb(self.colors["draw"])
        tab.view.highlight_color = QColor(self.colors["highlight"])
        tab.view.laser_color = QColor(self.colors["laser"])
        tab.view.set_dark_pages(self.dark_pages)
        tab.view.set_tool(self.current_tool)
        tab.side.setVisible(self.a_sidebar.isChecked())

    def _add_tab(self, tab, index=-1, activate=True):
        if index is None or index < 0:
            i = self.tabs.addTab(tab, tab.title())
        else:
            i = self.tabs.insertTab(index, tab, tab.title())
        close = QToolButton()
        close.setObjectName("tabClose")
        close.setAutoRaise(True)
        set_icon(close, "close")
        close.setIconSize(QSize(12, 12))
        close.setFixedSize(20, 20)
        close.setToolTip("Close tab (Ctrl+W)")
        close.setCursor(Qt.CursorShape.PointingHandCursor)
        close.clicked.connect(lambda checked=False, t=tab: t.win.close_tab(t))
        self.tabbar.setTabButton(i, QTabBar.ButtonPosition.RightSide, close)
        self._update_tab_title(tab)
        if activate:
            self.tabs.setCurrentIndex(i)
        self._sync_ui()
        return i

    def _update_tab_title(self, tab):
        i = self.tabs.indexOf(tab)
        if i < 0:
            return
        self.tabs.setTabText(i, tab.title())
        path = tab.model.path or tab.model.source_path
        self.tabs.setTabToolTip(i, path or tab.model.display_name)

    def _take_tab(self, tab):
        i = self.tabs.indexOf(tab)
        if i >= 0:
            self.tabs.removeTab(i)
        self._sync_ui()

    def close_tab(self, tab=None):
        tab = tab if isinstance(tab, DocumentTab) else self.tabs.currentWidget()
        if tab is None:
            return True
        self.tabs.setCurrentWidget(tab)
        if not self._maybe_save():
            return False
        self._take_tab(tab)
        tab.model.close()
        tab.deleteLater()
        if self.tabs.count() == 0 and len(WINDOWS) > 1 and not self._closing:
            QTimer.singleShot(0, self.close)
        return True

    def close_other_tabs(self, keep):
        for t in self.all_tabs():
            if t is not keep and not self.close_tab(t):
                return

    def _cycle_tab(self, d):
        n = self.tabs.count()
        if n > 1:
            self.tabs.setCurrentIndex((self.tabs.currentIndex() + d) % n)

    def detach_tab(self, tab, global_pos=None):
        """Move a tab into a new window of its own."""
        if self.tabs.indexOf(tab) < 0 or self.tabs.count() <= 1:
            return None
        self._take_tab(tab)
        w = MainWindow()
        w.resize(self.size())
        w.adopt_tab(tab)
        if global_pos is not None:
            w.move(global_pos - QPoint(120, 40))
        w.show()
        w.bring_to_front()
        return w

    def adopt_tab(self, tab, index=-1):
        self._configure_tab(tab)
        self._add_tab(tab, index)
        tab.view.apply_theme()

    def receive_tab_drop(self, payload, at_index=-1):
        try:
            wid, uid = (int(x) for x in payload.split(":"))
        except ValueError:
            return
        src = find_window_by_id(wid)
        if src is None:
            return
        tab = next((t for t in src.all_tabs() if t.uid == uid), None)
        if tab is None:
            return
        if src is self:
            return
        src._take_tab(tab)
        self.adopt_tab(tab, at_index)
        self.bring_to_front()
        if src.tabs.count() == 0:
            QTimer.singleShot(0, src.close)

    def new_window(self):
        w = MainWindow()
        w.resize(self.size())
        w.move(self.pos() + QPoint(40, 40))
        w.show()
        return w

    def bring_to_front(self):
        if self.isMinimized():
            self.showNormal()
        self.show()
        self.raise_()
        self.activateWindow()

    # ============================================================== utilities
    def _show_panel(self, name, then=None):
        if not self.a_sidebar.isChecked():
            self.a_sidebar.setChecked(True)
            self.toggle_sidebar()
        self.side.show_panel(name)
        if then:
            then()

    def toggle_sidebar(self):
        show = self.a_sidebar.isChecked()
        for t in self.all_tabs():
            t.side.setVisible(show)
            if show:
                sizes = t.splitter.sizes()
                if sizes[0] < 150:
                    t.splitter.setSizes([340, max(400, sum(sizes) - 340)])

    def _update_title(self):
        if self.model.is_open:
            star = "•" if self.model.modified else ""
            self.setWindowTitle(f"{star}{self.model.display_name} — {APP_NAME}")
        else:
            self.setWindowTitle(APP_NAME)

    def _update_actions(self):
        open_ = self.model.is_open
        for a in self.doc_actions:
            a.setEnabled(open_)
        self.a_undo.setEnabled(open_ and self.model.can_undo())
        self.a_redo.setEnabled(open_ and self.model.can_redo())
        self.a_undo.setToolTip(f"Undo {self.model.undo_text()} (Ctrl+Z)" if self.model.can_undo() else "Undo (Ctrl+Z)")
        self.a_redo.setToolTip(f"Redo {self.model.redo_text()} (Ctrl+Y)" if self.model.can_redo() else "Redo (Ctrl+Y)")
        self.quick_search.setEnabled(open_)
        self.page_edit.setEnabled(open_)
        self.zoom_combo.setEnabled(open_)
        self.tools_toolbar.setEnabled(open_)
        self.stack.setCurrentIndex(1 if self.tabs.count() else 0)

    def _sync_ui(self):
        """Refresh everything that shows the current tab (after switching tabs)."""
        tab = self.tab
        if tab is not self._empty:
            tab.view.set_tool(self.current_tool)
        self.page_total.setText(f" / {self.model.page_count} ")
        self._on_current_page(self.view.current_page() if self.model.is_open else -1)
        if self.model.is_open:
            self._on_zoom(self.view.zoom)
        else:
            self.zoom_combo.setEditText("")
        self.quick_search.setText(tab.search_phrase)
        self._update_actions()
        self._update_title()

    def msg(self, text, ms=5000):
        self.statusBar().showMessage(text, ms)

    def _error(self, title, text):
        QMessageBox.warning(self, title, text)

    # ============================================================ open / save
    def open_dialog(self):
        start = self.settings.value("last_dir", os.path.expanduser("~"))
        paths, _ = QFileDialog.getOpenFileNames(self, "Open", start, OPEN_FILTER)
        imgs = [p for p in paths if os.path.splitext(p)[1].lower() in convert.IMAGE_EXT]
        if len(imgs) > 1 and len(imgs) == len(paths):
            self.images_to_pdf(imgs)
            return
        for p in paths:
            self.open_path(p)

    def open_path(self, path):
        if not path:
            return False
        if not os.path.exists(path):
            self._error("Open", f"This file no longer exists:\n{path}")
            self._remove_recent(path)
            return False
        win, tab = find_open(path)
        if tab is not None:                    # already open: just show it
            win.tabs.setCurrentWidget(tab)
            win.bring_to_front()
            return True
        self.settings.setValue("last_dir", os.path.dirname(path))
        ext = os.path.splitext(path)[1].lower()
        if ext in convert.IMAGE_EXT:
            return self.images_to_pdf([path])
        if ext in convert.WORD_EXT or ext in convert.PPT_EXT:
            return self._open_office(path)
        return self._open_pdf(path)

    def _open_pdf(self, path):
        try:
            data = DocumentModel.read_file(path)
        except OSError as e:
            self._error("Open", f"Couldn't read the file:\n{e}")
            return False
        tab = self._new_tab()
        password = None
        while True:
            try:
                tab.model.load_bytes(data, os.path.basename(path), path=path, password=password)
                break
            except PermissionError:
                password, ok = QInputDialog.getText(
                    self, "Password needed",
                    f"“{os.path.basename(path)}” is protected." + (" That password didn't work." if password else "")
                    + "\nEnter its password:", QLineEdit.EchoMode.Password)
                if not ok:
                    tab.deleteLater()
                    return False
            except Exception as e:
                tab.deleteLater()
                self._error("Open", f"This doesn't look like a PDF that can be opened.\n\n{e}")
                return False
        self._add_tab(tab)
        self._add_recent(path)
        return True

    def _run_busy(self, text, fn):
        dlg = QProgressDialog(text, None, 0, 0, self)
        dlg.setWindowTitle(APP_NAME)
        dlg.setWindowModality(Qt.WindowModality.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.show()
        w = _Worker(fn)
        w.start()
        while not w.wait(40):
            QApplication.processEvents()
        dlg.close()
        if w.error is not None:
            raise w.error
        return w.result

    def _convert_office(self, path):
        """Returns (pdf_path, method). Office runs in the background; the built-in fallback on this thread."""
        ext = os.path.splitext(path)[1].lower()
        kind = "word" if ext in convert.WORD_EXT else "powerpoint"
        out = os.path.join(tempfile.mkdtemp(prefix="olai_"), os.path.splitext(os.path.basename(path))[0] + ".pdf")
        app_name = "Word" if kind == "word" else "PowerPoint"
        if convert.office_available(kind):
            try:
                self._run_busy(f"Converting with Microsoft {app_name}…",
                               lambda: convert._office_convert(path, out, kind))
                return out, "office"
            except Exception as e:
                self.msg(f"Microsoft {app_name} couldn't convert it ({e}); using the basic view.", 9000)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if kind == "word":
                convert.docx_to_pdf_basic(path, out)
            else:
                convert.pptx_to_pdf_basic(path, out)
        finally:
            QApplication.restoreOverrideCursor()
        return out, "basic"

    def _open_office(self, path):
        try:
            pdf, method = self._convert_office(path)
            data = DocumentModel.read_file(pdf)
        except Exception as e:
            self._error("Open", f"Couldn't open “{os.path.basename(path)}”.\n\n{e}")
            return False
        kind = "Word" if os.path.splitext(path)[1].lower() in convert.WORD_EXT else "PowerPoint"
        if method == "office":
            note = (f"<b>Converted from {kind}</b> — you're viewing a PDF copy of “{os.path.basename(path)}”. "
                    "The original file isn't changed. Use <i>Save as PDF</i> to keep this copy.")
        else:
            note = (f"<b>Basic view</b> — Microsoft {kind} isn't installed, so layout, fonts and designs are "
                    f"simplified. The original “{os.path.basename(path)}” isn't changed.")
        name = os.path.splitext(os.path.basename(path))[0] + ".pdf"
        tab = self._new_tab()
        tab.model.load_bytes(data, name, path=None, source_path=path, note=note)
        self._add_tab(tab)
        self._add_recent(path)
        return True

    def _maybe_save(self):
        if not self.model.is_open or not self.model.modified:
            return True
        r = QMessageBox.question(
            self, APP_NAME, f"Save changes to “{self.model.display_name}”?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Save)
        if r == QMessageBox.StandardButton.Save:
            return self.save()
        return r == QMessageBox.StandardButton.Discard

    def save(self):
        if not self.model.is_open:
            return False
        if self.model.path is None:
            return self.save_as()
        return self._save_to(self.model.path)

    def save_as(self):
        if not self.model.is_open:
            return False
        base = self.model.path or self.model.source_path
        folder = os.path.dirname(base) if base else self.settings.value("last_dir", os.path.expanduser("~"))
        name = os.path.splitext(self.model.display_name or "Untitled")[0] + ".pdf"
        path, _ = QFileDialog.getSaveFileName(self, "Save PDF as", os.path.join(folder, name), "PDF (*.pdf)")
        if not path:
            return False
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        return self._save_to(path)

    def _save_to(self, path):
        tab = self.tab
        old_key = self.model.bookmark_key()
        try:
            self.model.save(path)
        except Exception as e:
            self._error("Save", f"Couldn't save the PDF.\n\n{e}\n\nIf it's open in another program, close it there "
                                "or use Save as… to pick a new name.")
            return False
        new_key = self.model.bookmark_key()
        if old_key != new_key:
            self.bookmarks.move(old_key, new_key)
            self.highlights_store.move(old_key, new_key)
        self.side.bookmarks.load(new_key)
        self.side.highlights.load(new_key)
        self.banner.hide()
        self._add_recent(path)
        self._update_tab_title(tab)
        self._update_title()
        self.msg(f"Saved {os.path.basename(path)}")
        return True

    def close_doc(self):
        self.close_tab()

    def closeEvent(self, event):
        self._closing = True
        for t in self.all_tabs():
            self.tabs.setCurrentWidget(t)
            if not self._maybe_save():
                self._closing = False
                event.ignore()
                return
        if len(WINDOWS) == 1:
            self.settings.setValue("geometry", self.saveGeometry())
        for t in self.all_tabs():
            t.model.close()
        if self in WINDOWS:
            WINDOWS.remove(self)
        try:
            theme.notifier.changed.disconnect(self._on_theme_changed)
        except (RuntimeError, TypeError):
            pass
        event.accept()

    # recent files
    def _recent(self):
        v = self.settings.value("recent", [])
        if isinstance(v, str):
            v = [v]
        return [p for p in (v or []) if p]

    def _add_recent(self, path):
        r = [p for p in self._recent() if os.path.normcase(p) != os.path.normcase(path)]
        r.insert(0, path)
        self.settings.setValue("recent", r[:12])
        for w in WINDOWS:
            w._refresh_recent()

    def _remove_recent(self, path):
        self.settings.setValue("recent", [p for p in self._recent() if p != path])
        for w in WINDOWS:
            w._refresh_recent()

    def _refresh_recent(self):
        self.recent_menu.clear()
        self.recent_list.clear()
        recent = self._recent()
        for p in recent:
            self.recent_menu.addAction(os.path.basename(p), lambda p=p: self.open_path(p))
            it = QListWidgetItem(icon("open"), f"{os.path.basename(p)}   —   {os.path.dirname(p)}")
            it.setToolTip(p)
            it.setData(Qt.ItemDataRole.UserRole, p)
            self.recent_list.addItem(it)
        self.recent_menu.setEnabled(bool(recent))
        self.recent_label.setVisible(bool(recent))
        self.recent_list.setVisible(bool(recent))

    # drag & drop
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls() or e.mimeData().hasFormat(TAB_MIME):
            e.acceptProposedAction()

    def dropEvent(self, e):
        if e.mimeData().hasFormat(TAB_MIME):
            self.receive_tab_drop(bytes(e.mimeData().data(TAB_MIME)).decode())
            e.acceptProposedAction()
            return
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if not paths:
            return
        imgs = [p for p in paths if os.path.splitext(p)[1].lower() in convert.IMAGE_EXT]
        if len(imgs) == len(paths) and len(imgs) > 1:
            self.images_to_pdf(imgs)
        else:
            for p in paths:
                self.open_path(p)

    # ================================================================= create
    def new_pdf(self):
        d = NewPdfDialog(self)
        if not d.exec():
            return
        size, landscape, n = d.values()
        w, h = convert.PAPER[size]
        if landscape:
            w, h = h, w
        doc = fitz.open()
        for _ in range(n):
            doc.new_page(width=w, height=h)
        tab = self._new_tab()
        tab.model.load_document(doc, "Untitled.pdf", note=None, modified=True)
        self._add_tab(tab)

    def images_to_pdf(self, paths=None):
        d = ImagesToPdfDialog(self, paths if isinstance(paths, list) else None)
        if not paths:
            d.add()
            if d.list.count() == 0:
                return False
        if not d.exec():
            return False
        paths, size, margin, shrink = d.values()
        prog = QProgressDialog("Adding photos…", "Cancel", 0, len(paths), self)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(300)

        def step(i):
            prog.setValue(i)
            QApplication.processEvents()
            return not prog.wasCanceled()
        try:
            doc = convert.images_to_pdf(paths, size, margin, shrink, progress=step)
        except Exception as e:
            prog.close()
            self._error("Photos to PDF", f"Couldn't read one of the photos.\n\n{e}")
            return False
        prog.close()
        if doc.page_count == 0:
            return False
        first = os.path.splitext(os.path.basename(paths[0]))[0]
        tab = self._new_tab()
        tab.model.load_document(doc, f"{first}.pdf", source_path=None,
                                note=f"<b>New PDF from {len(paths)} photo(s)</b> — not saved yet.")
        self._add_tab(tab)
        return True

    def office_to_pdf_dialog(self):
        start = self.settings.value("last_dir", os.path.expanduser("~"))
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Choose Word or PowerPoint files", start,
            "Word or PowerPoint (*.doc *.docx *.rtf *.odt *.ppt *.pptx *.pps *.ppsx *.odp)")
        if not paths:
            return
        import shutil
        if len(paths) == 1:
            src = paths[0]
            try:
                pdf, method = self._convert_office(src)
            except Exception as e:
                self._error("Convert", f"Couldn't convert “{os.path.basename(src)}”.\n\n{e}")
                return
            default = os.path.splitext(src)[0] + ".pdf"
            out, _ = QFileDialog.getSaveFileName(self, "Save PDF as", default, "PDF (*.pdf)")
            if not out:
                return
            try:
                shutil.copyfile(pdf, out)
            except OSError as e:
                self._error("Convert", f"Couldn't save the PDF.\n\n{e}")
                return
            note = "" if method == "office" else "\n\n(Microsoft Office isn't installed, so this is a basic conversion.)"
            r = QMessageBox.question(self, "Converted", f"Saved {os.path.basename(out)}.{note}\n\nOpen it now?")
            if r == QMessageBox.StandardButton.Yes:
                self.open_path(out)
            return
        folder = QFileDialog.getExistingDirectory(self, "Save the PDFs in which folder?", os.path.dirname(paths[0]))
        if not folder:
            return
        done, failed = 0, []
        for src in paths:
            try:
                pdf, _ = self._convert_office(src)
                shutil.copyfile(pdf, os.path.join(folder, os.path.splitext(os.path.basename(src))[0] + ".pdf"))
                done += 1
            except Exception as e:
                failed.append(f"{os.path.basename(src)}: {e}")
        text = f"Converted {done} of {len(paths)} file(s) into {folder}."
        if failed:
            text += "\n\nProblems:\n" + "\n".join(failed)
        QMessageBox.information(self, "Convert", text)
        QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    # =========================================================== doc events
    def _on_doc_changed(self, tab, kind):
        doc = tab.model.doc
        if kind == "loaded":
            tab.view.fit_mode = "width"
            tab.view.rebuild(keep_position=False)
            tab.side.chapters.load(doc)
            tab.side.pages.load(doc)
            key = tab.model.bookmark_key()
            tab.side.bookmarks.load(key)
            tab.side.highlights.load(key)
            self._clear_search(tab)
            if tab.model.note:
                tab.banner_label.setText(tab.model.note)
                tab.banner.show()
            else:
                tab.banner.hide()
            if doc is not None and doc.get_toc():
                tab.side.show_panel("chapters")
        elif kind in ("structure", "content"):
            tab.view.rebuild(keep_position=True)
            tab.side.chapters.load(doc)
            tab.side.pages.load(doc)
            if tab.hits and kind == "structure":
                self._clear_search(tab)
                tab.side.search.show_status("The document changed — search again to update the results.")
        elif kind == "toc":
            if not tab.own_toc_edit:
                tab.side.chapters.load(doc)
        self._update_tab_title(tab)
        if tab is self.tab:
            self._sync_ui()

    def _on_page_content_changed(self, tab, pno):
        tab.view.invalidate_page(pno)
        tab.side.pages.refresh_page(pno)
        if tab is self.tab:
            self._update_actions()

    def _on_modified(self, tab):
        self._update_tab_title(tab)
        if tab is self.tab:
            self._update_title()

    def _on_current_page(self, pno):
        if pno < 0:
            self.page_edit.setText("")
            self.status_page.setText("")
            return
        self.page_edit.setText(str(pno + 1))
        self.status_page.setText(f"Page {pno + 1} of {self.model.page_count}   ")
        self.side.pages.select(pno)

    def _on_zoom(self, z):
        if self.view.fit_mode == "width":
            txt = "Fit width"
        elif self.view.fit_mode == "page":
            txt = "Fit page"
        else:
            txt = f"{round(z * 100)}%"
        self.zoom_combo.setEditText(txt)

    def _zoom_chosen(self, *_):
        t = self.zoom_combo.currentText().strip().lower()
        if t.startswith("fit w"):
            self.view.fit_width()
        elif t.startswith("fit p"):
            self.view.fit_page()
        else:
            try:
                self.view.set_zoom(float(t.rstrip("%").strip()) / 100)
            except ValueError:
                self._on_zoom(self.view.zoom)
        self.view.setFocus()

    def _page_entered(self):
        try:
            self.view.go_to_page(int(self.page_edit.text()) - 1)
        except ValueError:
            pass
        self.view.setFocus()

    def goto_dialog(self):
        n, ok = QInputDialog.getInt(self, "Go to page", f"Page (1–{self.model.page_count}):",
                                    self.view.current_page() + 1, 1, max(1, self.model.page_count))
        if ok:
            self.view.go_to_page(n - 1)

    def _navigate(self, page, y):
        self.view.go_to_page(page, y=y)
        self.view.setFocus()

    def undo(self):
        self.model.undo()
        self.msg("Undone")

    def redo(self):
        self.model.redo()

    # ================================================================ search
    def focus_search(self):
        self._show_panel("search")
        sel = self.quick_search.text()
        if sel and not self.side.search.edit.text():
            self.side.search.edit.setText(sel)
        self.side.search.edit.setFocus()
        self.side.search.edit.selectAll()

    def _quick_search(self):
        text = self.quick_search.text().strip()
        if not text:
            return
        self._show_panel("search")
        self.side.search.edit.setText(text)
        self.run_search(text, self.side.search.case.isChecked(), self.side.search.whole.isChecked())

    def _clear_search(self, tab=None):
        tab = tab or self.tab
        tab.hits = []
        tab.hit_index = -1
        tab.view.clear_search_highlights()
        tab.side.search.set_results([], "")
        tab.side.search.show_status("")

    def run_search(self, phrase, match_case=False, whole_word=False):
        phrase = phrase.strip()
        if not self.model.is_open or not phrase:
            return
        self._search_phrase = phrase
        self.quick_search.setText(phrase)
        doc = self.model.doc
        prog = None
        if doc.page_count > 40:
            prog = QProgressDialog("Searching…", "Stop", 0, doc.page_count, self)
            prog.setWindowModality(Qt.WindowModality.WindowModal)
            prog.setMinimumDuration(400)

        def step(pno):
            if prog is None:
                return True
            prog.setValue(pno)
            QApplication.processEvents()
            return not prog.wasCanceled()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            results = find_all(doc, phrase, match_case, whole_word, progress=step)
        finally:
            QApplication.restoreOverrideCursor()
            if prog is not None:
                prog.close()
        self.hits = [(r["page"], r["rect"]) for r in results]
        self.side.search.set_results(results, phrase)
        if results:
            pages = sorted({r["page"] for r in results})
            if len(pages) <= 6:
                where = "page " + ", ".join(str(p + 1) for p in pages) if len(pages) == 1 else \
                    "pages " + ", ".join(str(p + 1) for p in pages)
            else:
                where = f"{len(pages)} pages"
            times = "once" if len(results) == 1 else f"{len(results)} times"
            self.side.search.show_status(f"✓  Found “{phrase}” {times}, on {where}.", "found")
            cur = max(0, self.view.current_page())
            start = next((i for i, (p, _) in enumerate(self.hits) if p >= cur), 0)
            self.view.show_search_hits(self.hits, start)
            self.hit_index = start
            self.side.search.select_row(start)
            self.msg(f"Match {start + 1} of {len(self.hits)}")
        else:
            self.view.clear_search_highlights()
            extra = ""
            if not has_text_layer(doc):
                extra = ("\n\nThis PDF has no searchable text — its pages are probably scanned pictures, "
                         "so words in them can't be found.")
            self.side.search.show_status(f"✗  “{phrase}” is not in this document.{extra}", "missing")
            self.hit_index = -1

    def step_search(self, d):
        if not self.hits:
            if self._search_phrase:
                self.run_search(self._search_phrase, self.side.search.case.isChecked(),
                                self.side.search.whole.isChecked())
            else:
                self.focus_search()
            return
        self.go_to_hit((self.hit_index + d) % len(self.hits))

    def go_to_hit(self, index):
        if not (0 <= index < len(self.hits)):
            return
        self.hit_index = index
        self.view.set_current_hit(self.hits, index)
        self.side.search.select_row(index)
        self.msg(f"Match {index + 1} of {len(self.hits)}")

    # ================================================================ tools
    def set_tool(self, key):
        if self.current_tool == "laser" and key != "laser":
            for t in self.all_tabs():
                t.view.clear_laser()
        self.current_tool = key
        self.tool_actions[key].setChecked(True)
        self.view.set_tool(key)
        tip = next(t[3] for t in TOOLS if t[0] == key)
        self.tool_hint.setText(tip)
        self._update_color_btn()
        if key == "signature" and self.model.is_open:
            if not self._ask_signature():
                self.set_tool("select")

    def _escape(self):
        v = self.view
        if v._laser_items or v.has_selection():
            v.clear_laser()
            v.clear_selection()
        else:
            self.set_tool("select")

    def _update_color_btn(self):
        tool = self.current_tool
        visible = tool in self.colors
        self.color_btn_action.setVisible(visible)
        if visible:
            self.color_btn.setIcon(dot_icon(self.colors[tool], 18))

    def _presets(self, tool):
        return HIGHLIGHTER if tool == "highlight" else PEN

    def _pick_color(self):
        tool = self.current_tool
        if tool not in self.colors:
            return
        pick_color(self.color_btn, self.colors[tool], lambda c, t=tool: self.set_tool_color(t, c.name()),
                   presets=self._presets(tool), title=COLOR_TITLES.get(tool, "Pen colours"))

    def set_tool_color(self, tool, hexcolor):
        self.colors[tool] = hexcolor
        self.settings.setValue(f"color/{tool}", hexcolor)
        for t in self.all_tabs():
            t.view.ink_color = _rgb(self.colors["draw"])
            t.view.highlight_color = QColor(self.colors["highlight"])
            t.view.laser_color = QColor(self.colors["laser"])
            t.view.refresh_cursor()
        self._update_color_btn()

    def _ask_signature(self):
        d = SignatureDialog(self)
        if d.exec() and d.result_png:
            self._signature = d.result_png
            self.msg("Now drag a box on the page where the signature should go.", 8000)
            return True
        return False

    # ---------------------------------------------------- text selection
    def copy_selection(self):
        text = self.view.selected_text()
        if text:
            QGuiApplication.clipboard().setText(text)
            self.msg(f"Copied {len(text)} characters.")
        else:
            self.msg("Select some text first: drag over it with the Select tool.")

    def select_page_text(self):
        if self.current_tool not in ("select", "highlight"):
            self.set_tool("select")
        p = max(0, self.view.current_page())
        self.view.select_page_text(p)
        if not self.view.has_selection():
            self.msg("This page has no selectable text (it's probably a scanned picture).")

    def _on_selection(self, tool):
        if tool == "highlight":
            self.highlight_selection()
        else:
            n = len(self.view.selected_text())
            self.msg(f"Selected {n} characters — Ctrl+C copies, right-click for more.", 6000)

    def highlight_selection(self, add_to_list=False, color=None):
        view = self.view
        ranges = view.selection_ranges()
        if not ranges:
            return
        color = color or self.colors["highlight"]
        per_page = {}
        for p, (i0, i1) in ranges.items():
            layer = view.text_layer(p)
            rects = layer.line_rects(i0, i1)
            if rects:
                per_page[p] = (rects, layer.text(i0, i1))
        if not per_page:
            return

        def fn(d):
            for p, (rects, _) in per_page.items():
                page = d[p]                      # keep the page alive while using its annotation
                a = page.add_highlight_annot([fitz.Rect(r) for r in rects])
                a.set_colors(stroke=_rgb(color))
                a.update()
        pages = list(per_page)
        if len(pages) == 1:
            self.model.edit("highlight", fn, page=pages[0])
        else:
            self.model.edit("highlight", fn, kind="content")
        view.clear_selection()
        if add_to_list:
            for p, (rects, text) in per_page.items():
                self._add_highlight_entry(p, rects, text, color)

    def _add_highlight_entry(self, pno, rects, text, color):
        entry = {"id": uuid.uuid4().hex[:12], "page": pno, "rects": [list(fitz.Rect(r)) for r in rects],
                 "text": text.strip(), "color": color, "note": "", "added": int(time.time())}
        if self.side.highlights.add(entry):
            self.msg("Added to Highlights (left panel).", 5000)
            if self.a_sidebar.isChecked() is False:
                self.a_sidebar.setChecked(True)
                self.toggle_sidebar()

    # ---------------------------------------------------- annotations
    def _annot_at(self, pno, pt, types=None):
        """The topmost annotation under a (unrotated) point: dict with xref, type, rect, color, text."""
        if pno < 0 or pt is None or self.model.doc is None:
            return None
        page = self.model.doc[pno]
        vis = pt * page.rotation_matrix
        found = None
        for a in page.annots():
            t = a.type[0]
            if t in (fitz.PDF_ANNOT_LINK, fitz.PDF_ANNOT_WIDGET, fitz.PDF_ANNOT_POPUP):
                continue
            if types is not None and t not in types:
                continue
            r = a.rect
            grown = fitz.Rect(r.x0 - 3, r.y0 - 3, r.x1 + 3, r.y1 + 3)
            if pt in grown or vis in grown:
                found = a
        if found is None:
            return None
        colors = found.colors or {}
        info = {"xref": found.xref, "type": found.type[0], "rect": fitz.Rect(found.rect),
                "color": _hex(colors.get("stroke") or colors.get("fill")) or "#ffd400", "rects": [], "text": ""}
        if info["type"] == fitz.PDF_ANNOT_HIGHLIGHT:
            v = found.vertices or []
            for i in range(0, len(v) - 3, 4):
                q = fitz.Quad(v[i], v[i + 1], v[i + 2], v[i + 3])
                info["rects"].append(q.rect)
            info["text"] = " ".join(page.get_textbox(r).strip() for r in info["rects"]).strip()
            if not info["rects"]:
                info["rects"] = [info["rect"]]
        return info

    def _recolor_annot(self, pno, info, hexcolor):
        xref, kind = info["xref"], info["type"]

        def fn(d):
            page = d[pno]
            for a in page.annots():
                if a.xref == xref:
                    if kind == fitz.PDF_ANNOT_FREE_TEXT:
                        a.update(text_color=_rgb(hexcolor))
                    else:
                        a.set_colors(stroke=_rgb(hexcolor))
                        a.update()
                    break
        self.model.edit("colour", fn, page=pno)
        if kind == fitz.PDF_ANNOT_HIGHLIGHT:
            self.side.highlights.recolor(pno, info["rect"], hexcolor)

    def _delete_annot(self, pno, info):
        xref = info["xref"]

        def fn(d):
            p = d[pno]
            for a in p.annots():
                if a.xref == xref:
                    p.delete_annot(a)
                    break
        self.model.edit("remove", fn, page=pno)
        if info["type"] == fitz.PDF_ANNOT_HIGHLIGHT:
            self.side.highlights.remove_at(pno, info["rect"])

    # ---------------------------------------------------- right-click menus
    def _swatch_row(self, menu, presets, current, on_pick, more_title):
        """A row of colour dots inside a menu, plus a 'More colours…' entry."""
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(26, 4, 12, 4)
        h.setSpacing(6)
        for col in presets:
            s = Swatch(col, 22, True, current=(QColor(col).name().lower() == (current or "").lower()))
            s.clicked.connect(lambda checked=False, c=col: (menu.close(), on_pick(c)))
            h.addWidget(s)
        h.addStretch(1)
        wa = QWidgetAction(menu)
        wa.setDefaultWidget(w)
        menu.addAction(wa)
        gpos = QCursor.pos()
        menu.addAction("More colours…", lambda: pick_color(None, current, lambda c: on_pick(c.name()),
                                                            presets=presets, title=more_title,
                                                            global_pos=gpos))

    def _on_context(self, tool, pno, pt, gpos):
        if not self.model.is_open:
            return
        menu = QMenu(self)
        view = self.view
        if tool in ("select", "highlight") and view.has_selection():
            menu.addAction(icon("copy"), "Copy", self.copy_selection)
            menu.addAction(icon("highlight"), "Highlight", lambda: self.highlight_selection())
            menu.addAction(icon("highlights"), "Highlight and add to Highlights",
                           lambda: self.highlight_selection(add_to_list=True))
            snippet = " ".join(view.selected_text().split())
            if snippet:
                short = snippet[:28] + ("…" if len(snippet) > 28 else "")
                menu.addAction(icon("search"), f"Search for “{short}”",
                               lambda s=snippet: (self._show_panel("search"),
                                                  self.side.search.edit.setText(s[:200]), self.run_search(s[:200])))
            menu.addSeparator()
        if tool == "highlight":
            info = self._annot_at(pno, pt, TOOL_ANNOTS["highlight"])
            if info is not None:
                head = menu.addAction("This highlight")
                head.setEnabled(False)
                self._swatch_row(menu, HIGHLIGHTER, info["color"],
                                 lambda c, i=info: self._recolor_annot(pno, i, c), "Highlight colour")
                menu.addSeparator()
                if self.side.highlights.find(pno, info["rect"]) >= 0:
                    menu.addAction(icon("highlights"), "Remove from Highlights",
                                   lambda: self.side.highlights.remove_at(pno, info["rect"]))
                else:
                    menu.addAction(icon("highlights"), "Add to Highlights",
                                   lambda i=info: self._add_highlight_entry(pno, i["rects"], i["text"], i["color"]))
                if info["text"]:
                    menu.addAction(icon("copy"), "Copy highlighted text",
                                   lambda t=info["text"]: QGuiApplication.clipboard().setText(t))
                menu.addAction(icon("delete"), "Remove highlight", lambda i=info: self._delete_annot(pno, i))
            elif not view.has_selection():
                head = menu.addAction("Highlighter colour")
                head.setEnabled(False)
                self._swatch_row(menu, HIGHLIGHTER, self.colors["highlight"],
                                 lambda c: self.set_tool_color("highlight", c), "Highlighter colour")
        elif tool in ("draw", "rect", "note", "text"):
            info = self._annot_at(pno, pt, TOOL_ANNOTS[tool])
            if info is not None:
                head = menu.addAction("This mark's colour")
                head.setEnabled(False)
                self._swatch_row(menu, PEN, info["color"], lambda c, i=info: self._recolor_annot(pno, i, c), "Colour")
                menu.addSeparator()
                menu.addAction(icon("delete"), "Remove it", lambda i=info: self._delete_annot(pno, i))
            else:
                head = menu.addAction(f"{dict((k, l) for k, _, l, _ in TOOLS)[tool]} colour")
                head.setEnabled(False)
                self._swatch_row(menu, PEN, self.colors[tool], lambda c: self.set_tool_color(tool, c), "Colour")
        elif tool == "select" and not view.has_selection() and pno >= 0:
            menu.addAction("Select all text on this page", lambda: (view.select_page_text(pno)))
        if menu.isEmpty():
            return
        show_menu(menu, gpos)

    # ---------------------------------------------------- tool results
    def _on_rect(self, tool, pno, rect):
        color = _rgb(self.colors.get(tool, "#d61f1f"))
        if tool == "highlight":            # pages without text: highlight the dragged area
            def fn(d):
                page = d[pno]
                words = [fitz.Rect(w[:4]) for w in page.get_text("words") if fitz.Rect(w[:4]).intersects(rect)]
                a = page.add_highlight_annot(words if words else rect)
                a.set_colors(stroke=color)
                a.update()
            self.model.edit("highlight", fn, page=pno)
        elif tool == "rect":
            def fn(d):
                page = d[pno]
                a = page.add_rect_annot(rect)
                a.set_colors(stroke=color)
                a.set_border(width=1.6)
                a.update()
            self.model.edit("box", fn, page=pno)
        elif tool == "image":
            start = self.settings.value("last_img_dir", os.path.expanduser("~"))
            exts = " ".join("*" + e for e in sorted(convert.IMAGE_EXT))
            path, _ = QFileDialog.getOpenFileName(self, "Choose a picture", start, f"Images ({exts})")
            if not path:
                return
            self.settings.setValue("last_img_dir", os.path.dirname(path))
            try:
                data = convert.load_image_bytes(path)
            except Exception as e:
                self._error("Picture", f"Couldn't read that picture.\n\n{e}")
                return
            self.model.edit("picture", lambda d: d[pno].insert_image(rect, stream=data, keep_proportion=True),
                            page=pno)
        elif tool == "signature":
            if not self._signature and not self._ask_signature():
                return
            data, ratio = self._signature
            w, h = rect.width, rect.height
            if w / max(h, 1) > ratio:
                r = fitz.Rect(rect.x0, rect.y0, rect.x0 + h * ratio, rect.y1)
            else:
                r = fitz.Rect(rect.x0, rect.y0, rect.x1, rect.y0 + w / ratio)
            self.model.edit("signature", lambda d: d[pno].insert_image(r, stream=data, keep_proportion=True),
                            page=pno)

    def _on_click(self, tool, pno, pt):
        if tool == "text":
            d = TextDialog(self, int(self.settings.value("text_size", 12)), self.colors["text"])
            if not d.exec():
                return
            text, size, color = d.values()
            if not text.strip():
                return
            self.settings.setValue("text_size", size)
            self.colors["text"] = QColor.fromRgbF(*color).name()
            self.settings.setValue("color/text", self.colors["text"])
            self.model.edit("text", lambda dd: add_text(dd[pno], pt, text, size, color), page=pno)
        elif tool == "note":
            text, ok = QInputDialog.getMultiLineText(self, "Sticky note", "Comment:")
            if not ok or not text.strip():
                return
            color = _rgb(self.colors["note"])

            def fn(d):
                page = d[pno]
                a = page.add_text_annot(pt, text, icon="Note")
                a.set_colors(stroke=color)
                a.set_info(title=os.environ.get("USERNAME", ""))
                a.update()
            self.model.edit("note", fn, page=pno)
        elif tool == "erase":
            info = self._annot_at(pno, pt)
            if info is None:
                self.msg("Nothing to remove there. Pictures and signatures become part of the page — "
                         "use Undo (Ctrl+Z) to take them back.", 9000)
                return
            self._delete_annot(pno, info)

    def _on_ink(self, pno, pts):
        color = _rgb(self.colors["draw"])

        def fn(d):
            page = d[pno]
            a = page.add_ink_annot([[(p.x, p.y) for p in pts]])
            a.set_colors(stroke=color)
            a.set_border(width=2)
            a.update()
        self.model.edit("drawing", fn, page=pno)

    # ================================================================ theme
    def set_theme(self, name):
        self.settings.setValue("theme", name)
        theme.apply(QApplication.instance(), name)

    def _toggle_dark_pages(self):
        on = self.a_dark_pages.isChecked()
        self.settings.setValue("dark_pages", on)
        for w in WINDOWS:
            w.dark_pages = on
            w.a_dark_pages.setChecked(on)
            for t in w.all_tabs():
                t.view.set_dark_pages(on)

    def _on_theme_changed(self):
        refresh_icons(self)
        for key, a in self.theme_actions.items():
            a.setChecked(key == theme.choice())
        for t in self.all_tabs() + [self._empty]:
            t.view.apply_theme()
            t.side.refresh_theme()
            if t.model.is_open:
                t.side.chapters.load(t.model.doc)
        self._refresh_recent()
        self._update_color_btn()

    # ============================================================== chapters
    def _on_toc_edited(self, toc):
        tab = self.tab
        tab.own_toc_edit = True
        try:
            self.model.edit("chapters", lambda d: d.set_toc(toc), kind="toc")
            self.msg("Chapters updated — they're saved inside the PDF when you save.")
        except Exception as e:
            self._error("Chapters", f"Couldn't update the chapters.\n\n{e}")
            self.side.chapters.load(self.model.doc)
        finally:
            tab.own_toc_edit = False

    # ================================================================= pages
    def _on_page_dragged(self, frm, to):
        if to == frm or to == frm + 1:
            return
        self.model.edit("move page", lambda d: d.move_page(frm, to), kind="structure")

    def page_action(self, name, pno):
        doc = self.model.doc
        if doc is None:
            return
        n = doc.page_count
        if name == "blank":
            r = doc[pno].rect
            self.model.edit("insert page", lambda d: d.new_page(pno + 1, width=r.width, height=r.height),
                            kind="structure")
            self.view.go_to_page(pno + 1)
        elif name in ("rotl", "rotr"):
            delta = -90 if name == "rotl" else 90
            self.model.edit("rotate page",
                            lambda d: d[pno].set_rotation((d[pno].rotation + delta) % 360), kind="structure")
        elif name == "delete":
            if n <= 1:
                self._error("Delete page", "A PDF needs at least one page.")
                return
            r = QMessageBox.question(self, "Delete page", f"Delete page {pno + 1}?")
            if r == QMessageBox.StandardButton.Yes:
                self.model.edit("delete page", lambda d: d.delete_page(pno), kind="structure")
        elif name == "up" and pno > 0:
            self.model.edit("move page", lambda d: d.move_page(pno, pno - 1), kind="structure")
            self.view.go_to_page(pno - 1)
        elif name == "down" and pno < n - 1:
            self.model.edit("move page", lambda d: d.move_page(pno, pno + 2 if pno + 2 < n else -1),
                            kind="structure")
            self.view.go_to_page(pno + 1)
        elif name == "insert_file":
            self.insert_from_file(pno)
        elif name == "extract":
            self.extract_pages(f"{pno + 1}")

    def insert_from_file(self, after):
        start = self.settings.value("last_dir", os.path.expanduser("~"))
        exts = " ".join("*" + e for e in sorted(convert.IMAGE_EXT))
        path, _ = QFileDialog.getOpenFileName(
            self, "Insert pages from", start,
            f"PDF, Word, PowerPoint or photos (*.pdf *.docx *.doc *.pptx *.ppt {exts})")
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext in convert.IMAGE_EXT:
                src = convert.images_to_pdf([path], "Fit to photo")
            elif ext in convert.WORD_EXT or ext in convert.PPT_EXT:
                pdf, _ = self._convert_office(path)
                src = fitz.open(pdf)
            else:
                src = fitz.open(stream=DocumentModel.read_file(path), filetype="pdf")
                if src.needs_pass:
                    pw, ok = QInputDialog.getText(self, "Password", "Password for that PDF:",
                                                  QLineEdit.EchoMode.Password)
                    if not ok or not src.authenticate(pw):
                        return
        except Exception as e:
            self._error("Insert pages", f"Couldn't read that file.\n\n{e}")
            return
        count = src.page_count
        self.model.edit("insert pages", lambda d: d.insert_pdf(src, start_at=after + 1, links=True, annots=True),
                        kind="structure")
        src.close()
        self.view.go_to_page(after + 1)
        self.msg(f"Inserted {count} page(s) after page {after + 1}.")

    def extract_pages_dialog(self):
        cur = self.view.current_page() + 1
        text, ok = QInputDialog.getText(self, "Extract pages",
                                        f"Which pages? (e.g. 1-3, 7)  — this PDF has {self.model.page_count}",
                                        text=str(cur))
        if ok and text.strip():
            self.extract_pages(text)

    @staticmethod
    def parse_ranges(text, n):
        pages = []
        for part in text.replace(" ", "").split(","):
            if not part:
                continue
            if "-" in part:
                a, b = part.split("-", 1)
                a = int(a) if a else 1
                b = int(b) if b else n
                pages.extend(range(min(a, b), max(a, b) + 1))
            else:
                pages.append(int(part))
        out = []
        for p in pages:
            if 1 <= p <= n and p - 1 not in out:
                out.append(p - 1)
        return out

    def extract_pages(self, text):
        try:
            pages = self.parse_ranges(text, self.model.page_count)
        except ValueError:
            self._error("Extract pages", "Write pages like: 1-3, 7")
            return
        if not pages:
            self._error("Extract pages", "None of those pages are in this PDF.")
            return
        base = os.path.splitext(self.model.display_name)[0]
        folder = os.path.dirname(self.model.path or self.model.source_path or "") or \
            self.settings.value("last_dir", os.path.expanduser("~"))
        suggestion = os.path.join(folder, f"{base} (pages {text.replace(' ', '')}).pdf")
        out, _ = QFileDialog.getSaveFileName(self, "Save extracted pages", suggestion, "PDF (*.pdf)")
        if not out:
            return
        new = fitz.open()
        for p in pages:
            new.insert_pdf(self.model.doc, from_page=p, to_page=p)
        try:
            new.save(out, garbage=3, deflate=True)
            self.msg(f"Saved {len(pages)} page(s) to {os.path.basename(out)}")
        except Exception as e:
            self._error("Extract pages", f"Couldn't save.\n\n{e}")
        finally:
            new.close()

    # ================================================================= print
    def print_doc(self):
        from .printing import PrintDialog, print_pages
        if not self.model.is_open:
            return
        d = PrintDialog(self, self.model.doc, self.view.current_page(), self.model.display_name)
        if not d.exec():
            return
        pages = d.selected_pages()
        prog = QProgressDialog("Printing…", "Cancel", 0, len(pages), self)
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(300)

        def step(i):
            prog.setValue(i)
            QApplication.processEvents()
            return not prog.wasCanceled()
        try:
            done = print_pages(d.printer, self.model.doc, pages, progress=step, **d.options())
        except Exception as e:
            prog.close()
            self._error("Print", f"Couldn't print.\n\n{e}")
            return
        prog.close()
        if done:
            self.msg(f"Sent {len(pages)} page(s) to {d.printer.printerName()}.")

    # ================================================================== help
    def shortcuts_help(self):
        QMessageBox.information(self, "Keyboard shortcuts", (
            "Ctrl+O  Open (each file opens in a tab)      Ctrl+W  Close tab\n"
            "Ctrl+Tab / Ctrl+Shift+Tab  Next / previous tab      Ctrl+Shift+N  New window\n"
            "Drag a tab off the tab bar to give it its own window\n\n"
            "Ctrl+S  Save      Ctrl+P  Print      Ctrl+Z / Ctrl+Y  Undo / Redo\n"
            "Ctrl+C  Copy selected text      Ctrl+A  Select all text on the page\n"
            "Ctrl+F  Find      F3 / Shift+F3  Next / previous match\n"
            "Ctrl+D  Bookmark this spot      Ctrl+Shift+H  Highlights list\n"
            "Ctrl+Shift+C  Add a chapter at this page      F4  Side panel\n"
            "Ctrl+G  Go to page      Ctrl+Page Up / Down  Previous / next page\n"
            "Ctrl + mouse wheel  Zoom      Ctrl+0  Fit width      Ctrl+9  Whole page\n"
            "Ctrl+Shift+D  Dark pages\n\n"
            "Right-click  Options for the current tool (Laser: clears the marks)\n"
            "Esc  Clear laser marks / selection, then back to the Select tool"))

    def about(self):
        info = updater.running_info()
        how = "quick update" if info["patched"] else "installer"
        QMessageBox.about(self, f"About {APP_NAME}", (
            f"<b>{APP_NAME}</b> {__version__}<br><br>"
            "Read, mark up and create PDFs. Opens Word and PowerPoint files "
            "(using Microsoft Office when it's installed).<br><br>"
            f"<span style='color:{theme.c('muted')}'>Installed from: {how} · installer version {info['bundled']}<br>"
            f"Engine: {info['engine'][:12]} · PDF engine: PyMuPDF {fitz.VersionBind}</span>"))

    # ================================================================ updates
    def after_start(self):
        """Runs once the window is showing."""
        info = updater.running_info()
        if info["failed"]:
            QMessageBox.warning(self, "Update problem", (
                f"Version {info['failed']} couldn't start on this PC, so Olai went back to version "
                f"{__version__}.\n\nPlease tell the developer. The details are saved in:\n"
                + os.path.join(updater.updates_dir(), "last_error.txt")))
        seen = self.settings.value("last_seen_version", "")
        if seen and seen != __version__:
            self.msg(f"Olai was updated to version {__version__}.", 10000)
        self.settings.setValue("last_seen_version", __version__)
        if self.a_auto_updates.isChecked():
            last = float(self.settings.value("last_update_check", 0) or 0)
            if time.time() - last > 6 * 3600:
                QTimer.singleShot(4000, lambda: self.check_for_updates(manual=False))

    def _toggle_auto_updates(self):
        self.settings.setValue("auto_update", self.a_auto_updates.isChecked())

    def check_for_updates(self, manual=True):
        if getattr(self, "_update_worker", None) is not None and self._update_worker.isRunning():
            return
        w = _Worker(updater.check)
        self._update_worker = w
        if manual:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self.msg("Checking for updates…", 20000)
        w.finished.connect(lambda: self._update_checked(w, manual))
        w.start()

    def _update_checked(self, w, manual):
        if manual:
            QApplication.restoreOverrideCursor()
            self.statusBar().clearMessage()
        self._update_worker = None
        if w.error is not None:
            if manual:
                QMessageBox.information(self, "Check for updates", str(w.error))
            return
        self.settings.setValue("last_update_check", time.time())
        upd = w.result
        if upd is None:
            if manual:
                QMessageBox.information(self, "Check for updates",
                                        f"You have the latest version of Olai ({__version__}).")
            return
        if manual:
            self.offer_update(upd)
        elif upd.version not in updater.read_state().get("bad", []):
            self._show_update_button(upd)

    def _show_update_button(self, upd):
        btn = getattr(self, "_update_btn", None)
        if btn is None:
            btn = QPushButton()
            btn.setObjectName("updateBtn")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            self.statusBar().insertPermanentWidget(0, btn)
            self._update_btn = btn
        self._pending_update = upd
        if not getattr(self, "_update_btn_wired", False):
            btn.clicked.connect(lambda: self.offer_update(self._pending_update))
            self._update_btn_wired = True
        btn.setText(f"Update to {upd.version}")
        btn.show()

    def offer_update(self, upd):
        from .dialogs import UpdateDialog
        d = UpdateDialog(self, __version__, upd)
        if not d.exec():
            return
        if upd.kind == "full" and sys.platform != "win32":
            QMessageBox.information(self, "Update", "Full updates can only be installed on Windows.")
            return
        prog = QProgressDialog("Downloading the update…", "Cancel", 0, 100, self)
        prog.setWindowTitle("Updating Olai")
        prog.setWindowModality(Qt.WindowModality.WindowModal)
        prog.setMinimumDuration(0)
        prog.setValue(0)
        state = {"done": 0, "total": upd.size, "cancel": False}

        def progress(done, total):
            state["done"], state["total"] = done, total or state["total"]

        def job():
            cancel = lambda: state["cancel"]
            if upd.kind == "patch":
                updater.install_patch(upd, progress, cancel)
                return None
            return updater.download_installer(upd, progress, cancel)

        w = _Worker(job)
        w.start()
        while not w.wait(50):
            if state["total"]:
                prog.setValue(min(99, int(state["done"] * 100 / state["total"])))
                if state["done"] >= state["total"] and upd.kind == "patch":
                    prog.setLabelText("Checking the update…")
            if prog.wasCanceled():
                state["cancel"] = True
            QApplication.processEvents()
        prog.close()
        if isinstance(w.error, updater.Cancelled):
            return
        if w.error is not None:
            QMessageBox.warning(self, "Update", f"The update couldn't be installed.\n\n{w.error}")
            return
        if getattr(self, "_update_btn", None) is not None:
            self._update_btn.hide()
        if upd.kind == "patch":
            r = QMessageBox.question(self, "Update installed",
                                     f"Olai {upd.version} is installed.\n\nRestart now to start using it?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.Yes)
            if r == QMessageBox.StandardButton.Yes:
                self.restart_app()
            else:
                self.msg(f"Version {upd.version} will be used the next time you open Olai.", 10000)
        else:
            if not self._save_all():
                return
            try:
                updater.run_installer(w.result)
            except Exception as e:
                QMessageBox.warning(self, "Update", f"The installer couldn't be started.\n\n{e}")
                return
            self._close_everything()

    def _save_all(self):
        """Ask about unsaved changes in every tab of every window. False if the user cancels."""
        for w in list(WINDOWS):
            for t in w.all_tabs():
                w.tabs.setCurrentWidget(t)
                if not w._maybe_save():
                    return False
                t.model._set_modified(False)
        return True

    def _close_everything(self):
        srv = INSTANCE.get("server")
        if srv is not None:
            srv.close()
            INSTANCE["server"] = None
        for w in list(WINDOWS):
            w.close()

    def restart_app(self):
        if not self._save_all():
            return
        paths = [t.model.path for w in WINDOWS for t in w.all_tabs() if t.model.path]
        srv = INSTANCE.get("server")
        if srv is not None:                    # let the new copy become the running one
            srv.close()
            INSTANCE["server"] = None
        try:
            subprocess.Popen(updater.restart_command(paths), close_fds=True)
        except Exception as e:
            QMessageBox.warning(self, "Restart", f"Couldn't restart automatically ({e}).\n"
                                                 "Please close Olai and open it again.")
            return
        self._close_everything()

    def undo_update(self):
        r = QMessageBox.question(self, "Undo the last update",
                                 "Go back to the version before the last update?\n"
                                 "Olai will restart. It won't offer that update again automatically, "
                                 "but Help → Check for updates can still install it.")
        if r != QMessageBox.StandardButton.Yes:
            return
        try:
            ver = updater.undo_last_update()
        except OSError as e:
            QMessageBox.warning(self, "Undo update", str(e))
            return
        self.msg(f"Going back to version {ver}…")
        self.restart_app()


# ---------------------------------------------------------------- text helper
def add_text(page, pt, text, size, color):
    """Place text with its top-left at pt. Latin text is added as a removable text box
    (a FreeText annotation); other scripts are drawn onto the page with a Windows font."""
    import math
    lines = text.splitlines() or [text]
    fontname, fontfile = convert._font_for(text)
    if fontfile:
        font = fitz.Font(fontfile=fontfile)
        lengths = [font.text_length(l, fontsize=size) for l in lines]
    else:
        lengths = [fitz.get_text_length(l, fontname="helv", fontsize=size) for l in lines]
    prect = page.rect * page.derotation_matrix
    prect.normalize()
    pad = size * 0.8
    max_w = max(40, prect.x1 - pt.x - 4)
    width = min(max(lengths) + pad, max_w)
    # lines wider than the box wrap; count the wrapped lines (+ a little slack)
    usable = max(width - pad, 10)
    n_lines = sum(max(1, math.ceil(L * 1.08 / usable)) for L in lengths)
    height = n_lines * size * 1.3 + size * 0.7
    top = pt.y - size * 0.3
    rect = fitz.Rect(pt.x, top, pt.x + width, top + height)
    if fontfile is None:
        a = page.add_freetext_annot(rect, text, fontsize=size, fontname="helv",
                                    text_color=color, fill_color=None, border_width=0)
        a.update()
    else:
        for _ in range(12):
            rc = page.insert_textbox(rect, text, fontsize=size, fontname=fontname,
                                     fontfile=fontfile, color=color)
            if rc >= 0:
                return
            rect.y1 += size * 1.35
