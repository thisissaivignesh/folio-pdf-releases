"""The open document: wraps a PyMuPDF document with undo/redo and saving."""
import os
import tempfile

import fitz  # PyMuPDF
from PySide6.QtCore import QObject, Signal


class DocumentModel(QObject):
    # kind: "loaded" (new doc), "structure" (pages added/removed/moved/rotated),
    #       "content" (page drawing changed), "toc" (chapters changed)
    changed = Signal(str)
    pageChanged = Signal(int)
    modifiedChanged = Signal(bool)

    MAX_UNDO_BYTES = 600 * 1024 * 1024
    MAX_UNDO_STEPS = 30

    def __init__(self):
        super().__init__()
        self.doc = None
        self.path = None            # file the PDF is saved to (None = untitled)
        self.source_path = None     # original file (e.g. the .docx it came from)
        self.display_name = ""
        self.note = None            # banner text, e.g. "Converted from Word"
        self.password = None
        self._undo = []             # list of (description, bytes)
        self._redo = []
        self._modified = False

    # ------------------------------------------------------------------ state
    @property
    def is_open(self):
        return self.doc is not None

    @property
    def modified(self):
        return self._modified

    def _set_modified(self, value):
        if value != self._modified:
            self._modified = value
            self.modifiedChanged.emit(value)

    @property
    def page_count(self):
        return self.doc.page_count if self.doc else 0

    def bookmark_key(self):
        p = self.path or self.source_path
        return os.path.normcase(os.path.abspath(p)) if p else None

    # ---------------------------------------------------------------- loading
    @staticmethod
    def read_file(path):
        with open(path, "rb") as f:
            return f.read()

    def load_bytes(self, data, display_name, path=None, source_path=None, note=None, password=None):
        """Open PDF bytes. The file on disk is never kept open, so saving over it works on Windows."""
        doc = fitz.open(stream=data, filetype="pdf")
        if doc.needs_pass:
            if not password or not doc.authenticate(password):
                doc.close()
                raise PermissionError("password")
        self.close()
        self.doc = doc
        self.password = password
        self.path = path
        self.source_path = source_path or path
        self.display_name = display_name
        self.note = note
        self._undo.clear()
        self._redo.clear()
        self._modified = False
        self.modifiedChanged.emit(False)
        self.changed.emit("loaded")

    def load_document(self, doc, display_name, source_path=None, note=None, modified=True):
        """Adopt an already-built fitz document (new blank PDF, conversions)."""
        self.load_bytes(doc.tobytes(garbage=1, deflate=True), display_name,
                        path=None, source_path=source_path, note=note)
        doc.close()
        if modified:
            self._set_modified(True)

    def close(self):
        if self.doc is not None:
            self.doc.close()
        self.doc = None
        self.path = None
        self.source_path = None
        self.note = None
        self._undo.clear()
        self._redo.clear()
        self._set_modified(False)

    # ---------------------------------------------------------------- editing
    def _snapshot(self):
        return self.doc.tobytes(garbage=0, deflate=False)

    def _restore(self, data):
        doc = fitz.open(stream=data, filetype="pdf")
        if doc.needs_pass and self.password:
            doc.authenticate(self.password)
        self.doc.close()
        self.doc = doc

    def _trim_undo(self):
        total = sum(len(b) for _, b in self._undo)
        while self._undo and (len(self._undo) > self.MAX_UNDO_STEPS or total > self.MAX_UNDO_BYTES):
            _, b = self._undo.pop(0)
            total -= len(b)

    def edit(self, description, fn, kind="content", page=None):
        """Run fn(doc) as one undoable step. Returns fn's result."""
        if self.doc is None:
            return None
        snap = self._snapshot()
        try:
            result = fn(self.doc)
        except Exception:
            self._restore(snap)
            self.changed.emit("structure")
            raise
        self._undo.append((description, snap))
        self._trim_undo()
        self._redo.clear()
        self._set_modified(True)
        if kind == "content" and page is not None:
            self.pageChanged.emit(page)
        else:
            self.changed.emit(kind)
        return result

    def can_undo(self):
        return bool(self._undo)

    def can_redo(self):
        return bool(self._redo)

    def undo_text(self):
        return self._undo[-1][0] if self._undo else ""

    def redo_text(self):
        return self._redo[-1][0] if self._redo else ""

    def undo(self):
        if not self._undo:
            return
        desc, data = self._undo.pop()
        self._redo.append((desc, self._snapshot()))
        self._restore(data)
        self._set_modified(True)
        self.changed.emit("structure")

    def redo(self):
        if not self._redo:
            return
        desc, data = self._redo.pop()
        self._undo.append((desc, self._snapshot()))
        self._restore(data)
        self._set_modified(True)
        self.changed.emit("structure")

    # ----------------------------------------------------------------- saving
    def save(self, path):
        """Write to a temp file next to the target, then swap it in, so a failed save never damages the original."""
        folder = os.path.dirname(os.path.abspath(path)) or "."
        fd, tmp = tempfile.mkstemp(suffix=".pdf", dir=folder)
        os.close(fd)
        try:
            self.doc.save(tmp, garbage=1, deflate=True)
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
        self.path = path
        self.source_path = self.source_path or path
        self.display_name = os.path.basename(path)
        self.note = None
        self._set_modified(False)
