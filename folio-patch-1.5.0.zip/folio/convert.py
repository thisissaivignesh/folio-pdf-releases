"""Turning other files into PDFs: Word, PowerPoint and photos."""
import io
import os
import shutil
import sys
import tempfile

import fitz

WORD_EXT = {".doc", ".docx", ".docm", ".dot", ".dotx", ".rtf", ".odt"}
PPT_EXT = {".ppt", ".pptx", ".pptm", ".pps", ".ppsx", ".odp"}
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".gif", ".tif", ".tiff", ".webp", ".heic", ".heif"}

PAPER = {
    "A4": fitz.paper_size("a4"),
    "Letter": fitz.paper_size("letter"),
    "Legal": fitz.paper_size("legal"),
    "A5": fitz.paper_size("a5"),
}


class ConversionError(Exception):
    pass


# ------------------------------------------------------- Microsoft Office (COM)
def office_available(kind):
    """kind: 'word' or 'powerpoint'. True if that Office app is installed (Windows only)."""
    if sys.platform != "win32":
        return False
    try:
        import winreg
        progid = "Word.Application" if kind == "word" else "PowerPoint.Application"
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, progid))
        return True
    except Exception:
        return False


def _office_convert(src, out_pdf, kind):
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    app = None
    try:
        src = os.path.abspath(src)
        out_pdf = os.path.abspath(out_pdf)
        if kind == "word":
            app = win32com.client.DispatchEx("Word.Application")
            app.Visible = False
            app.DisplayAlerts = 0
            doc = app.Documents.Open(src, False, True, False)  # ConfirmConversions, ReadOnly, AddToRecent
            try:
                # 17 = PDF; CreateBookmarks 1 = turn Word headings into PDF chapters
                doc.ExportAsFixedFormat(OutputFileName=out_pdf, ExportFormat=17,
                                        OpenAfterExport=False, OptimizeFor=0,
                                        CreateBookmarks=1, DocStructureTags=True)
            finally:
                doc.Close(False)
        else:
            app = win32com.client.DispatchEx("PowerPoint.Application")
            pres = app.Presentations.Open(src, True, False, False)  # ReadOnly, Untitled, WithWindow
            try:
                pres.SaveAs(out_pdf, 32)  # 32 = PDF
            finally:
                pres.Close()
    finally:
        if app is not None:
            try:
                app.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()
    if not os.path.exists(out_pdf):
        raise ConversionError("Office did not produce a PDF.")


# --------------------------------------------------------- built-in fallbacks
_DOC_CSS = """
body { font-family: sans-serif; font-size: 11pt; line-height: 1.35; }
h1 { font-size: 20pt; margin-top: 14pt; } h2 { font-size: 16pt; margin-top: 12pt; }
h3 { font-size: 13pt; } h4, h5, h6 { font-size: 11.5pt; }
p { margin: 0 0 6pt 0; }
table { border-collapse: collapse; margin: 6pt 0; }
td, th { border: 0.6pt solid #888; padding: 3pt 5pt; vertical-align: top; }
img { max-width: 100%; }
"""


def docx_to_pdf_basic(src, out_pdf):
    """Approximate Word layout without Office: text, headings, lists, tables, pictures."""
    if os.path.splitext(src)[1].lower() != ".docx":
        raise ConversionError("Opening this kind of Word file needs Microsoft Word installed.\n"
                              "Files saved as .docx can be opened without it.")
    import mammoth
    tmpdir = tempfile.mkdtemp(prefix="folio_docx_")
    try:
        counter = [0]

        def save_image(image):
            ctype = (image.content_type or "").lower()
            ext = {"image/png": ".png", "image/jpeg": ".jpg", "image/jpg": ".jpg",
                   "image/gif": ".gif", "image/bmp": ".bmp"}.get(ctype)
            if ext is None:
                return {}
            counter[0] += 1
            name = f"img{counter[0]}{ext}"
            with image.open() as f, open(os.path.join(tmpdir, name), "wb") as out:
                out.write(f.read())
            return {"src": name}

        with open(src, "rb") as f:
            result = mammoth.convert_to_html(f, convert_image=mammoth.images.img_element(save_image))
        html = result.value or "<p></p>"
        story = fitz.Story(html=html, user_css=_DOC_CSS, archive=fitz.Archive(tmpdir))
        mediabox = fitz.paper_rect("a4")
        where = mediabox + (60, 60, -60, -60)
        headings = []
        writer = fitz.DocumentWriter(out_pdf)
        def rec(pos):
            if pos.heading and (pos.open_close & 1) and pos.text:
                headings.append((pos.heading, pos.text.strip(), pos.page_index, pos.rect[1]))

        more, pno = 1, 0
        while more:
            dev = writer.begin_page(mediabox)
            more, _ = story.place(where)
            story.element_positions(rec, {"page_index": pno})
            story.draw(dev)
            writer.end_page()
            pno += 1
        writer.close()
        if headings:
            _add_heading_toc(out_pdf, headings)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def _add_heading_toc(pdf_path, headings):
    doc = fitz.open(pdf_path)
    toc, last = [], 0
    for lvl, text, pno, y in headings:
        lvl = min(lvl, last + 1)   # outlines can't skip levels
        last = lvl
        toc.append([lvl, text[:120], pno + 1,
                    {"kind": fitz.LINK_GOTO, "page": pno, "to": fitz.Point(0, y), "zoom": 0.0}])
    try:
        doc.set_toc(toc)
        doc.saveIncr()
    except Exception:
        pass
    doc.close()


def pptx_to_pdf_basic(src, out_pdf):
    """One page per slide with its pictures and text in place (no themes or effects)."""
    if os.path.splitext(src)[1].lower() not in (".pptx", ".pptm", ".ppsx"):
        raise ConversionError("Opening this kind of PowerPoint file needs Microsoft PowerPoint installed.\n"
                              "Files saved as .pptx can be opened without it.")
    from pptx import Presentation
    from pptx.util import Emu
    prs = Presentation(src)
    W = Emu(prs.slide_width).pt
    H = Emu(prs.slide_height).pt
    doc = fitz.open()
    toc = []

    def pt(v):
        return Emu(v or 0).pt

    def draw_shape(page, shp, ox=0.0, oy=0.0):
        try:
            x, y = pt(shp.left) + ox, pt(shp.top) + oy
            w, h = pt(shp.width), pt(shp.height)
        except Exception:
            return
        rect = fitz.Rect(x, y, x + w, y + h)
        try:
            stype = int(shp.shape_type) if shp.shape_type is not None else None
        except Exception:
            stype = None
        if stype == 6 and hasattr(shp, "shapes"):          # group
            for s in shp.shapes:
                draw_shape(page, s, 0, 0)
            return
        blob = None
        try:
            blob = shp.image.blob                          # pictures (incl. picture placeholders)
        except Exception:
            blob = None
        if blob:
            try:
                page.insert_image(rect, stream=blob, keep_proportion=False)
            except Exception:
                pass
            return
        try:
            fill = shp.fill
            if fill.type == 1:  # solid
                c = fill.fore_color.rgb
                page.draw_rect(rect, color=None, fill=(c[0] / 255, c[1] / 255, c[2] / 255))
        except Exception:
            pass
        if getattr(shp, "has_table", False) and shp.has_table:
            rows = shp.table.rows
            n = max(len(rows), 1)
            rh = rect.height / n
            for i, row in enumerate(rows):
                cells = list(row.cells)
                cw = rect.width / max(len(cells), 1)
                for j, cell in enumerate(cells):
                    r = fitz.Rect(rect.x0 + j * cw, rect.y0 + i * rh,
                                  rect.x0 + (j + 1) * cw, rect.y0 + (i + 1) * rh)
                    page.draw_rect(r, color=(0.6, 0.6, 0.6), width=0.5)
                    _fit_text(page, r + (3, 2, -3, -2), cell.text, 12)
            return
        if getattr(shp, "has_text_frame", False) and shp.has_text_frame:
            text = "\n".join(p.text for p in shp.text_frame.paragraphs)
            size = 18
            try:
                for p in shp.text_frame.paragraphs:
                    for r in p.runs:
                        if r.font.size:
                            size = r.font.size.pt
                            raise StopIteration
            except StopIteration:
                pass
            if text.strip():
                _fit_text(page, rect, text, size)

    for i, slide in enumerate(prs.slides):
        page = doc.new_page(width=W, height=H)
        try:
            bg = slide.background.fill
            if bg.type == 1:
                c = bg.fore_color.rgb
                page.draw_rect(page.rect, color=None, fill=(c[0] / 255, c[1] / 255, c[2] / 255))
        except Exception:
            pass
        for shp in slide.shapes:
            draw_shape(page, shp)
        title = None
        try:
            if slide.shapes.title is not None and slide.shapes.title.text.strip():
                title = slide.shapes.title.text.strip().replace("\n", " ")
        except Exception:
            pass
        toc.append([1, f"Slide {i + 1}" + (f": {title[:80]}" if title else ""), i + 1])
    if doc.page_count == 0:
        doc.new_page(width=W, height=H)
    doc.set_toc(toc)
    doc.save(out_pdf, garbage=1, deflate=True)
    doc.close()


def _fit_text(page, rect, text, size):
    """Write text into rect, shrinking the font until it fits."""
    fontname, fontfile = _font_for(text)
    size = max(4.0, float(size))
    while size >= 4:
        rc = page.insert_textbox(rect, text, fontsize=size, fontname=fontname,
                                 fontfile=fontfile, color=(0.1, 0.1, 0.1))
        if rc >= 0:
            return
        size *= 0.85
    # last resort: overflow is clipped by the page anyway
    page.insert_textbox(fitz.Rect(rect.x0, rect.y0, rect.x1, rect.y1 + 400), text,
                        fontsize=4, fontname=fontname, fontfile=fontfile)


_WIN_FONTS = [r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\segoeui.ttf"]


def _font_for(text):
    """Built-in Helvetica covers Latin-1; use a Windows font for anything else."""
    try:
        text.encode("latin-1")
        return "helv", None
    except UnicodeEncodeError:
        for f in _WIN_FONTS:
            if os.path.exists(f):
                return "F0", f
        return "helv", None


# ----------------------------------------------------------------- entry point
def office_to_pdf(src, out_pdf, prefer_office=True):
    """Convert a Word/PowerPoint file. Returns 'office' or 'basic' (which method was used)."""
    ext = os.path.splitext(src)[1].lower()
    kind = "word" if ext in WORD_EXT else "powerpoint" if ext in PPT_EXT else None
    if kind is None:
        raise ConversionError(f"Unsupported file type: {ext}")
    if prefer_office and office_available(kind):
        try:
            _office_convert(src, out_pdf, kind)
            return "office"
        except Exception:
            pass  # fall back to the built-in view below
    if kind == "word":
        docx_to_pdf_basic(src, out_pdf)
    else:
        pptx_to_pdf_basic(src, out_pdf)
    return "basic"


# ---------------------------------------------------------------- photos → PDF
def _register_heic():
    try:
        from pillow_heif import register_heif_opener
        register_heif_opener()
    except Exception:
        pass


def load_image_bytes(path, max_side=3000):
    """Read a picture with phone-camera rotation applied; returns PNG (if transparent) or JPEG bytes."""
    from PIL import Image, ImageOps
    _register_heic()
    with Image.open(path) as im:
        im = ImageOps.exif_transpose(im)
        if max(im.size) > max_side:
            im.thumbnail((max_side, max_side), Image.LANCZOS)
        buf = io.BytesIO()
        if im.mode in ("RGBA", "LA", "P"):
            im.convert("RGBA").save(buf, format="PNG", optimize=True)
        else:
            im.convert("RGB").save(buf, format="JPEG", quality=92)
    return buf.getvalue()


def images_to_pdf(paths, page_size="Fit to photo", margin_pt=0, shrink=True, progress=None):
    """Build a fitz document with one photo per page. EXIF rotation from phone cameras is honoured."""
    from PIL import Image, ImageOps
    _register_heic()
    doc = fitz.open()
    for i, path in enumerate(paths):
        if progress is not None and progress(i) is False:
            break
        with Image.open(path) as im:
            im = ImageOps.exif_transpose(im)
            if im.mode in ("RGBA", "LA", "P"):
                im = im.convert("RGBA")
                bg = Image.new("RGB", im.size, "white")
                bg.paste(im, mask=im.split()[-1])
                im = bg
            elif im.mode != "RGB":
                im = im.convert("RGB")
            if shrink and max(im.size) > 2600:
                im.thumbnail((2600, 2600), Image.LANCZOS)
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=88 if shrink else 95, optimize=True)
            w_px, h_px = im.size
        data = buf.getvalue()
        if page_size in PAPER:
            pw, ph = PAPER[page_size]
            if (w_px > h_px) != (pw > ph):      # auto-orient the page to the photo
                pw, ph = ph, pw
        else:
            # "Fit to photo": page the photo's size at 150 dpi (min/max sensible)
            scale = 72 / 150
            pw, ph = w_px * scale, h_px * scale
            big = max(pw, ph)
            if big > 1400:
                pw, ph = pw * 1400 / big, ph * 1400 / big
            pw += 2 * margin_pt
            ph += 2 * margin_pt
        page = doc.new_page(width=pw, height=ph)
        rect = fitz.Rect(margin_pt, margin_pt, pw - margin_pt, ph - margin_pt)
        page.insert_image(rect, stream=data, keep_proportion=True)
    return doc
