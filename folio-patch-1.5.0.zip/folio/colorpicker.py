"""A modern colour picker popup: theme colours with lighter/darker shades, standard colours,
recent colours and a custom colour square. Replaces the old Windows colour dialog everywhere."""
from PySide6.QtCore import Qt, Signal, QPoint, QPointF, QRectF, QSettings, QSize
from PySide6.QtGui import QColor, QPainter, QPen, QLinearGradient, QBrush, QGuiApplication, QPixmap, QIcon
from PySide6.QtWidgets import (QFrame, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QToolButton,
                               QWidget, QLineEdit, QPushButton, QSizePolicy)

from . import theme

THEME_BASES = ["#ffffff", "#000000", "#9ca3af", "#1e3a5f", "#2563eb", "#ea580c", "#16a34a", "#0891b2",
               "#9333ea", "#ca8a04"]
STANDARD = ["#c00000", "#ff0000", "#ffc000", "#ffff00", "#92d050", "#00b050", "#00b0f0", "#0070c0",
            "#002060", "#7030a0"]
HIGHLIGHTER = ["#ffd400", "#9be36d", "#6ad7f7", "#ff9ad5", "#ffad5c", "#c7a6ff", "#ff7b7b", "#d9d9d9"]
PEN = ["#d61f1f", "#111111", "#1a5fb4", "#16a34a", "#ea580c", "#9333ea", "#ffffff", "#ffd400"]

SETTINGS = ("FolioPDF", "Folio PDF")


def _mix(c, other, amount):
    return QColor(round(c.red() + (other.red() - c.red()) * amount),
                  round(c.green() + (other.green() - c.green()) * amount),
                  round(c.blue() + (other.blue() - c.blue()) * amount))


def shades(hexcolor):
    """Five variants under a theme colour, like the Office palette."""
    c = QColor(hexcolor)
    white, black = QColor("#ffffff"), QColor("#000000")
    light = c.lightnessF()
    if light > 0.92:
        return [_mix(c, black, a).name() for a in (0.05, 0.15, 0.25, 0.35, 0.5)]
    if light < 0.08:
        return [_mix(c, white, a).name() for a in (0.5, 0.35, 0.25, 0.15, 0.05)]
    return ([_mix(c, white, a).name() for a in (0.8, 0.6, 0.4)] +
            [_mix(c, black, a).name() for a in (0.25, 0.5)])


def recent_colors():
    v = QSettings(*SETTINGS).value("recent_colors", [])
    if isinstance(v, str):
        v = [v]
    return [x for x in (v or []) if QColor(x).isValid()][:10]


def remember(color):
    name = QColor(color).name()
    r = [x for x in recent_colors() if x.lower() != name.lower()]
    QSettings(*SETTINGS).setValue("recent_colors", [name] + r[:9])


def dot_icon(hexcolor, size=18):
    """Round colour dot for buttons and menus."""
    pm = QPixmap(size * 2, size * 2)
    pm.setDevicePixelRatio(2)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QColor(hexcolor))
    p.setPen(QPen(theme.qcolor("border_strong"), 1))
    p.drawEllipse(QRectF(1.5, 1.5, size - 3, size - 3))
    p.end()
    return QIcon(pm)


class Swatch(QToolButton):
    def __init__(self, color, size=20, round_=False, current=False):
        super().__init__()
        self.color = QColor(color)
        self.round = round_
        self.current = current
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip(self.color.name().upper())
        self.setAutoRaise(True)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(1.5, 1.5, -1.5, -1.5)
        hover = self.underMouse()
        p.setBrush(self.color)
        border = theme.qcolor("text") if (hover or self.current) else theme.qcolor("border_strong")
        p.setPen(QPen(border, 2 if (hover or self.current) else 1))
        if self.round:
            p.drawEllipse(r)
        else:
            p.drawRoundedRect(r, 3, 3)
        if self.current:
            p.setPen(QPen(QColor("#000000") if self.color.lightnessF() > 0.6 else QColor("#ffffff"), 1.6))
            c = r.center()
            p.drawLine(c + QPointF(-4, 0), c + QPointF(-1, 3))
            p.drawLine(c + QPointF(-1, 3), c + QPointF(4, -3))


class SVSquare(QWidget):
    """Saturation (x) / brightness (y) square for one hue."""
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.setFixedSize(212, 132)
        self.h, self.s, self.v = 0.0, 1.0, 1.0
        self.setCursor(Qt.CursorShape.CrossCursor)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        base = QColor.fromHsvF(self.h, 1, 1)
        g = QLinearGradient(r.topLeft(), r.topRight())
        g.setColorAt(0, QColor("#ffffff"))
        g.setColorAt(1, base)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawRoundedRect(r, 6, 6)
        g2 = QLinearGradient(r.topLeft(), r.bottomLeft())
        g2.setColorAt(0, QColor(0, 0, 0, 0))
        g2.setColorAt(1, QColor(0, 0, 0, 255))
        p.setBrush(QBrush(g2))
        p.drawRoundedRect(r, 6, 6)
        x = r.left() + self.s * r.width()
        y = r.top() + (1 - self.v) * r.height()
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor("#ffffff"), 2))
        p.drawEllipse(QRectF(x - 6, y - 6, 12, 12))
        p.setPen(QPen(QColor("#000000"), 1))
        p.drawEllipse(QRectF(x - 7, y - 7, 14, 14))

    def _set(self, pos):
        self.s = min(max(pos.x() / max(self.width(), 1), 0), 1)
        self.v = 1 - min(max(pos.y() / max(self.height(), 1), 0), 1)
        self.update()
        self.changed.emit()

    def mousePressEvent(self, e):
        self._set(e.position())

    def mouseMoveEvent(self, e):
        self._set(e.position())


class HueBar(QWidget):
    changed = Signal()

    def __init__(self):
        super().__init__()
        self.setFixedSize(212, 16)
        self.h = 0.0
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 3.5, -0.5, -3.5)
        g = QLinearGradient(r.topLeft(), r.topRight())
        for i in range(7):
            g.setColorAt(i / 6, QColor.fromHsvF((i / 6) % 1.0, 1, 1))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawRoundedRect(r, 4, 4)
        x = self.h * self.width()
        p.setBrush(QColor("#ffffff"))
        p.setPen(QPen(QColor("#000000"), 1))
        p.drawRoundedRect(QRectF(x - 3, 0.5, 6, self.height() - 1), 2, 2)

    def _set(self, pos):
        self.h = min(max(pos.x() / max(self.width(), 1), 0), 0.9999)
        self.update()
        self.changed.emit()

    def mousePressEvent(self, e):
        self._set(e.position())

    def mouseMoveEvent(self, e):
        self._set(e.position())


class ColorPopup(QFrame):
    picked = Signal(QColor)

    def __init__(self, parent=None, current=None, presets=None, title=None):
        super().__init__(parent, Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setObjectName("colorPopup")
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        self.current = QColor(current).name().lower() if current else None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(6)
        if presets:
            lay.addWidget(self._heading(title or "Quick colours"))
            row = QHBoxLayout()
            row.setSpacing(6)
            for col in presets:
                row.addWidget(self._swatch(col, 24, True))
            row.addStretch(1)
            lay.addLayout(row)
        lay.addWidget(self._heading("Theme colours"))
        grid = QGridLayout()
        grid.setHorizontalSpacing(4)
        grid.setVerticalSpacing(0)
        for col_i, base in enumerate(THEME_BASES):
            grid.addWidget(self._swatch(base), 0, col_i)
            for row_i, s in enumerate(shades(base)):
                grid.addWidget(self._swatch(s, 20, False, tight=True), row_i + 2, col_i)
        grid.setRowMinimumHeight(1, 6)
        lay.addLayout(grid)
        lay.addWidget(self._heading("Standard colours"))
        row = QHBoxLayout()
        row.setSpacing(4)
        for col in STANDARD:
            row.addWidget(self._swatch(col))
        row.addStretch(1)
        lay.addLayout(row)
        recent = recent_colors()
        if recent:
            lay.addWidget(self._heading("Recent"))
            row = QHBoxLayout()
            row.setSpacing(4)
            for col in recent:
                row.addWidget(self._swatch(col))
            row.addStretch(1)
            lay.addLayout(row)
        line = QFrame()
        line.setFixedHeight(1)
        line.setStyleSheet(f"background:{theme.c('border')};")
        lay.addWidget(line)
        self.more = QToolButton()
        self.more.setObjectName("moreColors")
        self.more.setText("🎨  More colours…")
        self.more.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.more.clicked.connect(self._toggle_custom)
        lay.addWidget(self.more)
        self.custom = self._make_custom()
        self.custom.hide()
        lay.addWidget(self.custom)

    def _heading(self, text):
        l = QLabel(text)
        l.setProperty("heading", True)
        return l

    def _swatch(self, col, size=20, round_=False, tight=False):
        s = Swatch(col, size, round_, current=(self.current == QColor(col).name().lower()))
        if tight:
            s.setFixedSize(size, size - 4)
        s.clicked.connect(lambda checked=False, c=QColor(col): self._choose(c))
        return s

    def _make_custom(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(8)
        self.sv = SVSquare()
        self.hue = HueBar()
        v.addWidget(self.sv)
        v.addWidget(self.hue)
        row = QHBoxLayout()
        self.preview = QLabel()
        self.preview.setFixedSize(28, 28)
        self.hex = QLineEdit()
        self.hex.setPlaceholderText("#RRGGBB")
        self.hex.setFixedWidth(96)
        use = QPushButton("Use colour")
        use.setDefault(True)
        row.addWidget(self.preview)
        row.addWidget(self.hex)
        row.addStretch(1)
        row.addWidget(use)
        v.addLayout(row)
        start = QColor(self.current or "#d61f1f")
        h, s, val, _ = start.getHsvF()
        self.hue.h, self.sv.h, self.sv.s, self.sv.v = max(h, 0), max(h, 0), s, val
        self.sv.changed.connect(self._custom_changed)
        self.hue.changed.connect(self._hue_changed)
        self.hex.textEdited.connect(self._hex_edited)
        self.hex.returnPressed.connect(self._use_custom)
        use.clicked.connect(self._use_custom)
        self._custom_changed()
        return w

    def _toggle_custom(self):
        self.custom.setVisible(not self.custom.isVisible())
        self.adjustSize()
        self._keep_on_screen()

    def _custom_color(self):
        return QColor.fromHsvF(self.sv.h, self.sv.s, self.sv.v)

    def _hue_changed(self):
        self.sv.h = self.hue.h
        self.sv.update()
        self._custom_changed()

    def _custom_changed(self):
        col = self._custom_color()
        self.preview.setStyleSheet(f"background:{col.name()}; border:1px solid {theme.c('border_strong')}; border-radius:6px;")
        if not self.hex.hasFocus():
            self.hex.setText(col.name().upper())

    def _hex_edited(self, text):
        col = QColor(text.strip() if text.strip().startswith("#") else "#" + text.strip())
        if col.isValid() and len(text.strip().lstrip("#")) in (3, 6):
            h, s, v, _ = col.getHsvF()
            self.hue.h = self.sv.h = max(h, 0)
            self.sv.s, self.sv.v = s, v
            self.hue.update()
            self.sv.update()
            self.preview.setStyleSheet(f"background:{col.name()}; border:1px solid {theme.c('border_strong')}; border-radius:6px;")

    def _use_custom(self):
        text = self.hex.text().strip()
        col = QColor(text if text.startswith("#") else "#" + text)
        self._choose(col if col.isValid() else self._custom_color())

    def _choose(self, col):
        remember(col)
        self.picked.emit(QColor(col))
        self.close()

    def _keep_on_screen(self):
        screen = QGuiApplication.screenAt(self.pos()) or QGuiApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry()
        x = min(max(self.x(), area.left()), area.right() - self.width())
        y = min(max(self.y(), area.top()), area.bottom() - self.height())
        self.move(x, y)

    def popup_at(self, global_pos):
        self.adjustSize()
        self.move(global_pos)
        self._keep_on_screen()
        self.show()
        self.raise_()


def pick_color(anchor, current, on_pick, presets=None, title=None, global_pos=None):
    """Open the popup below `anchor` (a widget) or at `global_pos`; calls on_pick(QColor)."""
    pop = ColorPopup(anchor.window() if anchor is not None else None, current, presets, title)
    pop.picked.connect(on_pick)
    if global_pos is None:
        global_pos = anchor.mapToGlobal(QPoint(0, anchor.height() + 2))
    pop.popup_at(global_pos)
    return pop
