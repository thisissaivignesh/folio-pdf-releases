"""Colour themes: Light, Dark grey and Black (high contrast, for AMOLED screens).

Every colour the interface uses comes from the token tables below, so a theme switch
restyles the whole app at once.
"""
from PySide6.QtCore import Qt, QObject, Signal
from PySide6.QtGui import QColor, QPalette, QGuiApplication

LIGHT = {
    "name": "light", "dark": False, "hc": False,
    "bg": "#f7f8fa", "surface": "#ffffff", "surface2": "#f3f4f6",
    "border": "#e3e6ea", "border_strong": "#d5dbe3",
    "text": "#111827", "text2": "#4b5563", "muted": "#6b7280", "disabled": "#a0a7b1",
    "accent": "#1a5fb4", "accent_text": "#ffffff", "accent_soft": "#dbe7fb", "accent_soft_text": "#0f3d80",
    "hover": "#eef1f5", "input_bg": "#ffffff", "button": "#ffffff",
    "canvas": "#e4e7eb", "canvas_soft": "#f4f6f9",
    "banner_bg": "#eef4ff", "banner_border": "#c9d8ef",
    "ok_bg": "#dcfce7", "ok_text": "#166534", "bad_bg": "#fee4e2", "bad_text": "#b42318",
    "icon": "#3c4043", "link": "#1a5fb4",
    "scroll_bg": "transparent", "scroll_handle": "#c4cad3", "scroll_hover": "#a9b0ba",
    "page_shadow": 40, "page_border": "", "dark_page_bg": "#202124",
    "selection": "#2f6fd6", "tab_bar": "#eceef2", "tab_active": "#ffffff",
}

DARK = {
    "name": "dark", "dark": True, "hc": False,
    "bg": "#262624", "surface": "#1f1e1d", "surface2": "#30302e",
    "border": "#3a3936", "border_strong": "#4a4945",
    "text": "#eeedea", "text2": "#c2c0b6", "muted": "#9a988f", "disabled": "#6d6b65",
    "accent": "#5b93f0", "accent_text": "#ffffff", "accent_soft": "#33404f", "accent_soft_text": "#d6e4ff",
    "hover": "#34332f", "input_bg": "#30302e", "button": "#30302e",
    "canvas": "#1a1918", "canvas_soft": "#262624",
    "banner_bg": "#2a3342", "banner_border": "#3a4a63",
    "ok_bg": "#1d3a28", "ok_text": "#8ee0a8", "bad_bg": "#4a2323", "bad_text": "#f6a5a5",
    "icon": "#d9d7d0", "link": "#7fb0ff",
    "scroll_bg": "transparent", "scroll_handle": "#4a4945", "scroll_hover": "#5d5c57",
    "page_shadow": 110, "page_border": "", "dark_page_bg": "#262624",
    "selection": "#5b93f0", "tab_bar": "#1f1e1d", "tab_active": "#262624",
}

BLACK = {
    "name": "black", "dark": True, "hc": True,
    "bg": "#000000", "surface": "#000000", "surface2": "#000000",
    "border": "#6fc3df", "border_strong": "#6fc3df",
    "text": "#ffffff", "text2": "#ffffff", "muted": "#d0d0d0", "disabled": "#8a8a8a",
    "accent": "#f38518", "accent_text": "#000000", "accent_soft": "#000000", "accent_soft_text": "#ffffff",
    "hover": "#000000", "input_bg": "#000000", "button": "#000000",
    "canvas": "#000000", "canvas_soft": "#000000",
    "banner_bg": "#000000", "banner_border": "#6fc3df",
    "ok_bg": "#000000", "ok_text": "#89d185", "bad_bg": "#000000", "bad_text": "#f48771",
    "icon": "#ffffff", "link": "#3794ff",
    "scroll_bg": "#000000", "scroll_handle": "#6f6f6f", "scroll_hover": "#a0a0a0",
    "page_shadow": 0, "page_border": "#6fc3df", "dark_page_bg": "#000000",
    "selection": "#f38518", "tab_bar": "#000000", "tab_active": "#000000",
}

THEMES = {"light": LIGHT, "dark": DARK, "black": BLACK}
CHOICES = [("system", "Match Windows"), ("light", "Light"), ("dark", "Dark grey"),
           ("black", "Black (high contrast)")]


class _Notifier(QObject):
    changed = Signal()


notifier = _Notifier()
_state = {"choice": "light", "tokens": LIGHT}


def tokens():
    return _state["tokens"]


def c(key):
    return _state["tokens"][key]


def qcolor(key, alpha=None):
    col = QColor(_state["tokens"][key])
    if alpha is not None:
        col.setAlpha(alpha)
    return col


def choice():
    return _state["choice"]


def resolve(name):
    if name == "system":
        try:
            scheme = QGuiApplication.styleHints().colorScheme()
            return "dark" if scheme == Qt.ColorScheme.Dark else "light"
        except Exception:
            return "light"
    return name if name in THEMES else "light"


def apply(app, name):
    """Restyle the whole application. Returns the theme actually used."""
    resolved = resolve(name)
    t = THEMES[resolved]
    _state["choice"] = name
    _state["tokens"] = t
    from . import icons
    icons.set_default_color(t["icon"])
    app.setPalette(_palette(t))
    app.setStyleSheet(stylesheet(t))
    notifier.changed.emit()
    return resolved


def _palette(t):
    p = QPalette()
    C = QColor
    roles = {
        QPalette.ColorRole.Window: t["bg"], QPalette.ColorRole.WindowText: t["text"],
        QPalette.ColorRole.Base: t["input_bg"], QPalette.ColorRole.AlternateBase: t["surface2"],
        QPalette.ColorRole.Text: t["text"], QPalette.ColorRole.Button: t["button"],
        QPalette.ColorRole.ButtonText: t["text"], QPalette.ColorRole.Highlight: t["selection"],
        QPalette.ColorRole.HighlightedText: "#ffffff" if t["name"] != "black" else "#000000",
        QPalette.ColorRole.ToolTipBase: t["surface"], QPalette.ColorRole.ToolTipText: t["text"],
        QPalette.ColorRole.PlaceholderText: t["muted"], QPalette.ColorRole.Link: t["link"],
        QPalette.ColorRole.BrightText: "#ffffff",
        QPalette.ColorRole.Light: t["border_strong"], QPalette.ColorRole.Midlight: t["border"],
        QPalette.ColorRole.Mid: t["border_strong"], QPalette.ColorRole.Dark: t["border_strong"],
        QPalette.ColorRole.Shadow: "#000000",
    }
    for role, col in roles.items():
        p.setColor(role, C(col))
    for role in (QPalette.ColorRole.Text, QPalette.ColorRole.WindowText, QPalette.ColorRole.ButtonText):
        p.setColor(QPalette.ColorGroup.Disabled, role, C(t["disabled"]))
    return p


def stylesheet(t):
    hc = t["hc"]
    hover_outline = f"border: 1px dashed {t['accent']};" if hc else ""
    checked_outline = f"border: 1px solid {t['accent']};" if hc else ""
    selected_item = (f"background: #000000; color: #ffffff; border: 1px solid {t['accent']};" if hc
                     else f"background: {t['accent_soft']}; color: {t['text']};")
    return f"""
QMainWindow, QDialog {{ background: {t['bg']}; }}
QWidget {{ color: {t['text']}; }}
QMenuBar {{ background: {t['surface']}; color: {t['text']}; }}
QMenuBar::item {{ background: transparent; padding: 4px 8px; }}
QMenuBar::item:selected {{ background: {t['hover']}; {hover_outline} }}
QMenu {{ background: {t['surface']}; color: {t['text']}; border: 1px solid {t['border_strong']}; padding: 4px; }}
QMenu::item {{ padding: 5px 26px 5px 26px; border-radius: 4px; }}
QMenu::item:selected {{ background: {t['accent_soft']}; color: {t['accent_soft_text']}; {hover_outline} }}
QMenu::item:disabled {{ color: {t['disabled']}; }}
QMenu::separator {{ height: 1px; background: {t['border']}; margin: 4px 8px; }}
QToolBar {{ background: {t['surface']}; border: none; border-bottom: 1px solid {t['border']}; spacing: 2px; padding: 3px 6px; }}
QToolBar::separator {{ background: {t['border']}; width: 1px; margin: 4px 6px; }}
QToolBar QToolButton {{ border: 1px solid transparent; border-radius: 6px; padding: 4px 6px; color: {t['text']}; }}
QToolBar QToolButton:hover {{ background: {t['hover']}; {hover_outline} }}
QToolBar QToolButton:checked {{ background: {t['accent_soft']}; color: {t['accent_soft_text']}; {checked_outline} }}
QToolBar QToolButton:disabled {{ color: {t['disabled']}; }}
QToolBar QToolButton::menu-indicator {{ image: none; width: 0; }}
QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QTextEdit, QTextBrowser {{
    background: {t['input_bg']}; color: {t['text']}; border: 1px solid {t['border_strong']};
    border-radius: 6px; padding: 3px 6px; selection-background-color: {t['selection']};
    selection-color: {'#000000' if hc else '#ffffff'}; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus, QTextEdit:focus {{ border-color: {t['accent']}; }}
QLineEdit:disabled, QComboBox:disabled {{ color: {t['disabled']}; }}
QComboBox QAbstractItemView {{ background: {t['surface']}; color: {t['text']}; border: 1px solid {t['border_strong']};
    selection-background-color: {t['accent_soft']}; selection-color: {t['accent_soft_text']}; }}
QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ padding: 7px 6px; border: none; color: {t['text2']}; background: transparent; }}
QTabBar::tab:hover {{ color: {t['text']}; }}
QTabBar::tab:selected {{ color: {t['accent_soft_text'] if not hc else '#ffffff'}; border-bottom: 2px solid {t['accent']}; }}
QTabBar#docTabBar {{ background: {t['tab_bar']}; }}
QTabBar#docTabBar::tab {{ padding: 7px 10px; margin: 4px 1px 0 1px; border: 1px solid transparent; border-bottom: none;
    border-top-left-radius: 7px; border-top-right-radius: 7px; color: {t['text2']}; background: transparent;
    min-width: 90px; max-width: 240px; }}
QTabBar#docTabBar::tab:hover {{ background: {t['hover']}; }}
QTabBar#docTabBar::tab:selected {{ background: {t['tab_active']}; color: {t['text']};
    border-color: {t['border'] if not hc else t['accent']}; }}
QToolButton#tabClose {{ border: none; border-radius: 4px; padding: 0; background: transparent; }}
QToolButton#tabClose:hover {{ background: {t['hover'] if not hc else '#000000'}; {hover_outline} }}
QTreeWidget, QListWidget {{ border: none; background: {t['surface']}; color: {t['text']}; outline: 0; }}
QTreeWidget::item, QListWidget::item {{ padding: 3px 2px; border: 1px solid transparent; }}
QTreeWidget::item:hover, QListWidget::item:hover {{ background: {t['hover']}; }}
QTreeWidget::item:selected, QListWidget::item:selected {{ {selected_item} }}
QHeaderView::section {{ background: {t['surface']}; color: {t['text2']}; border: none; }}
QSplitter::handle {{ background: {t['border']}; width: 1px; }}
QStatusBar {{ background: {t['surface']}; border-top: 1px solid {t['border']}; color: {t['text2']}; }}
QStatusBar::item {{ border: none; }}
QPushButton {{ padding: 5px 12px; border: 1px solid {t['border_strong']}; border-radius: 6px;
    background: {t['button']}; color: {t['text']}; }}
QPushButton:hover {{ background: {t['hover']}; {hover_outline} }}
QPushButton:default {{ border-color: {t['accent']}; }}
QPushButton:disabled {{ color: {t['disabled']}; }}
QCheckBox, QRadioButton, QLabel {{ color: {t['text']}; background: transparent; }}
QToolTip {{ background: {t['surface']}; color: {t['text']}; border: 1px solid {t['border_strong']}; padding: 4px; }}
QScrollBar:vertical {{ background: {t['scroll_bg']}; width: 12px; margin: 0; }}
QScrollBar:horizontal {{ background: {t['scroll_bg']}; height: 12px; margin: 0; }}
QScrollBar::handle:vertical {{ background: {t['scroll_handle']}; min-height: 32px; border-radius: 4px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {t['scroll_handle']}; min-width: 32px; border-radius: 4px; margin: 2px; }}
QScrollBar::handle:hover {{ background: {t['scroll_hover']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}
QAbstractScrollArea::corner {{ background: {t['canvas']}; }}
QProgressBar {{ border: 1px solid {t['border_strong']}; border-radius: 5px; background: {t['surface2']};
    color: {t['text']}; text-align: center; }}
QProgressBar::chunk {{ background: {t['accent']}; border-radius: 4px; }}
#panelStrip {{ background: {t['surface']}; border-bottom: 1px solid {t['border']}; }}
#banner {{ background: {t['banner_bg']}; border-bottom: 1px solid {t['banner_border']}; }}
#welcome {{ background: {t['canvas_soft']}; }}
QPushButton[class="big"] {{ text-align: left; padding: 14px 18px; border: 1px solid {t['border_strong']};
    border-radius: 10px; background: {t['surface']}; font-size: 14px; }}
QPushButton[class="big"]:hover {{ border-color: {t['accent']}; background: {t['hover']}; }}
#welcomeTitle {{ font-size: 28px; font-weight: 600; color: {t['text']}; }}
#welcomeSub {{ color: {t['muted']}; font-size: 13px; margin-bottom: 10px; }}
#recentLabel {{ color: {t['text2']}; font-weight: 600; margin-top: 10px; }}
#recentList {{ border: 1px solid {t['border_strong']}; border-radius: 8px; background: {t['surface']}; }}
#recentList::item {{ padding: 5px; }}
QLabel[muted="true"] {{ color: {t['muted']}; }}
#toolHint {{ color: {t['muted']}; padding-left: 10px; }}
#emptyHint {{ color: {t['muted']}; padding: 18px; }}
#updateBtn {{ background: {t['accent']}; color: {t['accent_text']}; border: none; border-radius: 5px; padding: 2px 10px; }}
#searchStatus[kind="found"] {{ color: {t['ok_text']}; background: {t['ok_bg']}; border-radius: 6px; padding: 6px 8px;
    {('border: 1px solid ' + t['ok_text'] + ';') if hc else ''} }}
#searchStatus[kind="missing"] {{ color: {t['bad_text']}; background: {t['bad_bg']}; border-radius: 6px; padding: 6px 8px;
    {('border: 1px solid ' + t['bad_text'] + ';') if hc else ''} }}
#searchStatus[kind="info"] {{ color: {t['text2']}; background: transparent; padding: 6px 8px; }}
#colorPopup {{ background: {t['surface']}; border: 1px solid {t['border_strong']}; border-radius: 8px; }}
#colorPopup QLabel[heading="true"] {{ font-weight: 600; color: {t['text']}; padding-top: 2px; }}
#colorPopup QToolButton#moreColors {{ border: none; padding: 6px 4px; text-align: left; color: {t['text']}; border-radius: 5px; }}
#colorPopup QToolButton#moreColors:hover {{ background: {t['hover']}; }}
#colorButton {{ border: 1px solid transparent; border-radius: 6px; padding: 4px 8px; }}
#colorButton:hover {{ background: {t['hover']}; {hover_outline} }}
"""
