"""Per-file lists kept in the user's app-data folder: reader bookmarks and saved highlights.

The folder name stays "FolioPDF\\Folio PDF" (the app's old name) so nothing is lost after the rename.
"""
import json
import os

from PySide6.QtCore import QStandardPaths


def data_folder():
    base = os.environ.get("APPDATA")
    if base:
        folder = os.path.join(base, "FolioPDF", "Folio PDF")
    else:
        base = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.GenericDataLocation) \
            or os.path.join(os.path.expanduser("~"), ".local", "share")
        folder = os.path.join(base, "FolioPDF", "Folio PDF")
    os.makedirs(folder, exist_ok=True)
    return folder


class JsonStore:
    def __init__(self, path):
        self.path = path
        self.data = {}
        self._mtime = None
        self._reload()

    def _reload(self):
        try:
            mtime = os.path.getmtime(self.path)
        except OSError:
            return
        if mtime == self._mtime:
            return
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                self.data = json.load(f)
            self._mtime = mtime
        except (OSError, ValueError):
            pass

    def get(self, key):
        self._reload()
        return [dict(x) for x in self.data.get(key, [])] if key else []

    def put(self, key, items):
        if not key:
            return
        self._reload()
        if items:
            self.data[key] = items
        else:
            self.data.pop(key, None)
        self._write()

    def move(self, old_key, new_key):
        self._reload()
        if old_key and new_key and old_key != new_key and old_key in self.data:
            self.data[new_key] = self.data.get(new_key, []) + self.data[old_key]
            self._write()

    def _write(self):
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, self.path)
        try:
            self._mtime = os.path.getmtime(self.path)
        except OSError:
            pass


class BookmarkStore(JsonStore):
    def __init__(self, path=None):
        super().__init__(path or os.path.join(data_folder(), "bookmarks.json"))


class HighlightStore(JsonStore):
    def __init__(self, path=None):
        super().__init__(path or os.path.join(data_folder(), "highlights.json"))


_shared = {}


def bookmarks():
    if "b" not in _shared:
        _shared["b"] = BookmarkStore()
    return _shared["b"]


def highlights():
    if "h" not in _shared:
        _shared["h"] = HighlightStore()
    return _shared["h"]
