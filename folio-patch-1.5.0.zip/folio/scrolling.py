"""A top speed for touchpad scrolling, whatever the touchpad driver sends.

Scrolling slower than the limit is passed through untouched. Anything faster (a fling, or a driver's
"edge glide") moves the page at exactly the limit, from the first event: there is no detection or
measuring step. Distance beyond the limit is dropped rather than saved up, so the page stops the
moment the touchpad stops. A mouse wheel (whole notches) is never limited.
Pure Python, no Qt: tested directly.
"""

# (settings key, menu label, top speed in screen-heights per second; None = no limit)
PRESETS = [
    ("slow", "Slow", 1.0),
    ("medium", "Medium (Recommended)", 2.0),
    ("fast", "Fast", 3.0),
    ("faster", "Very fast", 5.0),
    ("off", "No limit", None),
]
DEFAULT = "medium"


def screens_per_second(key):
    for k, label, v in PRESETS:
        if k == key:
            return v
    return screens_per_second(DEFAULT)


class SpeedLimit:
    GAP_S = 0.1           # no events for this long = a new swipe; it starts with a little slack
    SLACK_S = 0.05        # timing slack, so uneven event delivery doesn't cause stutter

    def __init__(self):
        self.screens = screens_per_second(DEFAULT)
        self._last = -1e9
        self._budget = 0.0
        self._notches_only = True

    @property
    def enabled(self):
        return self.screens is not None

    def feed(self, px, now, viewport_h, notch=False):
        """px: distance the driver asked for (signed). Returns the distance to scroll."""
        if px == 0 or self.screens is None:
            return px
        cap = self.screens * max(viewport_h, 100)          # px per second
        gap = now - self._last
        self._last = now
        if gap > self.GAP_S or gap < 0:
            self._notches_only = True
            self._budget = cap * self.SLACK_S
        else:
            self._budget = min(self._budget + cap * gap, cap * self.SLACK_S)
        self._notches_only = self._notches_only and notch
        if self._notches_only:
            return px
        move = min(abs(px), self._budget)
        self._budget -= move
        return move if px > 0 else -move


class EdgeGlide:
    """Olai's own touchpad edge glide, from finger positions (see touchpad.py).

    When your fingers, while scrolling, reach the top or bottom edge zone of the pad they were moving
    towards, the page keeps moving at the speed it was scrolling (capped by the speed limit) from that
    very moment. It stops the instant you lift your fingers or move them back out of the zone. While
    Olai glides, the touchpad driver's scroll messages (including its own, delayed glide) are ignored.

    Without finger positions (no frames ever arrive) everything passes straight through, so the
    driver's behaviour is used unchanged.
    """
    ZONE = 0.12           # edge zone: this share of the pad's height at the top and at the bottom
    LEAVE = 0.03          # fingers must come this much further out of the zone to stop the glide
    RECENT_S = 0.15       # you count as scrolling if a scroll arrived this recently
    SPEED_S = 0.12        # the scroll speed is measured over this much recent scrolling
    LIFT_S = 0.08         # no finger reports for this long = fingers lifted
    MIN_SPEED = 30.0      # px/s; slowest glide

    def __init__(self):
        self.enabled = True
        self.gliding = False
        self.velocity = 0.0           # px/s, signed like the scroll distances
        self.last_wheel_t = -1e9
        self._wheel = []              # (time, px) recent scrolls as applied
        self._touch_t = -1e9
        self._fingers = 0
        self._y = None                # fingers' average height, 0 = top of pad
        self._start_y = None          # where the current touch started
        self._dir_y = 0               # which way the fingers have been moving: -1 up, +1 down

    def has_fingers(self, now):
        return now - self._touch_t < 1.0

    def on_touch(self, now, contacts):
        """contacts: [(id, x, y)] currently touching, x/y from 0 to 1."""
        self._touch_t = now
        if not contacts:
            self._fingers, self._y, self._start_y, self._dir_y = 0, None, None, 0
            self._stop()
            return
        y = sum(c[2] for c in contacts) / len(contacts)
        if len(contacts) != self._fingers or self._y is None:
            self._start_y = y              # fingers put down (or a finger added/removed)
            self._dir_y = 0
        elif abs(y - self._y) > 0.002:
            self._dir_y = 1 if y > self._y else -1
        self._fingers, self._y = len(contacts), y
        if self.gliding:
            if self._out_of_zone(y, self.LEAVE):
                self._stop()
        else:
            self._maybe_start(now)

    def _edge(self, y):
        if y <= self.ZONE:
            return -1
        if y >= 1 - self.ZONE:
            return 1
        return 0

    def _out_of_zone(self, y, slack):
        return self.ZONE + slack < y < 1 - self.ZONE - slack

    def _speed(self, now):
        recent = [(t, px) for t, px in self._wheel if now - t <= self.SPEED_S]
        if len(recent) < 2:
            return 0.0
        span = recent[-1][0] - recent[0][0]      # each scroll covers the time since the previous one
        return sum(px for t, px in recent[1:]) / span if span > 1e-3 else 0.0

    def _maybe_start(self, now):
        if not self.enabled or self._y is None or self._start_y is None or self._fingers < 1:
            return
        edge = self._edge(self._y)
        if not edge or self._edge(self._start_y) == edge:
            return                         # must arrive at the edge, not start there
        moved_towards = (self._y - self._start_y) * edge > 0 and self._dir_y in (0, edge)
        if not moved_towards or not self._wheel or now - self._wheel[-1][0] > self.RECENT_S:
            return
        v = self._speed(now)
        if v == 0:
            return
        sign = 1 if v > 0 else -1
        self.velocity = sign * max(abs(v), self.MIN_SPEED)
        self.gliding = True

    def _stop(self):
        self.gliding = False
        self.velocity = 0.0

    def on_wheel(self, now, px):
        """A scroll from the driver (after the speed limit). Returns what to apply now."""
        self.last_wheel_t = now
        if self.gliding:
            if px and (px > 0) != (self.velocity > 0):
                self._stop()               # scrolling the other way: hand control back
            else:
                return 0.0
        self._wheel.append((now, px))
        self._wheel = [(t, p) for t, p in self._wheel if now - t <= 0.5]
        if not self.gliding and self.has_fingers(now):
            self._maybe_start(now)
            if self.gliding:
                return 0.0
        return px

    def tick(self, now, dt, cap=None):
        """Distance to glide in this animation step."""
        if not self.gliding:
            return 0.0
        if now - self._touch_t > self.LIFT_S:
            self._stop()                   # finger reports stopped: treat as lifted
            return 0.0
        v = self.velocity
        if cap is not None and abs(v) > cap:
            v = cap if v > 0 else -cap
        return v * dt


class SmoothScroll:
    """Spreads each scroll step over a few milliseconds so the page glides instead of jumping."""
    TAU_S = 0.03          # time constant of the easing

    def __init__(self):
        self.enabled = True
        self.pending = 0.0

    def add(self, px):
        self.pending += px

    def step(self, dt):
        if not self.enabled or abs(self.pending) < 0.5:
            px, self.pending = self.pending, 0.0
            return px
        import math
        px = self.pending * (1 - math.exp(-max(dt, 0.0) / self.TAU_S))
        self.pending -= px
        return px

    @property
    def busy(self):
        return abs(self.pending) >= 0.01


class ScrollWatch:
    """Safety net for reading the touchpad: if two-finger swipes stop producing any scrolling while
    Olai reads finger positions (it shouldn't happen, but touchpads differ), Olai stops reading them."""
    MOVED = 0.2           # a swipe across this share of the pad should always scroll
    STRIKES = 3

    def __init__(self):
        self.strikes = 0
        self._t0 = None
        self._y0 = 0.0
        self._moved = 0.0

    def on_touch(self, now, contacts, last_wheel_t):
        """Returns True when finger reading should be switched off."""
        if len(contacts) >= 2:
            y = sum(c[2] for c in contacts) / len(contacts)
            if self._t0 is None:
                self._t0, self._y0, self._moved = now, y, 0.0
            self._moved = max(self._moved, abs(y - self._y0))
            return False
        if self._t0 is not None:
            if last_wheel_t >= self._t0:
                self.strikes = 0
            elif self._moved > self.MOVED:
                self.strikes += 1
            self._t0 = None
        return self.strikes >= self.STRIKES
