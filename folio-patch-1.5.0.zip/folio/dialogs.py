"""Dialogs: add text, signature pad, photos-to-PDF, new blank PDF."""
import os

from PySide6.QtCore import Qt, QPointF, QSize, QBuffer, QByteArray, QIODevice
from PySide6.QtGui import QColor, QPainter, QPen, QImage, QPainterPath, QPolygonF
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QPlainTextEdit,
                               QSpinBox, QPushButton, QDialogButtonBox, QLabel,
                               QWidget, QListWidget, QListWidgetItem, QComboBox, QCheckBox,
                               QFileDialog, QAbstractItemView, QTextBrowser)

from .icons import icon
from .colorpicker import pick_color, dot_icon, PEN
from . import theme
from .convert import IMAGE_EXT


def _color_button(initial):
    btn = QPushButton("  Colour")
    btn.color = QColor(initial)

    def paint():
        btn.setIcon(dot_icon(btn.color.name(), 18))

    def chosen(c):
        btn.color = QColor(c)
        paint()

    btn.clicked.connect(lambda: pick_color(btn, btn.color.name(), chosen, presets=PEN, title="Text colours"))
    paint()
    return btn


class TextDialog(QDialog):
    def __init__(self, parent, size=12, color="#111111"):
        super().__init__(parent)
        self.setWindowTitle("Add text")
        lay = QVBoxLayout(self)
        self.text = QPlainTextEdit()
        self.text.setPlaceholderText("Type the text to place on the page…")
        self.text.setMinimumSize(380, 120)
        lay.addWidget(self.text)
        form = QFormLayout()
        self.size = QSpinBox()
        self.size.setRange(4, 144)
        self.size.setValue(size)
        form.addRow("Font size", self.size)
        self.color = _color_button(color)
        form.addRow("Colour", self.color)
        lay.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        self.text.setFocus()

    def values(self):
        c = self.color.color
        return self.text.toPlainText(), self.size.value(), (c.redF(), c.greenF(), c.blueF())


class SignaturePad(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumSize(460, 170)
        self.strokes = []
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.pen_color = QColor("#0b2a6f")

    def clear(self):
        self.strokes = []
        self.update()

    def mousePressEvent(self, e):
        self.strokes.append([e.position()])

    def mouseMoveEvent(self, e):
        if self.strokes:
            self.strokes[-1].append(e.position())
            self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), Qt.GlobalColor.white)
        p.setPen(QPen(QColor("#c7cdd6"), 1, Qt.PenStyle.DashLine))
        y = self.height() - 40
        p.drawLine(20, y, self.width() - 20, y)
        self._draw(p, 1.0)

    def _draw(self, p, scale, offset=QPointF(0, 0)):
        p.setPen(QPen(self.pen_color, 2.6 * scale, Qt.PenStyle.SolidLine,
                      Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        for s in self.strokes:
            pts = [(pt - offset) * scale for pt in s]
            if len(pts) == 1:
                p.drawPoint(pts[0])
            else:
                p.drawPolyline(QPolygonF(pts))

    def png_bytes(self):
        """Transparent PNG cropped to the ink, at 3x resolution."""
        pts = [pt for s in self.strokes for pt in s]
        if not pts:
            return None
        pad = 6
        x0 = min(p.x() for p in pts) - pad
        y0 = min(p.y() for p in pts) - pad
        x1 = max(p.x() for p in pts) + pad
        y1 = max(p.y() for p in pts) + pad
        scale = 3
        img = QImage(int((x1 - x0) * scale), int((y1 - y0) * scale), QImage.Format.Format_ARGB32)
        img.fill(Qt.GlobalColor.transparent)
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        self._draw(p, scale, QPointF(x0, y0))
        p.end()
        ba = QByteArray()
        buf = QBuffer(ba)
        buf.open(QIODevice.OpenModeFlag.WriteOnly)
        img.save(buf, "PNG")
        buf.close()
        return bytes(ba), (x1 - x0) / (y1 - y0)


class SignatureDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Draw your signature")
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Sign with your mouse, touchpad or pen. Then drag a box on the page to place it."))
        self.pad = SignaturePad()
        lay.addWidget(self.pad)
        row = QHBoxLayout()
        clear = QPushButton("Clear")
        clear.clicked.connect(self.pad.clear)
        row.addWidget(clear)
        load = QPushButton("Use an image instead…")
        load.clicked.connect(self._load)
        row.addWidget(load)
        row.addStretch(1)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        row.addWidget(bb)
        lay.addLayout(row)
        self.result_png = None

    def _load(self):
        path, _ = QFileDialog.getOpenFileName(self, "Signature image", "", "Images (*.png *.jpg *.jpeg)")
        if path:
            with open(path, "rb") as f:
                data = f.read()
            img = QImage(path)
            ratio = img.width() / max(img.height(), 1) if not img.isNull() else 3.0
            self.result_png = (data, ratio)
            super().accept()

    def accept(self):
        self.result_png = self.pad.png_bytes()
        super().accept()


class ImagesToPdfDialog(QDialog):
    def __init__(self, parent, paths=None):
        super().__init__(parent)
        self.setWindowTitle("Photos to PDF")
        self.resize(560, 480)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Each photo becomes one page. Drag to change the order."))
        self.list = QListWidget()
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.list.setIconSize(QSize(56, 56))
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        lay.addWidget(self.list, 1)
        row = QHBoxLayout()
        add = QPushButton(icon("plus"), "Add photos…")
        add.clicked.connect(self.add)
        rem = QPushButton(icon("delete"), "Remove")
        rem.clicked.connect(self.remove)
        row.addWidget(add)
        row.addWidget(rem)
        row.addStretch(1)
        lay.addLayout(row)
        form = QFormLayout()
        self.size = QComboBox()
        self.size.addItems(["Fit to photo", "A4", "Letter", "Legal", "A5"])
        form.addRow("Page size", self.size)
        self.margin = QComboBox()
        self.margin.addItems(["None", "Small (0.5 cm)", "Normal (1.5 cm)"])
        form.addRow("Margin", self.margin)
        self.shrink = QCheckBox("Reduce file size (recommended for phone photos)")
        self.shrink.setChecked(True)
        form.addRow("", self.shrink)
        lay.addLayout(form)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.button(QDialogButtonBox.StandardButton.Ok).setText("Create PDF")
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
        for p in paths or []:
            self._add_path(p)

    def _add_path(self, p):
        it = QListWidgetItem(os.path.basename(p))
        it.setToolTip(p)
        it.setData(Qt.ItemDataRole.UserRole, p)
        img = QImage(p)
        if not img.isNull():
            from PySide6.QtGui import QPixmap, QIcon
            it.setIcon(QIcon(QPixmap.fromImage(img.scaled(112, 112, Qt.AspectRatioMode.KeepAspectRatio,
                                                          Qt.TransformationMode.SmoothTransformation))))
        else:
            it.setIcon(icon("image"))
        self.list.addItem(it)

    def add(self):
        exts = " ".join("*" + e for e in sorted(IMAGE_EXT))
        paths, _ = QFileDialog.getOpenFileNames(self, "Choose photos", "", f"Images ({exts})")
        for p in paths:
            self._add_path(p)

    def remove(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))

    def accept(self):
        if self.list.count() == 0:
            return
        super().accept()

    def values(self):
        paths = [self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())]
        margin = [0, 14, 42][self.margin.currentIndex()]
        return paths, self.size.currentText(), margin, self.shrink.isChecked()


class NewPdfDialog(QDialog):
    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("New blank PDF")
        form = QFormLayout(self)
        self.size = QComboBox()
        self.size.addItems(["A4", "Letter", "Legal", "A5"])
        form.addRow("Page size", self.size)
        self.orient = QComboBox()
        self.orient.addItems(["Portrait", "Landscape"])
        form.addRow("Orientation", self.orient)
        self.pages = QSpinBox()
        self.pages.setRange(1, 500)
        self.pages.setValue(1)
        form.addRow("Pages", self.pages)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        form.addRow(bb)

    def values(self):
        return self.size.currentText(), self.orient.currentText() == "Landscape", self.pages.value()


class UpdateDialog(QDialog):
    def __init__(self, parent, current, upd):
        super().__init__(parent)
        self.setWindowTitle("Update available")
        self.resize(480, 360)
        lay = QVBoxLayout(self)
        head = QLabel(f"<b style='font-size:14px'>Olai {upd.version} is available</b><br>"
                      f"<span style='color:{theme.c('muted')}'>You have version {current}.</span>")
        lay.addWidget(head)
        notes = QTextBrowser()
        notes.setOpenExternalLinks(True)
        notes.setMarkdown(upd.notes or "Bug fixes and improvements.")
        lay.addWidget(notes, 1)
        if upd.kind == "patch":
            how = (f"Quick update: {upd.size_text()}. Olai checks it, then asks to restart. "
                   "If anything goes wrong you can undo it from the Help menu.")
        else:
            how = (f"This update includes new built-in components, so it uses the full installer "
                   f"({upd.size_text()}). Olai will close, update and reopen by itself.")
        info = QLabel(how)
        info.setWordWrap(True)
        info.setProperty("muted", True)
        lay.addWidget(info)
        bb = QDialogButtonBox()
        bb.addButton("Install now", QDialogButtonBox.ButtonRole.AcceptRole).setDefault(True)
        bb.addButton("Later", QDialogButtonBox.ButtonRole.RejectRole)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)
