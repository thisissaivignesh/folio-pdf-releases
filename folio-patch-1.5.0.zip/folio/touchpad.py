"""Finger positions straight from a Windows precision touchpad (raw HID input).

Windows only tells ordinary apps "scroll by this much"; it doesn't say where the fingers are. To glide the
instant the fingers reach the pad's edge, Olai also asks Windows for the touchpad's own reports
(raw input, HID usage page 0x0D "Digitizer", usage 0x05 "Touch Pad") and reads each finger's
tip switch, X and Y with hid.dll. This only *reads*: the touchpad keeps working normally everywhere.

Anything unexpected (not Windows, no precision touchpad, a report that can't be parsed) simply
means no frames are delivered, and Olai falls back to the touchpad driver's own behaviour.

Frames are delivered as  callback(time, [(contact_id, x, y), ...])  with x, y from 0 to 1
(0, 0 = top left of the pad), listing the fingers currently touching.
"""
import sys
import time

WM_INPUT = 0x00FF
RID_INPUT = 0x10000003
RIM_TYPEHID = 2
RIDI_PREPARSEDDATA = 0x20000005
HIDP_STATUS_SUCCESS = 0x00110000
PAGE_DIGITIZER, PAGE_DESKTOP = 0x0D, 0x01
USAGE_TOUCHPAD, USAGE_TIP, USAGE_CONTACT_ID, USAGE_CONTACT_COUNT = 0x05, 0x42, 0x51, 0x54
USAGE_X, USAGE_Y = 0x30, 0x31

_reader = None


def reader():
    """The app-wide reader (created on first use)."""
    global _reader
    if _reader is None:
        _reader = TouchpadReader()
    return _reader


class _Device:
    """What we learned about one touchpad from its report descriptor."""

    def __init__(self, preparsed, buf, fingers):
        self.preparsed = preparsed      # keeps the buffer alive
        self.buf = buf
        self.fingers = fingers          # [(link collection, xmin, xmax, ymin, ymax, has_id)]
        self.contacts = {}              # id -> (x, y, time) for hybrid-mode reports
        self.expected = 0


class TouchpadReader:
    STALE_S = 0.1          # a finger not reported for this long has lifted

    def __init__(self):
        self.ok = False                 # registered with Windows
        self.seen = False               # at least one touchpad frame has arrived
        self.error = ""
        self.callback = None
        self._devices = {}
        self._filter = None
        self._bad = set()

    @property
    def status(self):
        if self.seen:
            return "reading finger positions from the touchpad"
        if self.ok:
            return "waiting for a precision touchpad"
        return "not available" + (f" ({self.error})" if self.error else "")

    # ------------------------------------------------------------------ setup
    def start(self, app):
        if sys.platform != "win32" or self.ok:
            return self.ok
        try:
            import ctypes
            from ctypes import wintypes
            from PySide6.QtCore import QAbstractNativeEventFilter
            self._ct, self._wt = ctypes, wintypes
            self._setup_api()

            class RAWINPUTDEVICE(ctypes.Structure):
                _fields_ = [("usUsagePage", wintypes.USHORT), ("usUsage", wintypes.USHORT),
                            ("dwFlags", wintypes.DWORD), ("hwndTarget", wintypes.HWND)]
            self._RID = RAWINPUTDEVICE
            dev = RAWINPUTDEVICE(PAGE_DIGITIZER, USAGE_TOUCHPAD, 0, None)   # follows keyboard focus
            if not self._user32.RegisterRawInputDevices(ctypes.addressof(dev), 1, ctypes.sizeof(dev)):
                self.error = f"Windows error {ctypes.get_last_error()}"
                return False
            outer = self

            class Filter(QAbstractNativeEventFilter):
                def nativeEventFilter(self, event_type, message):
                    try:
                        kind = event_type.data() if hasattr(event_type, "data") else bytes(event_type)
                        if outer.ok and bytes(kind) == b"windows_generic_MSG":
                            msg = wintypes.MSG.from_address(int(message))
                            if msg.message == WM_INPUT:
                                outer._on_input(msg.lParam)
                    except Exception as e:          # never let a bad report disturb the app
                        outer.error = str(e)[:80]
                    return False, 0

            self._filter = Filter()
            app.installNativeEventFilter(self._filter)
            self.ok = True
        except Exception as e:
            self.error = str(e)[:80]
            self.ok = False
        return self.ok

    def stop(self, reason=""):
        """Stop reading the touchpad (Olai then uses the driver's own glide)."""
        if not self.ok:
            return
        self.ok = False
        self.seen = False
        self.error = reason
        try:
            ct = self._ct
            dev = self._RID(PAGE_DIGITIZER, USAGE_TOUCHPAD, 0x00000001, None)    # RIDEV_REMOVE
            self._user32.RegisterRawInputDevices(ct.addressof(dev), 1, ct.sizeof(dev))
        except Exception:
            pass

    def _setup_api(self):
        ct, wt = self._ct, self._wt
        u = ct.WinDLL("user32", use_last_error=True)
        u.RegisterRawInputDevices.argtypes = [ct.c_void_p, wt.UINT, wt.UINT]
        u.RegisterRawInputDevices.restype = wt.BOOL
        u.GetRawInputData.argtypes = [wt.HANDLE, wt.UINT, ct.c_void_p, ct.POINTER(wt.UINT), wt.UINT]
        u.GetRawInputData.restype = wt.UINT
        u.GetRawInputDeviceInfoW.argtypes = [wt.HANDLE, wt.UINT, ct.c_void_p, ct.POINTER(wt.UINT)]
        u.GetRawInputDeviceInfoW.restype = wt.UINT
        self._user32 = u
        h = ct.WinDLL("hid")
        h.HidP_GetCaps.argtypes = [ct.c_void_p, ct.c_void_p]
        h.HidP_GetCaps.restype = ct.c_long
        h.HidP_GetValueCaps.argtypes = [ct.c_int, ct.c_void_p, ct.POINTER(wt.USHORT), ct.c_void_p]
        h.HidP_GetValueCaps.restype = ct.c_long
        h.HidP_GetUsageValue.argtypes = [ct.c_int, wt.USHORT, wt.USHORT, wt.USHORT, ct.POINTER(wt.ULONG),
                                         ct.c_void_p, ct.c_void_p, wt.ULONG]
        h.HidP_GetUsageValue.restype = ct.c_long
        h.HidP_GetUsages.argtypes = [ct.c_int, wt.USHORT, wt.USHORT, ct.POINTER(wt.USHORT), ct.POINTER(wt.ULONG),
                                     ct.c_void_p, ct.c_void_p, wt.ULONG]
        h.HidP_GetUsages.restype = ct.c_long
        self._hid = h

        class HIDP_CAPS(ct.Structure):
            _fields_ = [("Usage", wt.USHORT), ("UsagePage", wt.USHORT), ("InputReportByteLength", wt.USHORT),
                        ("OutputReportByteLength", wt.USHORT), ("FeatureReportByteLength", wt.USHORT),
                        ("Reserved", wt.USHORT * 17), ("NumberLinkCollectionNodes", wt.USHORT),
                        ("NumberInputButtonCaps", wt.USHORT), ("NumberInputValueCaps", wt.USHORT),
                        ("NumberInputDataIndices", wt.USHORT), ("NumberOutputButtonCaps", wt.USHORT),
                        ("NumberOutputValueCaps", wt.USHORT), ("NumberOutputDataIndices", wt.USHORT),
                        ("NumberFeatureButtonCaps", wt.USHORT), ("NumberFeatureValueCaps", wt.USHORT),
                        ("NumberFeatureDataIndices", wt.USHORT)]

        class HIDP_VALUE_CAPS(ct.Structure):
            _fields_ = [("UsagePage", wt.USHORT), ("ReportID", ct.c_ubyte), ("IsAlias", ct.c_ubyte),
                        ("BitField", wt.USHORT), ("LinkCollection", wt.USHORT), ("LinkUsage", wt.USHORT),
                        ("LinkUsagePage", wt.USHORT), ("IsRange", ct.c_ubyte), ("IsStringRange", ct.c_ubyte),
                        ("IsDesignatorRange", ct.c_ubyte), ("IsAbsolute", ct.c_ubyte), ("HasNull", ct.c_ubyte),
                        ("Reserved", ct.c_ubyte), ("BitSize", wt.USHORT), ("ReportCount", wt.USHORT),
                        ("Reserved2", wt.USHORT * 5), ("UnitsExp", wt.ULONG), ("Units", wt.ULONG),
                        ("LogicalMin", ct.c_long), ("LogicalMax", ct.c_long),
                        ("PhysicalMin", ct.c_long), ("PhysicalMax", ct.c_long),
                        ("UsageMin", wt.USHORT), ("UsageMax", wt.USHORT), ("Rest", wt.USHORT * 6)]
        self._HIDP_CAPS, self._HIDP_VALUE_CAPS = HIDP_CAPS, HIDP_VALUE_CAPS

    # ------------------------------------------------------------------ reports
    def _device(self, handle):
        if handle in self._devices:
            return self._devices[handle]
        if handle in self._bad:
            return None
        ct, wt = self._ct, self._wt
        try:
            size = wt.UINT(0)
            self._user32.GetRawInputDeviceInfoW(handle, RIDI_PREPARSEDDATA, None, ct.byref(size))
            if not size.value:
                raise OSError("no report descriptor")
            buf = ct.create_string_buffer(size.value)
            if self._user32.GetRawInputDeviceInfoW(handle, RIDI_PREPARSEDDATA, ct.addressof(buf),
                                                   ct.byref(size)) in (0, 0xFFFFFFFF):
                raise OSError("report descriptor unreadable")
            caps = self._HIDP_CAPS()
            if self._hid.HidP_GetCaps(ct.addressof(buf), ct.addressof(caps)) != HIDP_STATUS_SUCCESS:
                raise OSError("no caps")
            n = wt.USHORT(caps.NumberInputValueCaps)
            vcaps = (self._HIDP_VALUE_CAPS * max(n.value, 1))()
            if self._hid.HidP_GetValueCaps(0, ct.addressof(vcaps), ct.byref(n), ct.addressof(buf)) != HIDP_STATUS_SUCCESS:
                raise OSError("no value caps")
            per_lc = {}
            for vc in vcaps[:n.value]:
                usages = range(vc.UsageMin, vc.UsageMax + 1) if vc.IsRange else [vc.UsageMin]
                for usage in usages:
                    per_lc.setdefault(vc.LinkCollection, {})[(vc.UsagePage, usage)] = (vc.LogicalMin, vc.LogicalMax)
            fingers = []
            for lc, found in sorted(per_lc.items()):
                x, y = found.get((PAGE_DESKTOP, USAGE_X)), found.get((PAGE_DESKTOP, USAGE_Y))
                if x and y and x[1] > x[0] and y[1] > y[0]:
                    fingers.append((lc, x[0], x[1], y[0], y[1], (PAGE_DIGITIZER, USAGE_CONTACT_ID) in found))
            if not fingers:
                raise OSError("no finger positions in reports")
            dev = _Device(buf, buf, fingers)
            self._devices[handle] = dev
            return dev
        except Exception as e:
            self.error = str(e)[:80]
            self._bad.add(handle)
            return None

    def _value(self, dev, page, lc, usage, report, length):
        v = self._wt.ULONG(0)
        ct = self._ct
        r = self._hid.HidP_GetUsageValue(0, page, lc, usage, ct.byref(v), ct.addressof(dev.buf),
                                         ct.addressof(report), length)
        return v.value if r == HIDP_STATUS_SUCCESS else None

    def _tip(self, dev, lc, report, length):
        ct, wt = self._ct, self._wt
        usages = (wt.USHORT * 32)()
        n = wt.ULONG(32)
        r = self._hid.HidP_GetUsages(0, PAGE_DIGITIZER, lc, usages, ct.byref(n), ct.addressof(dev.buf),
                                     ct.addressof(report), length)
        return r == HIDP_STATUS_SUCCESS and USAGE_TIP in usages[:n.value]

    def _on_input(self, lparam):
        ct, wt = self._ct, self._wt
        size = wt.UINT(0)
        header = 8 + 2 * ct.sizeof(ct.c_void_p)            # RAWINPUTHEADER
        self._user32.GetRawInputData(lparam, RID_INPUT, None, ct.byref(size), header)
        if not size.value:
            return
        buf = ct.create_string_buffer(size.value)
        if self._user32.GetRawInputData(lparam, RID_INPUT, ct.addressof(buf), ct.byref(size), header) != size.value:
            return
        kind = ct.c_uint32.from_buffer(buf, 0).value
        if kind != RIM_TYPEHID:
            return
        handle = ct.c_void_p.from_buffer(buf, 8).value
        dev = self._device(handle)
        if dev is None:
            return
        size_hid = ct.c_uint32.from_buffer(buf, header).value
        count = ct.c_uint32.from_buffer(buf, header + 4).value
        now = time.monotonic()
        for i in range(count):
            off = header + 8 + i * size_hid
            report = (ct.c_char * size_hid).from_buffer(buf, off)
            self._parse(dev, report, size_hid, now)
        live = [(cid, x, y) for cid, (x, y, t) in dev.contacts.items() if now - t < self.STALE_S]
        dev.contacts = {cid: v for cid, v in dev.contacts.items() if now - v[2] < self.STALE_S}
        self.seen = True
        if self.callback:
            self.callback(now, live)

    def _parse(self, dev, report, length, now):
        slots = len(dev.fingers)
        count = self._value(dev, PAGE_DIGITIZER, 0, USAGE_CONTACT_COUNT, report, length)
        if count:                       # first report of a frame
            dev.remaining = count
            first = True
        else:                           # a continuation report (hybrid mode) or a device without counts
            first = False
            if count is None:
                dev.remaining = slots
        valid = min(slots, getattr(dev, "remaining", slots))
        dev.remaining = max(0, getattr(dev, "remaining", slots) - valid)
        listed = set()
        for lc, x0, x1, y0, y1, has_id in dev.fingers[:valid]:
            cid = self._value(dev, PAGE_DIGITIZER, lc, USAGE_CONTACT_ID, report, length) if has_id else lc
            if cid is None:
                cid = lc
            listed.add(cid)
            if not self._tip(dev, lc, report, length):
                dev.contacts.pop(cid, None)
                continue
            x = self._value(dev, PAGE_DESKTOP, lc, USAGE_X, report, length)
            y = self._value(dev, PAGE_DESKTOP, lc, USAGE_Y, report, length)
            if x is None or y is None:
                continue
            dev.contacts[cid] = ((x - x0) / (x1 - x0), (y - y0) / (y1 - y0), now)
        if first and count <= slots:
            # the whole frame fitted in this report: fingers not listed have lifted
            for cid in [c for c in dev.contacts if c not in listed]:
                dev.contacts.pop(cid, None)
