"""Olai's own print window, with a live preview of exactly what will print.
(Windows' modern print dialog can't preview pages for desktop apps like this one.)"""
import fitz
from PySide6.QtCore import Qt, QSettings, QTimer, QRect, QSize
from PySide6.QtGui import QImage, QPainter, QPageLayout
from PySide6.QtPrintSupport import QPrinter, QPrinterInfo, QPrintDialog
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QVBoxLayout, QFormLayout, QComboBox, QLineEdit, QSpinBox,
                               QCheckBox, QLabel, QPushButton, QWidget, QFrame, QSizePolicy)

from .document import DocumentModel
from .viewer import PageView
from . import theme

SETTINGS = ("FolioPDF", "Folio PDF")


def parse_pages(text, n):
    """'1-3, 7' -> [0, 1, 2, 6] (page indexes, in the order written)."""
    out = []
    for part in text.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            a = int(a) if a else 1
            b = int(b) if b else n
            rng = range(a, b + 1) if a <= b else range(a, b - 1, -1)
        else:
            rng = [int(part)]
        for p in rng:
            if 1 <= p <= n and p - 1 not in out:
                out.append(p - 1)
    return out


def print_pages(printer, doc, pages, orientation="auto", fit=True, annots=True, grayscale=False, progress=None):
    """Paint the given pages onto a configured QPrinter. progress(i) may return False to stop."""
    painter = QPainter()
    started = False
    try:
        for i, pno in enumerate(pages):
            if progress is not None and progress(i) is False:
                if started:
                    printer.abort()
                return False
            page = doc[pno]
            land = page.rect.width > page.rect.height if orientation == "auto" else orientation == "landscape"
            printer.setPageOrientation(QPageLayout.Orientation.Landscape if land else QPageLayout.Orientation.Portrait)
            if not started:
                if not painter.begin(printer):
                    raise RuntimeError("Couldn't start the printer.")
                started = True
            else:
                printer.newPage()
            res = printer.resolution()
            paint = printer.pageLayout().paintRectPixels(res)
            area = QRect(0, 0, paint.width(), paint.height())
            dpi = min(res, 300)
            pix = page.get_pixmap(dpi=dpi, alpha=False, annots=annots)
            img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format.Format_RGB888).copy()
            if grayscale:
                img = img.convertToFormat(QImage.Format.Format_Grayscale8)
            if fit:
                size = img.size().scaled(area.size(), Qt.AspectRatioMode.KeepAspectRatio)
            else:                                   # actual size: 1 PDF point = 1/72 inch
                size = QSize(round(page.rect.width * res / 72), round(page.rect.height * res / 72))
            x = area.x() + (area.width() - size.width()) // 2
            y = area.y() + (area.height() - size.height()) // 2 if fit else area.y()
            painter.drawImage(QRect(x, y, size.width(), size.height()), img)
    finally:
        if started:
            painter.end()
    return True


class PrintDialog(QDialog):
    def __init__(self, parent, doc, current_page, name):
        super().__init__(parent)
        self.setWindowTitle(f"Print — {name}")
        self.resize(1000, 700)
        self.doc = doc
        self.current = max(0, current_page)
        self.settings = QSettings(*SETTINGS)
        self.printer = QPrinter(QPrinter.PrinterMode.HighResolution)

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        left = QWidget()
        left.setFixedWidth(330)
        lv = QVBoxLayout(left)
        lv.setContentsMargins(20, 18, 20, 18)
        lv.setSpacing(12)
        head = QLabel("Print")
        head.setStyleSheet("font-size: 20px; font-weight: 600;")
        lv.addWidget(head)
        form = QFormLayout()
        form.setVerticalSpacing(10)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)

        self.printer_box = QComboBox()
        names = QPrinterInfo.availablePrinterNames()
        self.printer_box.addItems(names)
        want = self.settings.value("print/printer") or QPrinterInfo.defaultPrinterName()
        if want in names:
            self.printer_box.setCurrentText(want)
        form.addRow("Printer", self.printer_box)
        self.more = QPushButton("Printer settings…")
        self.more.clicked.connect(self._printer_settings)
        form.addRow("", self.more)

        self.pages_box = QComboBox()
        self.pages_box.addItems(["All pages", f"Current page ({self.current + 1})", "Custom pages"])
        form.addRow("Pages", self.pages_box)
        self.range_edit = QLineEdit()
        self.range_edit.setPlaceholderText(f"e.g. 1-3, 7   (1–{doc.page_count})")
        self.range_edit.setEnabled(False)
        form.addRow("", self.range_edit)

        self.copies = QSpinBox()
        self.copies.setRange(1, 999)
        form.addRow("Copies", self.copies)

        self.orient = QComboBox()
        self.orient.addItems(["Automatic", "Portrait", "Landscape"])
        self.orient.setCurrentIndex(int(self.settings.value("print/orient", 0)))
        form.addRow("Orientation", self.orient)

        self.scale = QComboBox()
        self.scale.addItems(["Fit to paper", "Actual size"])
        self.scale.setCurrentIndex(int(self.settings.value("print/scale", 0)))
        form.addRow("Size", self.scale)

        self.colour = QComboBox()
        self.colour.addItems(["Colour", "Black and white"])
        self.colour.setCurrentIndex(int(self.settings.value("print/colour", 0)))
        form.addRow("Colour", self.colour)

        self.annots = QCheckBox("Include highlights, notes and drawings")
        self.annots.setChecked(self.settings.value("print/annots", True, type=bool))
        form.addRow("", self.annots)
        lv.addLayout(form)

        self.summary = QLabel()
        self.summary.setProperty("muted", True)
        self.summary.setWordWrap(True)
        lv.addWidget(self.summary)
        lv.addStretch(1)
        row = QHBoxLayout()
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        self.print_btn = QPushButton("Print")
        self.print_btn.setDefault(True)
        self.print_btn.setStyleSheet(f"QPushButton{{background:{theme.c('accent')}; color:{theme.c('accent_text')};"
                                     f"border:none; padding:7px 22px; border-radius:6px; font-weight:600;}}")
        self.print_btn.clicked.connect(self._accept)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(self.print_btn)
        lv.addLayout(row)
        root.addWidget(left)

        line = QFrame()
        line.setFixedWidth(1)
        line.setStyleSheet(f"background:{theme.c('border')};")
        root.addWidget(line)
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(0)
        self.pmodel = DocumentModel()
        self.pview = PageView(self.pmodel)
        self.pview.set_tool("hand")
        self.pview.fit_mode = "page"
        self.pmodel.changed.connect(lambda kind: self.pview.rebuild(keep_position=False))
        self.pview.currentPageChanged.connect(self._page_label)
        rv.addWidget(self.pview, 1)
        self.preview_info = QLabel()
        self.preview_info.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview_info.setProperty("muted", True)
        self.preview_info.setContentsMargins(0, 6, 0, 8)
        rv.addWidget(self.preview_info)
        root.addWidget(right, 1)

        self._timer = QTimer(self, singleShot=True, interval=250, timeout=self.update_preview)
        self.pages_box.currentIndexChanged.connect(self._pages_mode)
        self.range_edit.textChanged.connect(lambda _: self._timer.start())
        self.annots.toggled.connect(lambda _: self._timer.start())
        self.copies.valueChanged.connect(lambda _: self._summarise())
        for box in (self.orient, self.scale, self.colour):
            box.currentIndexChanged.connect(lambda _: self._summarise())
        if not names:
            self.print_btn.setEnabled(False)
            self.more.setEnabled(False)
        self.update_preview()

    # ------------------------------------------------------------ pages
    def _pages_mode(self, i):
        self.range_edit.setEnabled(i == 2)
        if i == 2:
            self.range_edit.setFocus()
        self.update_preview()

    def selected_pages(self):
        n = self.doc.page_count
        mode = self.pages_box.currentIndex()
        if mode == 0:
            return list(range(n))
        if mode == 1:
            return [min(self.current, n - 1)]
        try:
            return parse_pages(self.range_edit.text(), n)
        except ValueError:
            return []

    def done(self, r):
        self._timer.stop()                  # no preview refresh after the window has closed
        super().done(r)

    def update_preview(self):
        if self.doc is None or self.doc.is_closed:
            return
        pages = self.selected_pages()
        prev = fitz.open()
        for p in pages:
            prev.insert_pdf(self.doc, from_page=p, to_page=p, annots=self.annots.isChecked())
        if prev.page_count == 0:
            prev.new_page()
        self.pmodel.load_document(prev, "Preview", modified=False)
        self.pview.fit_page()
        self._pages = pages
        self._summarise()
        self._page_label(0)

    def _page_label(self, i):
        if not getattr(self, "_pages", None):
            self.preview_info.setText("No pages to print — check the page numbers.")
            return
        i = max(0, min(i, len(self._pages) - 1))
        self.preview_info.setText(f"Preview: sheet {i + 1} of {len(self._pages)}  ·  page {self._pages[i] + 1} "
                                  f"of the document  ·  scroll to see the others")

    def _summarise(self):
        pages = getattr(self, "_pages", [])
        copies = self.copies.value()
        if not self.printer_box.count():
            self.summary.setText("No printers are installed. Add one in Windows Settings → Printers & scanners.")
        elif not pages:
            self.summary.setText("Type pages like 1-3, 7.")
        else:
            sheets = len(pages) * copies
            self.summary.setText(f"{len(pages)} page{'s' if len(pages) != 1 else ''}"
                                 + (f" × {copies} copies = {sheets} sheets" if copies > 1 else "")
                                 + ("  ·  black and white" if self.colour.currentIndex() == 1 else ""))
        self.print_btn.setEnabled(bool(pages) and self.printer_box.count() > 0)

    # ------------------------------------------------------------ printer
    def _configure(self):
        self.printer.setPrinterName(self.printer_box.currentText())
        self.printer.setCopyCount(self.copies.value())
        self.printer.setColorMode(QPrinter.ColorMode.GrayScale if self.colour.currentIndex() == 1
                                  else QPrinter.ColorMode.Color)
        self.printer.setDocName(self.windowTitle().replace("Print — ", ""))

    def _printer_settings(self):
        """The printer's own options (paper, duplex, quality...)."""
        self._configure()
        d = QPrintDialog(self.printer, self)
        d.setOption(QPrintDialog.PrintDialogOption.PrintPageRange, False)
        if d.exec():
            name = self.printer.printerName()
            if name and self.printer_box.findText(name) >= 0:
                self.printer_box.setCurrentText(name)

    def _accept(self):
        if not self.selected_pages():
            return
        self._configure()
        self.settings.setValue("print/printer", self.printer_box.currentText())
        self.settings.setValue("print/orient", self.orient.currentIndex())
        self.settings.setValue("print/scale", self.scale.currentIndex())
        self.settings.setValue("print/colour", self.colour.currentIndex())
        self.settings.setValue("print/annots", self.annots.isChecked())
        self.accept()

    def options(self):
        return {
            "orientation": ["auto", "portrait", "landscape"][self.orient.currentIndex()],
            "fit": self.scale.currentIndex() == 0,
            "annots": self.annots.isChecked(),
            "grayscale": self.colour.currentIndex() == 1,
        }
