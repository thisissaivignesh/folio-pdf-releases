"""Small line icons drawn from inline SVG so the app needs no image files."""
from PySide6.QtCore import QByteArray, Qt, QRectF
from PySide6.QtGui import QIcon, QPixmap, QPainter
from PySide6.QtSvg import QSvgRenderer

_PATHS = {
    "new": "M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z M14 3v6h6 M12 12v6 M9 15h6",
    "open": "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
    "save": "M5 3h11l5 5v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z M7 3v5h8V3 M7 21v-7h10v7",
    "print": "M6 9V3h12v6 M6 18H4v-7h16v7h-2 M6 14h12v7H6z",
    "sidebar": "M3 5h18v14H3z M9 5v14",
    "zoom_in": "M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14z M21 21l-5-5 M11 8v6 M8 11h6",
    "zoom_out": "M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14z M21 21l-5-5 M8 11h6",
    "fit_width": "M3 12h18 M7 8l-4 4 4 4 M17 8l4 4-4 4",
    "fit_page": "M6 3h12v18H6z M9 8h6 M9 12h6 M9 16h4",
    "prev": "M6 15l6-6 6 6",
    "next": "M6 9l6 6 6-6",
    "undo": "M9 14L4 9l5-5 M4 9h10a6 6 0 0 1 0 12h-3",
    "redo": "M15 14l5-5-5-5 M20 9H10a6 6 0 0 0 0 12h3",
    "select": "M9 4h6 M12 4v16 M9 20h6",
    "hand": "M12 3v18 M3 12h18 M9 6l3-3 3 3 M9 18l3 3 3-3 M6 9l-3 3 3 3 M18 9l3 3-3 3",
    "text": "M4 7V4h16v3 M12 4v16 M9 20h6",
    "highlight": "M9 11l-6 6v3h3l6-6 M22 12l-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4",
    "draw": "M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z",
    "rect": "M4 5h16v14H4z",
    "image": "M3 5h18v14H3z M8.5 9a1.5 1.5 0 1 0 0 3a1.5 1.5 0 1 0 0-3z M21 15l-5-5L5 19",
    "signature": "M3 17c3-6 5-8 6-6s-2 6 0 6 3-4 5-4 2 3 4 3h3 M3 21h18",
    "note": "M4 4h16v12l-4 4H4z M16 20v-4h4 M8 9h8 M8 13h5",
    "eraser": "M7 21h10 M5.5 15.5l9-9a2 2 0 0 1 2.8 0l2.2 2.2a2 2 0 0 1 0 2.8L13 18H8z",
    "search": "M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14z M21 21l-5-5",
    "bookmark": "M6 3h12v18l-6-4-6 4z",
    "bookmark_add": "M6 3h12v18l-6-4-6 4z M12 7v6 M9 10h6",
    "chapters": "M8 6h13 M8 12h13 M8 18h13 M3.5 6h.5 M3.5 12h.5 M3.5 18h.5",
    "pages": "M8 3h11v14H8z M5 7v14h11",
    "rotate_right": "M21 12a9 9 0 1 1-3-6.7L21 8 M21 3v5h-5",
    "rotate_left": "M3 12a9 9 0 1 0 3-6.7L3 8 M3 3v5h5",
    "delete": "M3 6h18 M8 6V4h8v2 M6 6l1 14h10l1-14 M10 10v6 M14 10v6",
    "plus": "M12 5v14 M5 12h14",
    "sub_add": "M5 4v10h6 M14 14h7 M17.5 10.5v7",
    "rename": "M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z",
    "up": "M12 19V5 M5 12l7-7 7 7",
    "down": "M12 5v14 M19 12l-7 7-7-7",
    "indent": "M3 5h18 M11 12h10 M11 19h10 M3 9l4 3-4 3",
    "outdent": "M3 5h18 M11 12h10 M11 19h10 M7 9l-4 3 4 3",
    "expand": "M7 15l5 5 5-5 M7 9l5-5 5 5",
    "collapse": "M7 20l5-5 5 5 M7 4l5 5 5-5",
    "convert": "M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z M14 3v6h6 M9 15l3 3 3-3 M12 11v7",
    "close": "M6 6l12 12 M18 6L6 18",
    "copy": "M9 9h11v11H9z M5 15H4V4h11v1",
}

_cache = {}
_default = ["#3c4043"]

# extra shapes for newer tools
_PATHS.update({
    "laser": "M5 19l6-6 M13 11a2 2 0 1 0 0.01 0z M16 4l1 2 M20 8l-2 1 M19.5 4.5l-1.8 1.8",
    "theme": "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z",
    "highlights": "M4 6h12 M4 11h9 M4 16h6 M15 14l2.5 5 1.5-2 2.5.5-3-5.5",
    "copy": "M9 9h11v11H9z M5 15H4V4h11v1",
    "tab_new": "M3 6h7l2 2h9v11H3z M12 11v5 M9.5 13.5h5",
    "window": "M3 5h18v14H3z M3 9h18",
})


def set_default_color(color):
    """Theme switch: icons drawn from now on use this colour."""
    _default[0] = color


def default_color():
    return _default[0]


def icon(name: str, color: str = None) -> QIcon:
    color = color or _default[0]
    key = (name, color)
    if key in _cache:
        return _cache[key]
    d = _PATHS.get(name, _PATHS["plus"])
    svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
        f'stroke="{color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'
        f'<path d="{d}"/></svg>'
    )
    renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
    ic = QIcon()
    for size in (16, 20, 24, 32, 48):
        pm = QPixmap(size, size)
        pm.fill(Qt.GlobalColor.transparent)
        p = QPainter(pm)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        renderer.render(p, QRectF(0, 0, size, size))
        p.end()
        ic.addPixmap(pm)
    _cache[key] = ic
    return ic


def app_icon() -> QIcon:
    """The Olai logo."""
    if "app" in _cache:
        return _cache["app"]
    import base64
    from .logo_data import LOGO_PNG_B64
    pm = QPixmap()
    pm.loadFromData(base64.b64decode(LOGO_PNG_B64), "PNG")
    ic = QIcon()
    for size in (16, 24, 32, 48, 64, 128, 256):
        ic.addPixmap(pm.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatio,
                               Qt.TransformationMode.SmoothTransformation))
    _cache["app"] = ic
    return ic


def set_icon(obj, name, color_key=None):
    """Give a button/action an icon that follows the theme (see refresh_icons)."""
    obj.setProperty("icon_name", name)
    if color_key:
        obj.setProperty("icon_color_key", color_key)
    from . import theme
    obj.setIcon(icon(name, theme.c(color_key) if color_key else None))
    return obj


def refresh_icons(root):
    """Redraw every themed icon under `root` after a theme change."""
    from PySide6.QtCore import QObject
    from . import theme
    for obj in [root] + root.findChildren(QObject):
        name = obj.property("icon_name") if hasattr(obj, "property") else None
        if name and hasattr(obj, "setIcon"):
            key = obj.property("icon_color_key")
            obj.setIcon(icon(name, theme.c(key) if key else None))


def wordmark(height, dpr=1.0):
    """The Olai wordmark at the given height, with slightly rounded corners."""
    import base64
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QPainterPath
    from .logo_data import WORDMARK_PNG_B64
    src = QPixmap()
    src.loadFromData(base64.b64decode(WORDMARK_PNG_B64), "PNG")
    w = height * src.width() / max(src.height(), 1)
    out = QPixmap(int(round(w * dpr)), int(round(height * dpr)))
    out.fill(Qt.GlobalColor.transparent)
    out.setDevicePixelRatio(dpr)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    clip = QPainterPath()
    clip.addRoundedRect(QRectF(0, 0, w, height), height * 0.22, height * 0.22)
    p.setClipPath(clip)
    p.drawPixmap(QRectF(0, 0, w, height), src, QRectF(src.rect()))
    p.end()
    return out
