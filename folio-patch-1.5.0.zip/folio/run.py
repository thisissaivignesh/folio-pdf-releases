"""Starts Olai. Everything in the folio package can be replaced by a quick update."""
import getpass
import json
import os
import sys

from PySide6.QtCore import QSettings, QTimer, QByteArray
from PySide6.QtGui import QFont, QGuiApplication
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import QApplication

from . import theme
from .app import MainWindow, open_files, INSTANCE, SETTINGS
from .icons import app_icon


def _server_name():
    try:
        user = getpass.getuser()
    except Exception:
        user = "user"
    return f"OlaiPDF-{user}"


def _send_to_running(paths):
    """If Olai is already open, hand it the files (they open as tabs) and return True."""
    sock = QLocalSocket()
    sock.connectToServer(_server_name())
    if not sock.waitForConnected(400):
        return False
    if sys.platform == "win32":
        try:  # let the running copy bring its window to the front
            import ctypes
            ctypes.windll.user32.AllowSetForegroundWindow(-1)
        except Exception:
            pass
    sock.write(QByteArray(json.dumps(paths).encode("utf-8") + b"\n"))
    sock.flush()
    sock.waitForBytesWritten(1000)
    sock.disconnectFromServer()
    return True


def _start_server():
    name = _server_name()
    server = QLocalServer()
    if not server.listen(name):
        QLocalServer.removeServer(name)        # left over from a crash
        if not server.listen(name):
            return None

    def on_connection():
        while server.hasPendingConnections():
            conn = server.nextPendingConnection()
            buf = bytearray()

            def read(c=conn, b=buf):
                b.extend(bytes(c.readAll()))
                if b.endswith(b"\n"):
                    try:
                        paths = json.loads(b.decode("utf-8"))
                    except ValueError:
                        paths = []
                    open_files([p for p in paths if isinstance(p, str)])
            conn.readyRead.connect(read)
            conn.disconnected.connect(conn.deleteLater)
    server.newConnection.connect(on_connection)
    return server


def main():
    args = sys.argv[1:]
    files = [os.path.abspath(a) for a in args if not a.startswith("-") and os.path.exists(a)]
    smoke = "--smoke-exit" in args
    if sys.platform == "win32":
        try:  # own taskbar icon instead of Python's
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Olai.Reader.1")
        except Exception:
            pass
    app = QApplication(sys.argv)
    # storage names stay as before the rename, so settings and bookmarks carry over
    app.setOrganizationName(SETTINGS[0])
    app.setApplicationName(SETTINGS[1])
    app.setApplicationDisplayName("Olai")
    app.setStyle("Fusion")
    if sys.platform == "win32":
        app.setFont(QFont("Segoe UI", 9))
    app.setWindowIcon(app_icon())

    if not smoke and "--new-instance" not in args and _send_to_running(files):
        return 0
    if not smoke:
        INSTANCE["server"] = _start_server()

    settings = QSettings(*SETTINGS)
    theme.apply(app, settings.value("theme", "light"))
    try:
        QGuiApplication.styleHints().colorSchemeChanged.connect(
            lambda *_: theme.choice() == "system" and theme.apply(app, "system"))
    except Exception:
        pass

    if smoke:
        # Used by the build to check the packaged .exe starts and has everything it needs.
        import mammoth, pptx, PIL, fitz  # noqa: F401
        if sys.platform == "win32":
            import win32com.client, pythoncom  # noqa: F401
        QTimer.singleShot(1500, app.quit)

    win = MainWindow()
    win._on_theme_changed()
    win.show()
    win.after_start()
    for p in files:
        win.open_path(p)
    code = app.exec()
    if INSTANCE.get("server") is not None:
        INSTANCE["server"].close()
    sys.exit(code)
