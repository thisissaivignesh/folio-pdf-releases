"""The collapsible left pane: Chapters, Bookmarks, Highlights, Pages and Search."""
import fitz
from PySide6.QtCore import Qt, Signal, QSize, QTimer, QRect, QRectF, QVariantAnimation, QEasingCurve
from PySide6.QtGui import QColor, QImage, QPixmap, QIcon, QKeySequence, QShortcut, QPainter, QPen
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTabWidget, QTreeWidget,
                               QTreeWidgetItem, QToolButton, QListWidget, QListWidgetItem,
                               QLineEdit, QCheckBox, QLabel, QPushButton, QInputDialog,
                               QAbstractItemView, QMenu, QHeaderView, QMessageBox, QSizePolicy,
                               QScroller, QStyledItemDelegate, QStyle, QAbstractButton, QButtonGroup,
                               QStackedWidget)

from .icons import icon, set_icon
from . import theme
from .colorpicker import dot_icon

ROLE = Qt.ItemDataRole.UserRole


def _tool(name, tip, slot):
    b = QToolButton()
    set_icon(b, name)
    b.setToolTip(tip)
    b.setAutoRaise(True)
    b.setIconSize(QSize(18, 18))
    b.clicked.connect(slot)
    return b


def _row(*widgets):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(4, 2, 4, 2)
    h.setSpacing(1)
    for x in widgets:
        h.addWidget(x)
    h.addStretch(1)
    return w


# ===================================================================== Chapters
class ChaptersPanel(QWidget):
    """A collapsible tree of chapters, stored inside the PDF as its outline."""
    navigate = Signal(int, object)   # page, y (visible coords) or None
    tocEdited = Signal(list)         # full new table of contents for doc.set_toc

    def __init__(self, main):
        super().__init__()
        self.main = main
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_row(
            _tool("plus", "Add chapter at the current page (Ctrl+Shift+C)", self.add_chapter),
            _tool("sub_add", "Add sub-chapter under the selected chapter", self.add_sub_chapter),
            _tool("rename", "Rename (F2)", self.rename),
            _tool("delete", "Delete chapter (and its sub-chapters)", self.delete),
            _tool("up", "Move up", lambda: self.move(-1)),
            _tool("down", "Move down", lambda: self.move(1)),
            _tool("outdent", "Promote (move one level out)", self.outdent),
            _tool("indent", "Demote (make a sub-chapter of the one above)", self.indent),
            _tool("expand", "Expand all", lambda: self.tree.expandAll()),
            _tool("collapse", "Collapse all", lambda: self.tree.collapseAll()),
        ))
        self.tree = QTreeWidget()
        self.tree.setColumnCount(2)
        self.tree.setHeaderHidden(True)
        self.tree.header().setStretchLastSection(False)
        self.tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.setEditTriggers(QAbstractItemView.EditTrigger.EditKeyPressed |
                                  QAbstractItemView.EditTrigger.SelectedClicked)
        self.tree.itemClicked.connect(self._clicked)
        self.tree.itemActivated.connect(self._clicked)
        self.tree.itemChanged.connect(self._renamed)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._menu)
        lay.addWidget(self.tree, 1)
        self.empty = QLabel("No chapters yet.\nGo to a page and click + to add one.")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setObjectName("emptyHint")
        lay.addWidget(self.empty)
        self._loading = False

    # ---- load / export
    def load(self, doc):
        self._loading = True
        expanded = self._expanded_titles()
        self.tree.clear()
        if doc is not None:
            try:
                toc = doc.get_toc(simple=False)
            except Exception:
                toc = []
            stack = [(0, self.tree.invisibleRootItem())]
            for entry in toc:
                lvl, title, page = entry[0], entry[1], entry[2]
                dest = entry[3] if len(entry) > 3 and isinstance(entry[3], dict) else None
                while len(stack) > 1 and stack[-1][0] >= lvl:
                    stack.pop()
                parent = stack[-1][1]
                item = self._make_item(title, page - 1, dest)
                parent.addChild(item)
                stack.append((lvl, item))
                if title in expanded or (dest and dest.get("collapse") is False):
                    item.setExpanded(True)
        has = self.tree.topLevelItemCount() > 0
        self.empty.setVisible(not has)
        self._loading = False

    def _expanded_titles(self):
        out = set()

        def walk(it):
            for i in range(it.childCount()):
                c = it.child(i)
                if c.isExpanded():
                    out.add(c.text(0))
                walk(c)
        walk(self.tree.invisibleRootItem())
        return out

    def _make_item(self, title, page, dest):
        item = QTreeWidgetItem([title, str(page + 1) if page >= 0 else ""])
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
        item.setData(0, ROLE, {"page": page, "dest": dest})
        item.setTextAlignment(1, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        item.setForeground(1, theme.qcolor("muted"))
        return item

    def to_toc(self):
        toc = []

        def walk(parent, level):
            for i in range(parent.childCount()):
                it = parent.child(i)
                d = it.data(0, ROLE) or {}
                page = d.get("page", 0)
                dest = d.get("dest")
                title = it.text(0).strip() or "Untitled"
                if dest:
                    dest = dict(dest)
                    dest["collapse"] = not it.isExpanded()
                    toc.append([level, title, page + 1, dest])
                else:
                    toc.append([level, title, page + 1])
                walk(it, level + 1)
        walk(self.tree.invisibleRootItem(), 1)
        return toc

    def _emit(self):
        self.empty.setVisible(self.tree.topLevelItemCount() == 0)
        self.tocEdited.emit(self.to_toc())

    # ---- actions
    def _clicked(self, item, col=0):
        d = item.data(0, ROLE) or {}
        page = d.get("page", -1)
        if page < 0:
            return
        y = None
        dest = d.get("dest")
        if dest and dest.get("kind") == fitz.LINK_GOTO and dest.get("to") is not None:
            try:
                doc = self.main.model.doc
                pt = fitz.Point(dest["to"]) * doc[page].rotation_matrix
                y = pt.y
            except Exception:
                y = None
        self.navigate.emit(page, y)

    def _renamed(self, item, col):
        if not self._loading and col == 0:
            self._emit()

    def _new_dest(self, page):
        y = self.main.view.view_point_on_page(page)
        doc = self.main.model.doc
        pt = fitz.Point(0, y) * doc[page].derotation_matrix
        return {"kind": fitz.LINK_GOTO, "page": page, "to": pt, "zoom": 0.0}

    def add_chapter(self, sub=False):
        if not self.main.model.is_open:
            return
        page = max(0, self.main.view.current_page())
        parent = None
        if sub:
            parent = self.tree.currentItem()
            if parent is None:
                QMessageBox.information(self, "Add sub-chapter", "Select the chapter to add it under first.")
                return
        default = f"Chapter {self.tree.topLevelItemCount() + 1}" if not sub else "Section"
        title, ok = QInputDialog.getText(self, "Add sub-chapter" if sub else "Add chapter",
                                         f"Name (starts on page {page + 1}):", text=default)
        if not ok or not title.strip():
            return
        item = self._make_item(title.strip(), page, self._new_dest(page))
        self._loading = True
        if parent is not None:
            # keep siblings in page order
            idx = parent.childCount()
            for i in range(parent.childCount()):
                if (parent.child(i).data(0, ROLE) or {}).get("page", 0) > page:
                    idx = i
                    break
            parent.insertChild(idx, item)
            parent.setExpanded(True)
        else:
            root = self.tree.invisibleRootItem()
            idx = root.childCount()
            for i in range(root.childCount()):
                if (root.child(i).data(0, ROLE) or {}).get("page", 0) > page:
                    idx = i
                    break
            self.tree.insertTopLevelItem(idx, item)
        self._loading = False
        self.tree.setCurrentItem(item)
        self._emit()

    def add_sub_chapter(self):
        self.add_chapter(sub=True)

    def rename(self):
        it = self.tree.currentItem()
        if it:
            self.tree.editItem(it, 0)

    def delete(self):
        it = self.tree.currentItem()
        if not it:
            return
        if it.childCount():
            r = QMessageBox.question(self, "Delete chapter",
                                     f"Delete “{it.text(0)}” and its {it.childCount()} sub-chapter(s)?")
            if r != QMessageBox.StandardButton.Yes:
                return
        parent = it.parent() or self.tree.invisibleRootItem()
        parent.removeChild(it)
        self._emit()

    def _take(self, it):
        parent = it.parent() or self.tree.invisibleRootItem()
        idx = parent.indexOfChild(it)
        parent.takeChild(idx)
        return parent, idx

    def move(self, delta):
        it = self.tree.currentItem()
        if not it:
            return
        parent = it.parent() or self.tree.invisibleRootItem()
        idx = parent.indexOfChild(it)
        new = idx + delta
        if not (0 <= new < parent.childCount()):
            return
        exp = it.isExpanded()
        self._loading = True
        parent.takeChild(idx)
        parent.insertChild(new, it)
        it.setExpanded(exp)
        self._loading = False
        self.tree.setCurrentItem(it)
        self._emit()

    def indent(self):
        it = self.tree.currentItem()
        if not it:
            return
        parent = it.parent() or self.tree.invisibleRootItem()
        idx = parent.indexOfChild(it)
        if idx == 0:
            return
        above = parent.child(idx - 1)
        self._loading = True
        parent.takeChild(idx)
        above.addChild(it)
        above.setExpanded(True)
        self._loading = False
        self.tree.setCurrentItem(it)
        self._emit()

    def outdent(self):
        it = self.tree.currentItem()
        if not it or it.parent() is None:
            return
        parent = it.parent()
        grand = parent.parent() or self.tree.invisibleRootItem()
        self._loading = True
        parent.takeChild(parent.indexOfChild(it))
        grand.insertChild(grand.indexOfChild(parent) + 1, it)
        self._loading = False
        self.tree.setCurrentItem(it)
        self._emit()

    def _menu(self, pos):
        m = QMenu(self)
        m.addAction(icon("plus"), "Add chapter here", self.add_chapter)
        if self.tree.itemAt(pos):
            m.addAction(icon("sub_add"), "Add sub-chapter", self.add_sub_chapter)
            m.addAction(icon("rename"), "Rename", self.rename)
            m.addAction(icon("delete"), "Delete", self.delete)
            m.addSeparator()
            m.addAction("Set to the current page", self.set_to_current_page)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    def set_to_current_page(self):
        it = self.tree.currentItem()
        if not it:
            return
        page = max(0, self.main.view.current_page())
        self._loading = True
        it.setData(0, ROLE, {"page": page, "dest": self._new_dest(page)})
        it.setText(1, str(page + 1))
        self._loading = False
        self._emit()


# ==================================================================== Bookmarks
class BookmarksPanel(QWidget):
    navigate = Signal(int, object)

    def __init__(self, main):
        super().__init__()
        self.main = main
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_row(
            _tool("bookmark_add", "Bookmark this spot (Ctrl+D)", self.add),
            _tool("rename", "Rename", self.rename),
            _tool("delete", "Remove bookmark", self.delete),
            _tool("up", "Move up", lambda: self.move(-1)),
            _tool("down", "Move down", lambda: self.move(1)),
        ))
        self.list = QListWidget()
        self.list.itemClicked.connect(self._go)
        self.list.itemActivated.connect(self._go)
        lay.addWidget(self.list, 1)
        self.hint = QLabel("Bookmarks are your own quick-jump marks.\nThey don't change the PDF.")
        self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hint.setObjectName("emptyHint")
        lay.addWidget(self.hint)
        self.key = None

    def load(self, key):
        self.key = key
        self.list.clear()
        for b in self.main.bookmarks.get(key):
            self._add_item(b)
        self._update_hint()

    def _update_hint(self):
        if self.key is None and self.main.model.is_open:
            self.hint.setText("Save this PDF first to keep bookmarks for it.")
            self.hint.show()
        else:
            self.hint.setText("Bookmarks are your own quick-jump marks.\nThey don't change the PDF.")
            self.hint.setVisible(self.list.count() == 0)

    def _add_item(self, b):
        it = QListWidgetItem(icon("bookmark", "#f6a01a"), f"{b['name']}    · p. {b['page'] + 1}")
        it.setData(ROLE, b)
        self.list.addItem(it)

    def _save(self):
        items = [self.list.item(i).data(ROLE) for i in range(self.list.count())]
        self.main.bookmarks.put(self.key, items)
        self._update_hint()

    def add(self):
        if not self.main.model.is_open:
            return
        if self.key is None:
            QMessageBox.information(self, "Bookmarks", "Save this PDF first, then you can bookmark it.")
            return
        page = max(0, self.main.view.current_page())
        name, ok = QInputDialog.getText(self, "Add bookmark", f"Name for this spot on page {page + 1}:",
                                        text=f"Page {page + 1}")
        if not ok:
            return
        b = {"name": name.strip() or f"Page {page + 1}", "page": page,
             "y": self.main.view.view_point_on_page(page)}
        self._add_item(b)
        self._save()

    def rename(self):
        it = self.list.currentItem()
        if not it:
            return
        b = it.data(ROLE)
        name, ok = QInputDialog.getText(self, "Rename bookmark", "Name:", text=b["name"])
        if ok and name.strip():
            b["name"] = name.strip()
            it.setData(ROLE, b)
            it.setText(f"{b['name']}    · p. {b['page'] + 1}")
            self._save()

    def delete(self):
        row = self.list.currentRow()
        if row >= 0:
            self.list.takeItem(row)
            self._save()

    def move(self, d):
        row = self.list.currentRow()
        new = row + d
        if row < 0 or not (0 <= new < self.list.count()):
            return
        it = self.list.takeItem(row)
        self.list.insertItem(new, it)
        self.list.setCurrentRow(new)
        self._save()

    def _go(self, it):
        b = it.data(ROLE)
        self.navigate.emit(b["page"], b.get("y"))


# ======================================================================== Pages
THUMB_ROLE = Qt.ItemDataRole.UserRole + 1


class ThumbDelegate(QStyledItemDelegate):
    """Draws each page as a whole, centred miniature with its number underneath."""

    def __init__(self, panel):
        super().__init__(panel)
        self.panel = panel

    def sizeHint(self, option, index):
        hint = index.data(Qt.ItemDataRole.SizeHintRole)
        return hint if isinstance(hint, QSize) else QSize(self.panel.THUMB_W + 24, int(self.panel.THUMB_W * 1.42) + 34)

    def paint(self, painter, option, index):
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        r = option.rect
        selected = bool(option.state & QStyle.StateFlag.State_Selected)
        hover = bool(option.state & QStyle.StateFlag.State_MouseOver)
        hint = self.sizeHint(option, index)
        w = self.panel.THUMB_W
        h = hint.height() - 34
        x = r.x() + (r.width() - w) // 2
        y = r.y() + 8
        target = QRect(x, y, w, h)
        if selected or hover:
            bg = theme.qcolor("accent_soft") if selected else theme.qcolor("hover")
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(bg)
            painter.drawRoundedRect(QRect(x - 8, r.y() + 2, w + 16, r.height() - 4), 8, 8)
        if not theme.tokens()["hc"]:
            painter.fillRect(target.translated(1, 2), QColor(0, 0, 0, 45))
        pm = index.data(THUMB_ROLE)
        if isinstance(pm, QPixmap) and not pm.isNull():
            painter.drawPixmap(target, pm)
        else:
            painter.fillRect(target, QColor("#ffffff"))
        pen = QPen(theme.qcolor("accent") if selected else theme.qcolor("border_strong"), 2 if selected else 1)
        painter.setPen(pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRect(target)
        painter.setPen(theme.qcolor("text") if selected else theme.qcolor("text2"))
        painter.drawText(QRect(r.x(), y + h + 4, r.width(), 20), Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop,
                         str(index.row() + 1))
        painter.restore()


class PagesPanel(QWidget):
    navigate = Signal(int, object)
    pageMoved = Signal(int, int)        # from, to (insert before 'to', -1 = end)
    pageAction = Signal(str, int)       # action name, page

    THUMB_W = 150

    def __init__(self, main):
        super().__init__()
        self.main = main
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_row(
            _tool("plus", "Insert blank page after", lambda: self._act("blank")),
            _tool("rotate_left", "Rotate left", lambda: self._act("rotl")),
            _tool("rotate_right", "Rotate right", lambda: self._act("rotr")),
            _tool("delete", "Delete page", lambda: self._act("delete")),
        ))
        self.list = QListWidget()
        self.list.setObjectName("pageThumbs")
        self.list.setViewMode(QListWidget.ViewMode.ListMode)
        self.list.setItemDelegate(ThumbDelegate(self))
        self.list.setMouseTracking(True)
        self.list.setSpacing(0)
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self.list.itemClicked.connect(lambda it: self.navigate.emit(self.list.row(it), None))
        self.list.model().rowsMoved.connect(self._moved)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._menu)
        lay.addWidget(self.list, 1)
        self._pending = []
        self._timer = QTimer(self, interval=0, timeout=self._render_some)

    def load(self, doc):
        self._timer.stop()
        self.list.blockSignals(True)
        self.list.clear()
        self.list.blockSignals(False)
        if doc is None:
            return
        for pno in range(doc.page_count):
            r = doc[pno].rect
            h = int(round(self.THUMB_W * r.height / max(r.width, 1)))
            it = QListWidgetItem()
            it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsDropEnabled)
            it.setSizeHint(QSize(self.THUMB_W + 24, h + 34))
            it.setToolTip(f"Page {pno + 1}")
            self.list.addItem(it)
        self._pending = list(range(doc.page_count))
        self._timer.start()

    def refresh_page(self, pno):
        if pno not in self._pending:
            self._pending.insert(0, pno)
        self._timer.start()

    def _render_some(self):
        doc = self.main.model.doc
        if doc is None or not self._pending:
            self._timer.stop()
            return
        dpr = max(self.list.devicePixelRatioF(), 1.0)
        for _ in range(4):
            if not self._pending:
                break
            pno = self._pending.pop(0)
            if pno >= doc.page_count or pno >= self.list.count():
                continue
            page = doc[pno]
            s = self.THUMB_W * dpr / max(page.rect.width, 1)
            try:
                pix = page.get_pixmap(matrix=fitz.Matrix(s, s), alpha=False)
            except Exception:
                continue
            img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format.Format_RGB888).copy()
            pm = QPixmap.fromImage(img)
            pm.setDevicePixelRatio(dpr)
            self.list.item(pno).setData(THUMB_ROLE, pm)

    def select(self, pno):
        if 0 <= pno < self.list.count():
            self.list.blockSignals(True)
            self.list.setCurrentRow(pno)
            self.list.blockSignals(False)

    def _moved(self, parent, start, end, dest, row):
        self.pageMoved.emit(start, row if row < self.list.count() else -1)

    def _act(self, name, pno=None):
        if pno is None:
            pno = self.list.currentRow()
            if pno < 0:
                pno = max(0, self.main.view.current_page())
        self.pageAction.emit(name, pno)

    def _menu(self, pos):
        it = self.list.itemAt(pos)
        if not it:
            return
        pno = self.list.row(it)
        m = QMenu(self)
        m.addAction(icon("plus"), "Insert blank page after", lambda: self._act("blank", pno))
        m.addAction(icon("open"), "Insert pages from file after…", lambda: self._act("insert_file", pno))
        m.addSeparator()
        m.addAction(icon("rotate_left"), "Rotate left", lambda: self._act("rotl", pno))
        m.addAction(icon("rotate_right"), "Rotate right", lambda: self._act("rotr", pno))
        m.addAction(icon("up"), "Move up", lambda: self._act("up", pno))
        m.addAction(icon("down"), "Move down", lambda: self._act("down", pno))
        m.addSeparator()
        m.addAction(icon("save"), "Extract page to new PDF…", lambda: self._act("extract", pno))
        m.addAction(icon("delete"), "Delete page", lambda: self._act("delete", pno))
        m.exec(self.list.viewport().mapToGlobal(pos))


# ======================================================================= Search
class SearchPanel(QWidget):
    searchRequested = Signal(str, bool, bool)
    stepRequested = Signal(int)
    resultChosen = Signal(int)

    def __init__(self, main):
        super().__init__()
        self.main = main
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 4)
        lay.setSpacing(6)
        row = QHBoxLayout()
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Word or phrase…")
        self.edit.setClearButtonEnabled(True)
        self.edit.returnPressed.connect(self._go)
        row.addWidget(self.edit, 1)
        self.btn = QPushButton("Find")
        set_icon(self.btn, "search")
        self.btn.clicked.connect(self._go)
        row.addWidget(self.btn)
        lay.addLayout(row)
        opts = QHBoxLayout()
        self.case = QCheckBox("Match case")
        self.whole = QCheckBox("Whole words")
        opts.addWidget(self.case)
        opts.addWidget(self.whole)
        opts.addStretch(1)
        self.prev = _tool("prev", "Previous match (Shift+F3)", lambda: self.stepRequested.emit(-1))
        self.next = _tool("next", "Next match (F3)", lambda: self.stepRequested.emit(1))
        opts.addWidget(self.prev)
        opts.addWidget(self.next)
        lay.addLayout(opts)
        self.status = QLabel("")
        self.status.setObjectName("searchStatus")
        self.status.setProperty("kind", "info")
        self.status.setWordWrap(True)
        self.status.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
        lay.addWidget(self.status)
        self.results = QListWidget()
        self.results.setWordWrap(True)
        self.results.setTextElideMode(Qt.TextElideMode.ElideNone)
        self.results.currentRowChanged.connect(lambda r: r >= 0 and self.resultChosen.emit(r))
        lay.addWidget(self.results, 1)

    def _go(self):
        self.searchRequested.emit(self.edit.text(), self.case.isChecked(), self.whole.isChecked())

    def show_status(self, text, kind="info"):
        self.status.setProperty("kind", kind)
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.status.setText(text)

    def set_results(self, results, phrase):
        self.results.blockSignals(True)
        self.results.clear()
        for r in results:
            ctx = r["context"] or phrase
            it = QListWidgetItem(f"Page {r['page'] + 1}\n{ctx}")
            self.results.addItem(it)
        self.results.blockSignals(False)

    def select_row(self, row):
        self.results.blockSignals(True)
        self.results.setCurrentRow(row)
        self.results.blockSignals(False)


# =================================================================== Highlights
class HighlightsPanel(QWidget):
    """Your own list of important highlighted passages to revisit (kept per file, outside the PDF)."""
    navigate = Signal(int, object)

    def __init__(self, main):
        super().__init__()
        self.main = main
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_row(
            _tool("rename", "Add a note to this highlight", self.rename),
            _tool("delete", "Remove from Highlights (the highlight stays in the PDF)", self.delete),
            _tool("up", "Move up", lambda: self.move(-1)),
            _tool("down", "Move down", lambda: self.move(1)),
            _tool("copy", "Copy the highlighted text", self.copy_text),
        ))
        self.list = QListWidget()
        self.list.setWordWrap(True)
        self.list.setTextElideMode(Qt.TextElideMode.ElideNone)
        self.list.setIconSize(QSize(14, 14))
        self.list.itemClicked.connect(self._go)
        self.list.itemActivated.connect(self._go)
        self.list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._menu)
        lay.addWidget(self.list, 1)
        self.hint = QLabel()
        self.hint.setObjectName("emptyHint")
        self.hint.setWordWrap(True)
        self.hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.hint)
        self.key = None

    def load(self, key):
        self.key = key
        self.list.clear()
        for e in self.main.highlights.get(key):
            self._add_item(e)
        self._update_hint()

    def _update_hint(self):
        if self.key is None and self.main.model.is_open:
            self.hint.setText("Save this PDF first to keep a Highlights list for it.")
            self.hint.show()
        else:
            self.hint.setText("Important passages you want to revisit.\n\nWith the Highlight tool, right-click a "
                              "highlight and choose “Add to Highlights”. Or select text and right-click it.")
            self.hint.setVisible(self.list.count() == 0)

    @staticmethod
    def _label(e):
        text = " ".join((e.get("text") or "").split())
        if len(text) > 140:
            text = text[:137] + "…"
        first = e.get("note") or (f"“{text}”" if text else "Highlighted area")
        second = f"Page {e['page'] + 1}" + (f"  ·  “{text[:60]}…”" if e.get("note") and text else "")
        return f"{first}\n{second}"

    def _add_item(self, e):
        it = QListWidgetItem(dot_icon(e.get("color", "#ffd400"), 14), self._label(e))
        it.setData(ROLE, e)
        it.setToolTip(e.get("text", ""))
        self.list.addItem(it)
        return it

    def entries(self):
        return [self.list.item(i).data(ROLE) for i in range(self.list.count())]

    def _save(self):
        self.main.highlights.put(self.key, self.entries())
        self._update_hint()

    def add(self, entry):
        if self.key is None:
            QMessageBox.information(self, "Highlights", "Save this PDF first, then you can add to Highlights.")
            return False
        it = self._add_item(entry)
        self.list.setCurrentItem(it)
        self._save()
        return True

    @staticmethod
    def _overlaps(e, pno, rect):
        if e.get("page") != pno:
            return False
        r = fitz.Rect(rect)
        return any(fitz.Rect(x).intersects(r) for x in e.get("rects", []))

    def find(self, pno, rect):
        for i in range(self.list.count()):
            if self._overlaps(self.list.item(i).data(ROLE), pno, rect):
                return i
        return -1

    def remove_at(self, pno, rect):
        i = self.find(pno, rect)
        if i >= 0:
            self.list.takeItem(i)
            self._save()

    def recolor(self, pno, rect, color):
        i = self.find(pno, rect)
        if i >= 0:
            it = self.list.item(i)
            e = it.data(ROLE)
            e["color"] = color
            it.setData(ROLE, e)
            it.setIcon(dot_icon(color, 14))
            self._save()

    def refresh_icons(self):
        for i in range(self.list.count()):
            it = self.list.item(i)
            it.setIcon(dot_icon(it.data(ROLE).get("color", "#ffd400"), 14))

    def rename(self):
        it = self.list.currentItem()
        if not it:
            return
        e = it.data(ROLE)
        note, ok = QInputDialog.getText(self, "Highlight note", "A short note or title (leave empty for none):",
                                        text=e.get("note", ""))
        if ok:
            e["note"] = note.strip()
            it.setData(ROLE, e)
            it.setText(self._label(e))
            self._save()

    def delete(self):
        row = self.list.currentRow()
        if row >= 0:
            self.list.takeItem(row)
            self._save()

    def move(self, d):
        row = self.list.currentRow()
        new = row + d
        if row < 0 or not (0 <= new < self.list.count()):
            return
        it = self.list.takeItem(row)
        self.list.insertItem(new, it)
        self.list.setCurrentRow(new)
        self._save()

    def copy_text(self):
        it = self.list.currentItem()
        if it:
            from PySide6.QtGui import QGuiApplication
            QGuiApplication.clipboard().setText(it.data(ROLE).get("text", ""))

    def _go(self, it):
        e = it.data(ROLE)
        doc = self.main.model.doc
        page = e.get("page", 0)
        y = None
        rects = e.get("rects") or []
        if doc is not None and 0 <= page < doc.page_count and rects:
            y = (fitz.Rect(rects[0]) * doc[page].rotation_matrix).y0
        self.navigate.emit(page, y)
        self.main.view.flash(page, rects)

    def _menu(self, pos):
        it = self.list.itemAt(pos)
        if not it:
            return
        m = QMenu(self)
        m.addAction("Go to it", lambda: self._go(it))
        m.addAction(icon("rename"), "Add a note…", self.rename)
        m.addAction(icon("copy"), "Copy text", self.copy_text)
        m.addSeparator()
        m.addAction(icon("delete"), "Remove from Highlights", self.delete)
        m.exec(self.list.viewport().mapToGlobal(pos))


class PanelTab(QAbstractButton):
    """A side-panel tab: just a centred icon, sliding open to show its name when
    it's selected or the pointer is over it."""
    COLLAPSED = 40
    ICON = 18
    GAP = 7

    def __init__(self, icon_name, text):
        super().__init__()
        self.icon_name = icon_name
        self.setText(text)
        self.setToolTip(text)
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(38)
        self._t = 0.0
        self._hover = False
        self.anim = QVariantAnimation(self)
        self.anim.setDuration(180)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.anim.valueChanged.connect(self._set_t)
        self.toggled.connect(lambda _: self._retarget())
        self.setMinimumWidth(self.COLLAPSED)

    def _text_w(self):
        return self.fontMetrics().horizontalAdvance(self.text())

    def _extra(self):
        return self._text_w() + self.GAP

    def expanded(self):
        return self.isChecked() or self._hover

    def _retarget(self):
        target = 1.0 if self.expanded() else 0.0
        self.anim.stop()
        if abs(target - self._t) < 1e-3:
            self._set_t(target)
            return
        self.anim.setStartValue(float(self._t))
        self.anim.setEndValue(target)
        self.anim.start()

    def _set_t(self, v):
        self._t = float(v)
        self.setMinimumWidth(int(self.COLLAPSED + self._t * self._extra()))
        self.updateGeometry()
        self.update()

    def sizeHint(self):
        return QSize(int(self.COLLAPSED + self._t * self._extra()), 38)

    def enterEvent(self, e):
        self._hover = True
        self._retarget()
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover = False
        self._retarget()
        super().leaveEvent(e)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        t = theme.tokens()
        checked = self.isChecked()
        if self._hover and not checked:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(theme.qcolor("hover"))
            p.drawRoundedRect(self.rect().adjusted(2, 4, -2, -4), 6, 6)
        content = self.ICON + self._t * self._extra()
        x0 = (self.width() - content) / 2
        colour = t["accent_soft_text"] if checked and not t["hc"] else (t["text"] if checked else t["text2"])
        pm = icon(self.icon_name, colour).pixmap(self.ICON, self.ICON)
        p.drawPixmap(int(round(x0)), (self.height() - self.ICON) // 2, pm)
        if self._t > 0.01:
            p.save()
            p.setOpacity(min(1.0, self._t * 1.3))
            tx = x0 + self.ICON + self.GAP
            p.setClipRect(QRectF(tx, 0, self._t * self._text_w() + 1, self.height()))
            p.setPen(theme.qcolor("text") if checked else theme.qcolor("text2"))
            p.drawText(QRectF(tx, 0, self._text_w() + 2, self.height()),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, self.text())
            p.restore()
        if checked:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(theme.qcolor("accent"))
            p.drawRoundedRect(QRectF(x0 - 4, self.height() - 3, content + 8, 2.5), 1.2, 1.2)


class SidePanel(QWidget):
    """Chapters, Bookmarks, Highlights, Pages and Search, switched with a row of icon tabs."""
    currentChanged = Signal(int)
    NAMES = ["chapters", "bookmarks", "highlights", "pages", "search"]
    TITLES = {"chapters": ("Chapters", "chapters"), "bookmarks": ("Bookmarks", "bookmark"),
              "highlights": ("Highlights", "highlights"), "pages": ("Pages", "pages"),
              "search": ("Search", "search")}

    def __init__(self, main):
        super().__init__()
        self.chapters = ChaptersPanel(main)
        self.bookmarks = BookmarksPanel(main)
        self.highlights = HighlightsPanel(main)
        self.pages = PagesPanel(main)
        self.search = SearchPanel(main)
        self.strip = QWidget()
        self.strip.setObjectName("panelStrip")
        h = QHBoxLayout(self.strip)
        h.setContentsMargins(4, 0, 4, 0)
        h.setSpacing(2)
        self.group = QButtonGroup(self)
        self.group.setExclusive(True)
        self.buttons = []
        self.stack = QStackedWidget()
        for i, name in enumerate(self.NAMES):
            title, ic = self.TITLES[name]
            b = PanelTab(ic, title)
            b.clicked.connect(lambda checked=False, k=i: self.setCurrentIndex(k))
            self.group.addButton(b, i)
            h.addWidget(b, 1)
            self.buttons.append(b)
            self.stack.addWidget(getattr(self, name))
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.strip)
        lay.addWidget(self.stack, 1)
        self.setMinimumWidth(220)
        self.setCurrentIndex(0)
        # let a finger scroll the lists like on a tablet
        for view in (self.chapters.tree, self.bookmarks.list, self.highlights.list, self.pages.list,
                     self.search.results):
            view.setVerticalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
            QScroller.grabGesture(view.viewport(), QScroller.ScrollerGestureType.TouchGesture)

    def setCurrentIndex(self, i):
        i = max(0, min(i, len(self.NAMES) - 1))
        changed = i != self.stack.currentIndex()
        self.stack.setCurrentIndex(i)
        self.buttons[i].setChecked(True)
        if changed:
            self.currentChanged.emit(i)

    def currentIndex(self):
        return self.stack.currentIndex()

    def count(self):
        return len(self.NAMES)

    def show_panel(self, name):
        self.setCurrentIndex(self.NAMES.index(name))

    def current_name(self):
        return self.NAMES[self.currentIndex()]

    def refresh_theme(self):
        for b in self.buttons:
            b.update()
        self.highlights.refresh_icons()
        self.pages.list.viewport().update()
