"""Find a word or phrase across the whole document."""
import re
import unicodedata

import fitz

_PUNCT = re.compile(r"^[\W_]+|[\W_]+$", re.UNICODE)


def _norm(s):
    return unicodedata.normalize("NFKC", s)


def _strip(word):
    return _PUNCT.sub("", word)


def has_text_layer(doc, sample=8):
    for pno in range(min(doc.page_count, sample)):
        if doc[pno].get_text("text").strip():
            return True
    return False


def find_all(doc, phrase, match_case=False, whole_word=False, progress=None):
    """Return a list of dicts: {page, rect (visible coords), context}.

    progress(pno) is called per page and may return False to cancel.
    """
    phrase = _norm(phrase.strip())
    if not phrase:
        return []
    results = []
    target_words = [_strip(w) for w in phrase.split()]
    for pno in range(doc.page_count):
        if progress is not None and progress(pno) is False:
            break
        page = doc[pno]
        try:
            rects = page.search_for(phrase)          # case-insensitive, unrotated coords
        except Exception:
            rects = []
        if not rects:
            continue
        words = None
        rot = page.rotation_matrix
        for r in rects:
            grown = fitz.Rect(r.x0 - 0.5, r.y0 - 0.5, r.x1 + 0.5, r.y1 + 0.5)
            if match_case or whole_word:
                if words is None:
                    words = page.get_text("words")
                hit_words = []
                for w in words:
                    wr = fitz.Rect(w[:4])
                    inter = wr & grown
                    if not inter.is_empty and inter.width * inter.height > 0.3 * wr.width * wr.height:
                        hit_words.append(w)
                hit_text = page.get_textbox(grown).strip()
                if match_case and phrase not in _norm(hit_text) and \
                        phrase not in _norm(" ".join(w[4] for w in hit_words)):
                    continue
                if whole_word:
                    got = [_strip(_norm(w[4])) for w in hit_words]
                    a = [x.lower() for x in got if x]
                    b = [x.lower() for x in target_words if x]
                    if a != b:
                        continue
            # a little context for the results list
            ctx_rect = fitz.Rect(r.x0 - 120, r.y0 - 1, r.x1 + 120, r.y1 + 1)
            context = " ".join(page.get_textbox(ctx_rect).split())
            results.append({"page": pno, "rect": r * rot, "context": context})
    return results
