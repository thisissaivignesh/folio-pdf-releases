"""Checks the public releases repo for a newer Olai and installs it.

Two kinds of update:
  * quick update ("patch") — a zip of the folio package, a few hundred KB. Used when the new
    release was built on the same engine as the installed app (see main.py).
  * full update — the normal installer. Needed when the engine changed (new libraries).

The releases repo holds, at the top level:  latest.json, folio-patch-<v>.zip, Olai-Setup-<v>.exe
"""
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

from . import __version__

RELEASES_REPO = "thisissaivignesh/folio-pdf-releases"
DEFAULT_URL = f"https://raw.githubusercontent.com/{RELEASES_REPO}/main/"
STATE_FILE = "state.json"


class UpdateError(Exception):
    pass


class Cancelled(Exception):
    pass


# ------------------------------------------------------------------ locations
def base_url():
    url = os.environ.get("FOLIO_UPDATE_URL") or DEFAULT_URL
    return url if url.endswith("/") else url + "/"


def data_dir():
    d = os.environ.get("FOLIO_DATA_DIR")
    if not d:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), ".local", "share")
        d = os.path.join(base, "FolioPDF")
    return d


def updates_dir():
    return os.path.join(data_dir(), "updates")


def engine():
    return os.environ.get("FOLIO_ENGINE", "dev")


def is_frozen():
    return bool(getattr(sys, "frozen", False))


def version_tuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().lstrip("v").split(".")[:3])
    except ValueError:
        return (0,)


def running_info():
    """What's running right now, for the About box and diagnostics."""
    return {
        "version": __version__,
        "engine": engine(),
        "bundled": os.environ.get("FOLIO_BUNDLED_VERSION", __version__),
        "patched": bool(os.environ.get("FOLIO_PATCH")),
        "failed": os.environ.get("FOLIO_PATCH_FAILED"),
    }


# ---------------------------------------------------------------- state file
def read_state():
    try:
        with open(os.path.join(updates_dir(), STATE_FILE), "r", encoding="utf-8-sig") as f:
            st = json.load(f)
        return st if isinstance(st, dict) else {}
    except (OSError, ValueError):
        return {}


def write_state(st):
    os.makedirs(updates_dir(), exist_ok=True)
    path = os.path.join(updates_dir(), STATE_FILE)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, indent=1)
    os.replace(tmp, path)


# ------------------------------------------------------------------ download
def fetch(url, timeout=20, progress=None, cancel=None):
    if url.startswith("http"):
        sep = "&" if "?" in url else "?"
        url = f"{url}{sep}t={int(time.time())}"     # skip stale caches
    req = urllib.request.Request(url, headers={"User-Agent": f"Olai/{__version__}",
                                               "Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            total = int(r.headers.get("Content-Length") or 0)
            buf = io.BytesIO()
            while True:
                if cancel is not None and cancel():
                    raise Cancelled()
                chunk = r.read(65536)
                if not chunk:
                    break
                buf.write(chunk)
                if progress is not None:
                    progress(buf.tell(), total)
            return buf.getvalue()
    except Cancelled:
        raise
    except Exception as e:
        raise UpdateError(_friendly_net_error(e)) from e


def _friendly_net_error(e):
    text = str(getattr(e, "reason", e))
    code = getattr(e, "code", None)
    if code == 404:
        return "No updates have been published yet."
    if "getaddrinfo" in text or "Name or service" in text or "nodename" in text:
        return "Couldn't reach the internet. Check your connection and try again."
    if "timed out" in text.lower():
        return "The update server took too long to answer. Try again in a moment."
    return f"Couldn't check for updates ({text})."


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


# --------------------------------------------------------------------- check
class Update:
    def __init__(self, manifest, kind):
        self.manifest = manifest
        self.kind = kind                         # "patch" or "full"
        self.version = str(manifest["version"])
        self.notes = manifest.get("notes", "").strip()
        part = manifest.get(kind) or {}
        self.file = part.get("file", "")
        self.sha256 = part.get("sha256", "")
        self.size = int(part.get("size", 0))

    def size_text(self):
        if self.size >= 1024 * 1024:
            return f"{self.size / (1024 * 1024):.1f} MB"
        return f"{max(1, self.size // 1024)} KB"


def check():
    """Returns an Update if a newer version is published, else None. Raises UpdateError."""
    try:
        manifest = json.loads(fetch(base_url() + "latest.json").decode("utf-8"))
        latest = str(manifest["version"])
    except UpdateError:
        raise
    except Exception as e:
        raise UpdateError(f"The update information couldn't be read ({e}).") from e
    if version_tuple(latest) <= version_tuple(__version__):
        return None
    if manifest.get("engine") == engine() and manifest.get("patch"):
        return Update(manifest, "patch")
    if not manifest.get("full"):
        raise UpdateError("This update needs the full installer, but it isn't available yet.")
    return Update(manifest, "full")


# ------------------------------------------------------------- quick update
def _launcher_cmd():
    if is_frozen():
        return [sys.executable]
    return [sys.executable, os.environ.get("FOLIO_LAUNCHER")
            or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "main.py")]


def _no_window():
    return {"creationflags": 0x08000000} if sys.platform == "win32" else {}   # CREATE_NO_WINDOW


def verify_folder(folder):
    """Start a fresh copy of the app that only imports the new code, to prove it loads."""
    out = os.path.join(folder, "verify.txt")
    try:
        rc = subprocess.run(_launcher_cmd() + ["--verify-update", folder, out],
                            timeout=180, **_no_window()).returncode
    except Exception as e:
        raise UpdateError(f"The update couldn't be checked ({e}).") from e
    try:
        with open(out, "r", encoding="utf-8") as f:
            result = f.read()
    except OSError:
        result = ""
    if rc != 0 or not result.startswith("ok"):
        raise UpdateError("The downloaded update didn't pass its start-up check, so it wasn't installed.\n\n"
                          + result[-1500:])


def _safe_extract(blob, dest):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        for name in z.namelist():
            norm = name.replace("\\", "/")
            if norm.startswith("/") or ".." in norm.split("/") or not norm.startswith("folio/"):
                raise UpdateError(f"The update contains an unexpected file: {name}")
        z.extractall(dest)
    if not os.path.isfile(os.path.join(dest, "folio", "__init__.py")):
        raise UpdateError("The update is incomplete.")


def install_patch(update, progress=None, cancel=None):
    blob = fetch(base_url() + update.file, timeout=60, progress=progress, cancel=cancel)
    if update.sha256 and _sha256(blob) != update.sha256:
        raise UpdateError("The download was damaged (checksum mismatch). Please try again.")
    os.makedirs(updates_dir(), exist_ok=True)
    tmp = os.path.join(updates_dir(), update.version + ".new")
    shutil.rmtree(tmp, ignore_errors=True)
    _safe_extract(blob, tmp)
    verify_folder(tmp)
    final = os.path.join(updates_dir(), update.version)
    shutil.rmtree(final, ignore_errors=True)
    os.replace(tmp, final)
    st = read_state()
    prev = st.get("current")
    st["current"] = {"version": update.version, "engine": engine(), "installed": int(time.time())}
    st["previous"] = prev if isinstance(prev, dict) and prev.get("version") != update.version else st.get("previous")
    st["bad"] = [v for v in st.get("bad", []) if v != update.version]
    write_state(st)
    _prune(st)


def _prune(st):
    keep = {d.get("version") for d in (st.get("current"), st.get("previous")) if isinstance(d, dict)}
    try:
        for name in os.listdir(updates_dir()):
            p = os.path.join(updates_dir(), name)
            if os.path.isdir(p) and name not in keep:
                shutil.rmtree(p, ignore_errors=True)
    except OSError:
        pass


def can_undo():
    st = read_state()
    return isinstance(st.get("current"), dict)


def undo_last_update():
    """Go back to the previous quick update, or to the version the installer put on disk."""
    st = read_state()
    cur = st.get("current")
    if isinstance(cur, dict):
        st.setdefault("bad", [])
        if cur.get("version") not in st["bad"]:
            st["bad"].append(cur.get("version"))
    prev = st.get("previous")
    st["current"] = prev if isinstance(prev, dict) else None
    st["previous"] = None
    write_state(st)
    return st["current"]["version"] if st["current"] else os.environ.get("FOLIO_BUNDLED_VERSION", "")


# --------------------------------------------------------------- full update
def download_installer(update, progress=None, cancel=None):
    blob = fetch(base_url() + update.file, timeout=60, progress=progress, cancel=cancel)
    if update.sha256 and _sha256(blob) != update.sha256:
        raise UpdateError("The download was damaged (checksum mismatch). Please try again.")
    folder = tempfile.mkdtemp(prefix="Olai-update-")
    path = os.path.join(folder, os.path.basename(update.file) or "Olai-Setup.exe")
    with open(path, "wb") as f:
        f.write(blob)
    return path


def run_installer(path):
    """Runs the installer quietly; it closes Olai, updates it and opens it again."""
    subprocess.Popen([path, "/SILENT", "/SUPPRESSMSGBOXES", "/NORESTART", "/CLOSEAPPLICATIONS"],
                     close_fds=True)


def restart_command(paths=None):
    """Command that starts a fresh copy of the app (which takes over from this one)."""
    cmd = _launcher_cmd() + ["--new-instance"]
    if isinstance(paths, str):
        paths = [paths]
    cmd.extend(p for p in (paths or []) if p)
    return cmd
